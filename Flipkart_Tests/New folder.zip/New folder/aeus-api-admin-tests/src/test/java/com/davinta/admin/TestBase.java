package com.davinta.admin;

import com.intuit.karate.junit4.Karate;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

@RunWith(Karate.class)
public abstract class TestBase {
    
    
    @BeforeClass
    public static void beforeClass() throws Exception {
    	javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier((hostname, sslSession) -> true);
    	System.setProperty("javax.net.ssl.keyStore", "./certificates/aeusapp-keystore.jks");
        System.setProperty("javax.net.ssl.keyStorePassword", "aeusapp@321");
        System.setProperty("javax.net.ssl.trustStore", "./certificates/aeusapp-truststore.jks");
        System.setProperty("javax.net.ssl.trustStorePassword", "aeusapp@321");
        System.setProperty("api.gateway.enabled", "true");
        System.setProperty("db.check", "true");
        
        if(System.getProperty("jenkins") == null) {
            System.setProperty("env", "dev");
        	System.setProperty("varEnterpriseCode","EN000583");
        	System.setProperty("varTenantId","EN000582");
        	System.setProperty("varAadharNumber","889042683786");
        	System.setProperty("varUserId","AG000003");
        	System.setProperty("varTerminalId","TE000009");
        }
    }
    
    @AfterClass
    public static void afterClass() {

    }
}
