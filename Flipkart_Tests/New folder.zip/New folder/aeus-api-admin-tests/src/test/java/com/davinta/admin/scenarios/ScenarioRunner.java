package com.davinta.admin.scenarios;

import com.davinta.admin.TestBase;
import com.intuit.karate.junit4.Karate;

import cucumber.api.CucumberOptions;

import org.junit.runner.RunWith;

@RunWith(Karate.class)
@CucumberOptions(monochrome = true)
public class ScenarioRunner extends TestBase {

}