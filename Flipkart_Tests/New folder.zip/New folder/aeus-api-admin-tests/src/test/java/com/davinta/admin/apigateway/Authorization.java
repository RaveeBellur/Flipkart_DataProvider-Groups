package com.davinta.admin.apigateway;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Random;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.encoding.ShaPasswordEncoder;


import com.davinta.apigatewaylayer.utils.HmacUtility;
import com.davinta.apigatewaylayer.utils.RsaActionAssist;
import com.davinta.databaseaccesslayer.utils.JsonUtil;


public class Authorization {
	private static ShaPasswordEncoder encoder = new ShaPasswordEncoder(512); 
    private static final Logger logger = LoggerFactory.getLogger(Authorization.class);
	private static String secretKey = "12345678901";
   
    public static String getAuthKey(Map<String, ?> payload){
    	String jsonBody = JsonUtil.disableHtmlEscaping(payload);
    	String authKeyHeader = HmacUtility.authKeyGenerator(jsonBody,secretKey);
    	logger.debug("Auth key header: {}", authKeyHeader);
    	return authKeyHeader;
    }
    
    public static String desKeyGeneration(String n, String e) throws Exception {
		RsaActionAssist object = new RsaActionAssist();
		List<String> keys = new ArrayList<String>();
		keys.add(n);
		keys.add(e);
		BigInteger key = new BigInteger(secretKey);
		BigInteger arr = object.encrypt(key, keys);
		String enc = new String(Base64.getEncoder().encode(arr.toString().getBytes()));
		return enc;
	}
	
	public static String hashPasswordGeneration(String pwd) {
		return encoder.encodePassword(pwd, null);
				
	}
	
	

	
}

    