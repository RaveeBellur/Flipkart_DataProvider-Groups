function(){
	var apiGatewayEnabled = karate.properties['api.gateway.enabled'];
	if (apiGatewayEnabled == 'true') {
		  karate.log('Invoking key-token/clien-info/login services...')
		  var result = karate.call('../apigateway/apigatewayadminauth.feature');
		  return result.jwtHeader;
	} else {
	    return {};
	}
}