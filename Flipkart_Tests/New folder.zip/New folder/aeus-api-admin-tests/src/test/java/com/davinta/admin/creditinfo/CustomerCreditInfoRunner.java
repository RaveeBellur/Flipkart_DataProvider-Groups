package com.davinta.admin.creditinfo;

import org.junit.runner.RunWith;
import com.davinta.admin.TestBase;
import com.intuit.karate.junit4.Karate;
import cucumber.api.CucumberOptions;

@RunWith(Karate.class)
@CucumberOptions(monochrome = true)
public class CustomerCreditInfoRunner extends TestBase{

}
