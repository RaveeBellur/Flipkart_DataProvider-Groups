function(jsonBody){
	  var apiGatewayEnabled = karate.properties['api.gateway.enabled'];
	  if (apiGatewayEnabled == 'true') {
		  karate.log('Generating Auth Header to invoke services through API Gateway layer...')
			var auth = Java.type('com.davinta.admin.apigateway.Authorization')
			var authHeader = auth.getAuthKey(jsonBody)
			return authHeader;
	  } else {
		    return {};
	  }
}