function() { 
	  karate.configure('connectTimeout', 500000);
	  karate.configure('readTimeout', 500000);
	  
	  var scripts = 'classpath:com/davinta/common/scripts/';
	  var expectedJson = 'classpath:com/davinta/device/expectedjson/';
	  
	  karate.set('jsBaseUrl', scripts+'urldetector.js');
	  karate.set('jsAuthorization', scripts+'headers.js');
	  karate.set('jsJwtHeader', scripts+'jwtheaders.js');
	  karate.set('jsTransmissionTime', scripts+'transmissiontime.js');
	  karate.set('jsStringConversion',scripts+'stringconversion.js');
	  karate.set('jsTimeKeeper', scripts+'timekeeper.js');
	  karate.set('jsStreKycComplete', scripts+'strekyccomplete.js');
	  karate.set('jsStrRequestComplete', scripts+'strrequestcomplete.js');
	  karate.set('jsStrGenerator', scripts+'stringgenarator.js');
	  karate.set('jsRandomNumGenerator', scripts+'randomnumgenarator.js');
	  karate.set('setRandomSecretKey', scripts+'setrandomsecretkey.js');
	  
	  
	  	  
	  karate.set('jsonEmpty', scripts+'empty.json');
	  karate.set('jsonEmptyArray', scripts+'emptyarray.json');
	 
	  karate.set('expectedJsonAgent', expectedJson+'agent.json');
	  karate.set('expectedJsonAgentActivation', expectedJson+'agentactivation.json');	  
	  karate.set('expectedJsonAgentWorkflowInitiation', expectedJson+'agentworkflowInitiation.json');
	  karate.set('expectedJsonEnrollmenteKycTaskCompleteexpected', expectedJson+'enrollmentekyctaskcomplete.json');
	  karate.set('expectedJsonEnrollmentProcess', expectedJson+'enrollmentprocess.json');      
	  karate.set('expectedJsonEnrollmentRequestTaskCompleted', expectedJson+'enrollmentrequesttaskcomplete.json');
	  karate.set('expectedJsonFeeAndTax', expectedJson+'feeandtax.json');
	  karate.set('expectedJsonFundTransfer', expectedJson+'fundtransfer.json');
	  karate.set('expectedJsonLatestTransactionHistory', expectedJson+'latesttransactionhistory.json');
	  karate.set('expectedJsonMiniStatement', expectedJson+'ministatement.json');
	  karate.set('expectedJsonTransaction', expectedJson+'transactions.json');
	  karate.set('expectedJsonUpdateAgent', expectedJson+'updateagent.json');
	  karate.set('expectedJsonSearchCustomer', expectedJson+'searchCustomer.json');
	  karate.set('expectedJsonSearchCustomerByMobile', expectedJson+'searchCustomerByMobile.json');
	  karate.set('expectedJsonApplicationVersion', expectedJson+'applicationversion.json');
	  karate.set('expectedJsonMemberBank', expectedJson+'memberbank.json');
	  karate.set('expectedJsonEnterpriseSummary', expectedJson+'enterprisetransactionsummary.json');
	  karate.set('expectedJsonAgentSummary', expectedJson+'agenttransactionsummary.json');
	  karate.set('expectedJsonTransactionGroupSHG', expectedJson+'transactionGroupSHG.json');
	  karate.set('expectedJsonTransactionGroupSHGInfo', expectedJson+'transactionGroupSHGInfo.json');
	  karate.set('expectedJsonThirdPartyTransfer', expectedJson+'thirdPartyTransfer.json');
	  
	  karate.set('varAgentID',karate.properties['varAgentID']);
	  karate.set('varTerminalID',karate.properties['varTerminalID']);
	  karate.set('varTenantID',karate.properties['varTenantID']);
	  karate.set('varCardNumber',karate.properties['varCardNumber']);
	  karate.set('varMobileNumber2',karate.properties['varMobileNumber2']);
	  karate.set('varMobileNumber',karate.properties['varMobileNumber']);
	  
	} 