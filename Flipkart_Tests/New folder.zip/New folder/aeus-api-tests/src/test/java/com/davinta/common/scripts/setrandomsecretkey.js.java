function(){
	var auth = Java.type('com.davinta.device.apigateway.Authorization');
	var authHeader = auth.setRandomSecretKey();
}