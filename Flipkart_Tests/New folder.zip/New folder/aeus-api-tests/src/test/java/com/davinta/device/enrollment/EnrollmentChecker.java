package com.davinta.device.enrollment;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.databaseaccesslayer.common.Base;
import com.davinta.databaseaccesslayer.dao.DB;
import com.davinta.databaseaccesslayer.service.DataSource;
import com.davinta.common.utils.Constants;
import com.davinta.databaseaccesslayer.utils.DataTransformUtil;
import com.davinta.databaseaccesslayer.utils.JsonUtil;
import com.davinta.databaseaccesslayer.utils.ResourceHelper;
import com.google.gson.stream.JsonReader;

public class EnrollmentChecker {
    private static final Logger logger = LoggerFactory.getLogger(EnrollmentChecker.class);

	public static Boolean getCustomerDetailsByCustID(Map<String, Object> jsonResponseMap) throws Throwable {
		if(Constants.DB_CHECK){
			List<Map<String, Object>> dbResult = null;
			String arrayName = "customerVerification";
	
			//1. Read mapping rules
			JsonReader mappingRules = JsonUtil.jsonReader("src/test/java/com/davinta/device/enrollment/enrollmentfieldmapper.json");
	
			//2. Get MySQL DB records 
			dbResult = DataSource.getData(Constants.SEARCH_CUSTOMER_BY_CUSTOMERID,new Object[] { jsonResponseMap.get("customerId").toString()},Constants.ENROLLMENT);
			
			//3. Compare API response with DB 
			boolean result =  DataTransformUtil.compareApiResponseToDbRecords(jsonResponseMap, dbResult, mappingRules,arrayName);
			
			return result;
		}
		else
			return true;
	}
	
	public static Boolean getCustomerDetailsByAadhaar(Map<String, Object> jsonMap) throws Throwable {
		if(Constants.DB_CHECK){
			List<Map<String, Object>> dbResult = null;
			String arrayName = "customerVerification";
	
			//1. Read mapping rules
			JsonReader mappingRules = JsonUtil.jsonReader("src/test/java/com/davinta/device/enrollment/enrollmentfieldmapper.json");
	
			//2. Get MySQL DB records 
			dbResult = DataSource.getData(Constants.SEARCH_CUSTOMER_BY_AADHAAR,new Object[] { jsonMap.get("aadharNumber").toString()},Constants.ENROLLMENT);
			
			//3. Compare API response with DB 
			boolean result =  DataTransformUtil.compareApiResponseToDbRecords(jsonMap, dbResult, mappingRules,arrayName);
			
			return result;
		}
		else
			return true;
	}
		
	
	public static Boolean getCustomerDetailsByMobile(Map<String, Object> jsonMap) throws Throwable {
		if(Constants.DB_CHECK){
			List<Map<String, Object>> dbResult = null;
			String arrayName = "customerVerification";
	
			//1. Read mapping rules
			JsonReader mappingRules = JsonUtil.jsonReader("src/test/java/com/davinta/device/enrollment/enrollmentfieldmapper.json");
	
			//2. Get MySQL DB records 
			dbResult = DataSource.getData(Constants.SEARCH_CUSTOMER_BY_MOBILE,new Object[] { jsonMap.get("mobileNumber").toString()},Constants.ENROLLMENT);
			
			//3. Compare API response with DB 
			boolean result =  DataTransformUtil.compareApiResponseToDbRecords(jsonMap, dbResult, mappingRules,arrayName);
			
			return result;
		}
		else
			return true;
	}
	
	public static Boolean getEnrolledInformation(Map<String, Object> jsonMap,String custID) throws Throwable {
		if(Constants.DB_CHECK){
			List<Map<String, Object>> dbResult = null;
			String arrayName = "enrollVerification";
	
			//1. Read mapping rules
			JsonReader mappingRules = JsonUtil.jsonReader("src/test/java/com/davinta/device/enrollment/customerenrollmapper.json");
	
			//2. Get MySQL DB records 
			dbResult = DataSource.getData(Constants.FETCH_CUSTOMER_INFO,new Object[] {custID},Constants.ENROLLMENT);
			
			//3. Compare API response with DB 
			boolean result =  DataTransformUtil.compareApiResponseToDbRecords(jsonMap, dbResult, mappingRules,arrayName);
			
			return result;
		}
		else
			return true;
	}
	
	public static boolean deleteCustomer(String aadhaar){
		DataSource.deleteRecord(Constants.DELETE_EXISTING_CUSTOMER_SURVEY, new Object[] {aadhaar},Constants.ENROLLMENT);				
		DataSource.deleteRecord(Constants.DELETE_EXISTING_CUSTOMER, new Object[] {aadhaar},Constants.ENROLLMENT);	
		return true;
	}
	public static boolean deleteCustomerByMobile(String mobile){
		DataSource.deleteRecord(Constants.DELETE_EXISTING_CUSTOMER_SURVEY_BY_MOBILE, new Object[] {mobile},Constants.ENROLLMENT);				
		DataSource.deleteRecord(Constants.DELETE_EXISTING_CUSTOMER_BY_MOBILE, new Object[] {mobile},Constants.ENROLLMENT);	
		return true;
	}

}
