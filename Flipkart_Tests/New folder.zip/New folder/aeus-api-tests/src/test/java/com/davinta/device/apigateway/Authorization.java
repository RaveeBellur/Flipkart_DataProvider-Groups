package com.davinta.device.apigateway;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.apigatewaylayer.utils.DESCipherTest;
import com.davinta.apigatewaylayer.utils.HmacUtility;
import com.davinta.apigatewaylayer.utils.RsaActionAssist;
import com.davinta.databaseaccesslayer.utils.JsonUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.minidev.json.JSONObject;


public class Authorization {
    private static final Logger logger = LoggerFactory.getLogger(Authorization.class);
	//private static String secretKey = "1234123412341234";
    private static String secretKey = null; 
    
    public static String getAuthKey(Map<String, ?> payload){
    	if(secretKey == null)
    		setRandomSecretKey();
    	//System.out.println("Sec Key getAth key: "+secretKey);
    	String jsonBody = JsonUtil.disableHtmlEscaping(payload);
    	String authKeyHeader = HmacUtility.authKeyGenerator(jsonBody,secretKey);
    	logger.debug("Auth key header: {}", authKeyHeader);
    	return authKeyHeader;
    }
    
    public static String getClientInfo(Map<String, Object> payload) throws Exception{
    	if(secretKey == null)
    		setRandomSecretKey();
    	logger.debug("getClientInfo(): {}", payload.toString() );
    	//System.out.println("Sec Key client info: "+secretKey);
    	Gson gson = new GsonBuilder().disableHtmlEscaping().create();
    	String jsonBody = gson.toJson(payload);
    	DESCipherTest desCipherTest = new DESCipherTest();
    	String clientinfoKeyHeader = desCipherTest.clientInfoKey(jsonBody,secretKey);
    	logger.debug("Auth key header: {}", clientinfoKeyHeader);
    	return clientinfoKeyHeader;
    	
    }
    
    public static String getDesKey(Map<String, Object> payload) throws Exception{
    	if(secretKey == null)
    		setRandomSecretKey();
    	logger.debug("getDesKey() - payload: {}", payload.toString() );
    	//System.out.println("Sec Key geDesk Key: "+secretKey);
    	Map<String, String> map = (Map<String, String>) payload.get("keys");
    	String desKey = RsaActionAssist.desKeyGeneration(map.get("n"),map.get("e"),secretKey);
    	
    	logger.debug("getDesKey() - desKey: {}", desKey);
    	return desKey;
    }
	
    /*public static String generateRandomNumber(){
    	Random randomGenerator = new Random();
		String randNumber = ""; 
	    for (int idx = 1; idx <= 16; ++idx){
	    	int randomInt = randomGenerator.nextInt(10);
		     randNumber+=randomInt;	    	
	    }
	    char firstChar = randNumber.charAt(0);
	    if(firstChar =='0'){
	    	randNumber=randNumber.replace(randNumber.charAt(0),'1');
	    }	   	
	    return randNumber;
	}*/

    public static void setRandomSecretKey(){
    	Random randomGenerator = new Random();
		String randNumber = ""; 
	    for (int idx = 1; idx <= 16; ++idx){
	    	int randomInt = randomGenerator.nextInt(10);
		     randNumber+=randomInt;	    	
	    }
	    char firstChar = randNumber.charAt(0);
	    if(firstChar =='0'){
	    	randNumber=randNumber.replace(randNumber.charAt(0),'1');
	    }	   	
	    secretKey = randNumber;
	}
    
    public static boolean resetSecretKey(){
    	secretKey = null;
    	return true;
    }	
    
}

    