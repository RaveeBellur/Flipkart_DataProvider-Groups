package com.davinta.webdriver.main;

import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.davinta.webdriver.utils.TimeManager;
import com.davinta.webdriver.utils.TimeEntity;
import com.google.common.base.Function;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.PressesKeyCode; 
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.MobileBy;
import io.appium.java_client.android.AndroidDriver;
import java.time.Duration;


/**
 * @author Shivanand/Vijay Sreenivas
 * @throws   
 * @category
 * 
 */

public abstract class DevicePageObject extends LoadableComponent<DevicePageObject> {
	final static Logger logger = LoggerFactory.getLogger(DevicePageObject.class);
	DriverInitializer driverInitializer = DriverInitializer.getDriverInitializerInstance();
	public AppiumDriver deviceDriver;
	public void init() {
		this.deviceDriver=driverInitializer.getDeviceDriver();
		PageFactory.initElements(new AppiumFieldDecorator(deviceDriver), this);
	}

	// ================================================================================
	// Start of Appium core wrapper methods
	// ================================================================================


	public void closeAlert() {
		if (deviceDriver == null) {
			throwNullPointerExeptionForNullDriver();
		}
		if (deviceDriver.switchTo().alert() != null) {
			Alert alert = deviceDriver.switchTo().alert();
			alert.dismiss();
		}
	}

	public void click(By byLocator) {
		MobileElement element = findElement(byLocator);
		if (element == null) {
			logErrorForNotFindingElement(byLocator);
			return;
		}
		element.click();
	}

	public void click(MobileElement element) {
		if (element == null) {
			logErrorForNotFindingElement();
			return;
		}
		element.click();
	}

	public void click(By byLocator, int maxWaitTime) {
		MobileElement element = findElement(byLocator, maxWaitTime);
		if (element == null) {
			logErrorForNotFindingElement(byLocator);
			return;
		}
		element.click();
	}

	public void submit(By byLocator) {
		MobileElement element = findElement(byLocator);
		if (element == null) {
			logErrorForNotFindingElement(byLocator);
			return;
		}
		element.submit();
	}

	public void submit(By byLocator, int maxWaitTime) {
		MobileElement element = findElement(byLocator, maxWaitTime);
		if (element == null) {
			logErrorForNotFindingElement(byLocator);
			return;
		}
		element.submit();
	}

	public void type(String inputText, By byLocator) {
		MobileElement element = findElement(byLocator);
		if (element == null) {
			logErrorForNotFindingElement(byLocator);
			return;
		}
		element.sendKeys(inputText);
	}


	public void type(String inputText, MobileElement element) {
		if (element == null) {
			logErrorForNotFindingElement(element);
			return;
		}
		element.sendKeys(inputText);
	}

	public void clearAndType(String inputText, By byLocator) {
		clear(byLocator);
		type(inputText, byLocator);
	}

	public void clearAndType(String inputText, MobileElement element) {
		clear(element);
		type(inputText, element);
	}

	public void clear(By byLocator) {
		MobileElement element = findElement(byLocator);
		if (element == null) {
			logErrorForNotFindingElement(byLocator);
			return;
		}
		element.clear();
	}

	public void clear(MobileElement element) {
		if (element == null) {
			logErrorForNotFindingElement(element);
			return;
		}
		element.clear();
	}

	public boolean isDisplayed(By byLocator) {
		return isElementCurrentlyDisplayed(byLocator);
	}

	public boolean isDisplayed(By byLocator, int maxWaitTime) {
		for (int waitSoFar = 1; waitSoFar < maxWaitTime; waitSoFar++) {
			if (isElementCurrentlyDisplayed(byLocator)) {
				return true;
			}
			TimeManager.waitInSeconds(TimeEntity.SEC_1.getSeconds()); // Wait 1 second and try again.
		}
		if (isElementCurrentlyDisplayed(byLocator)) {
			return true;
		}
		return false;
	}

	private boolean isElementCurrentlyDisplayed(By byLocator) {
		MobileElement element = findElementThatIsPresent(byLocator, 0);
		if ((element != null) && element.isDisplayed()) {
			return true;
		}
		return false;
	}

	public boolean isEnabled(By byLocator) {
		return isElementCurrentlyEnabled(byLocator);
	}

	public boolean isEnabled(By byLocator, int maxWaitTime) {
		for (int waitSoFar = 1; waitSoFar < maxWaitTime; waitSoFar++) {
			if (isElementCurrentlyEnabled(byLocator)) {
				return true;
			}
			TimeManager.waitInSeconds(TimeEntity.SEC_1.getSeconds()); // Wait 1 second and try again.
		}
		if (isElementCurrentlyEnabled(byLocator)) {
			return true;
		}
		return false;
	}

	private boolean isElementCurrentlyEnabled(By byLocator) {
		MobileElement element = findElementThatIsPresent(byLocator, 0);
		if ((element != null) && element.isEnabled()) {
			return true;
		}
		return false;
	}

	public boolean isSelected(By byLocator) {
		MobileElement element = findElement(byLocator, 0);
		if ((element != null) && element.isSelected()) {
			return true;
		}
		return false;
	}

	public String getAttribute(By byLocator, String attribute) {
		MobileElement element = findElementThatIsPresent(byLocator, 0);
		if (element == null) {
			logErrorForNotFindingElement(byLocator);
			return "";
		}
		return element.getAttribute(attribute);
	}

	public String getText(By byLocator) {
		MobileElement element = findElementThatIsPresent(byLocator, 0);
		if (element == null) {
			logErrorForNotFindingElement(byLocator);
			return "";
		}
		return element.getText();
	}

	public String getText(WebElement element) {
		if (element == null) {
			logErrorForNotFindingElement();
			return "";
		}
		return element.getText();
	}

	public MobileElement findElement(By byLocator) {
		if (deviceDriver == null) {
			throwNullPointerExeptionForNullDriver();
		}
		MobileElement element;
		if (!isElementEnabledWithinWait(byLocator, 0)) {
			return null;
		}
		element = (MobileElement)deviceDriver.findElement(byLocator);
		return element;
	}

	public MobileElement findElement(By byLocator, int maxWaitTime) {
		if (deviceDriver == null) {
			throwNullPointerExeptionForNullDriver();
		}
		MobileElement element;
		if (!isElementEnabledWithinWait(byLocator, maxWaitTime)) {
			return null;
		}
		element = (MobileElement)deviceDriver.findElement(byLocator);
		return element;
	}

	private boolean isElementEnabledWithinWait(By byLocator, int maxWaitTime) {
		if (isWaitForSuccessful(ExpectedConditions.elementToBeClickable(byLocator), maxWaitTime)) {
			return true;
		}
		return false;
	}

	public MobileElement findElementThatIsVisible(By byLocator, int maxWaitTime) {
		if (deviceDriver == null) {
			throwNullPointerExeptionForNullDriver();
		}
		MobileElement element;
		if (!isElementVisibleWithinWait(byLocator, maxWaitTime)) {
			return null;
		}
		element = (MobileElement)deviceDriver.findElement(byLocator);
		return element;
	}

	public MobileElement findElementThatIsPresent(final By byLocator, int maxWaitTime) {
		if (deviceDriver == null) {
			throwNullPointerExeptionForNullDriver();
		}
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(deviceDriver).withTimeout(maxWaitTime, TimeUnit.SECONDS)
				.pollingEvery(200, TimeUnit.MILLISECONDS);

		try {
			return wait.until(new Function<WebDriver, MobileElement>() {
				public MobileElement apply(WebDriver webDriver) {
					List<MobileElement> elems = deviceDriver.findElements(byLocator);
					if (elems.size() > 0) {
						return elems.get(0);
					} else {
						return null;
					}
				}
			});
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * Element found via byLocator can be seen on the page.
	 */
	private boolean isElementVisibleWithinWait(By byLocator, int maxWaitTime) {
		if (isWaitForSuccessful(ExpectedConditions.visibilityOfElementLocated(byLocator), maxWaitTime)) {
			return true;
		}
		return false;
	}

	public List<MobileElement> findElements(By byLocator, int maxWaitTime) {
		if (deviceDriver == null) {
			throwNullPointerExeptionForNullDriver();
		}
		List<MobileElement> result;
		findElement(byLocator, maxWaitTime); // Look for the default first one
		// of the collection.
		result = deviceDriver.findElements(byLocator);
		return result;
	}

	public List<MobileElement> findElements(By byLocator) {
		if (deviceDriver == null) {
			throwNullPointerExeptionForNullDriver();
		}
		List<MobileElement> result;
		findElement(byLocator); // Look for the default first one of the
		// collection.
		result = deviceDriver.findElements(byLocator);
		return result;
	}

	private boolean isWaitForSuccessful(ExpectedCondition<WebElement> condition, Integer maxWaitTime) {
		if (deviceDriver == null) {
			throwNullPointerExeptionForNullDriver();
		}
		if (maxWaitTime == null) {
			maxWaitTime = 3;
		}
		WebDriverWait wait = new WebDriverWait(deviceDriver, maxWaitTime);
		try {
			wait.until(condition);
			return true;
		} catch (TimeoutException e) {
			return false;
		}
	}
	 
	public void scrollToElement(String eleTxtName){
	MobileElement scrollToText = (MobileElement) deviceDriver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(new UiSelector().text(\"" + eleTxtName + "\"));"));
	}
	
	public void scrollToElement(String eleTxtName,int instIndex){
		MobileElement scrollToText = (MobileElement) deviceDriver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(new UiSelector().textContains(\"" + eleTxtName + "\").instance(instIndex));"));
		}
		
	// ================================================================================
	// End of Appium core wrapper methods
	// ================================================================================

	// ================================================================================
	// Start of wait methods
	// ================================================================================

	public void waitUntilLoadedAndElementClickable(By locator) {
		WebDriverWait wait = new WebDriverWait(deviceDriver, TimeEntity.SEC_30.getSeconds());
		wait.until(ExpectedConditions.elementToBeClickable(locator));
	}

	public void waitUntilLoadedAndElementVisible(By locator) {
		WebDriverWait wait = new WebDriverWait(deviceDriver, TimeEntity.SEC_30.getSeconds());
		wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	}

	public void waitUntilElementPresent(By locator) {
		WebDriverWait wait = new WebDriverWait(deviceDriver, TimeEntity.SEC_30.getSeconds());
		wait.until(ExpectedConditions.presenceOfElementLocated(locator));
	}

	public void waitUntilLoadedAndTextPresentInElement(By locator, String text) {
		WebDriverWait wait = new WebDriverWait(deviceDriver, TimeEntity.SEC_30.getSeconds());
		wait.until(ExpectedConditions.textToBePresentInElementLocated(locator, text));
	}

	// ================================================================================
	// End of wait methods
	// ================================================================================

	// ================================================================================
	// Start of page action methods
	// ================================================================================

	public void hoverAndClick(MobileElement mainElement, MobileElement subElement) {
		Actions actions = new Actions(deviceDriver);
		actions.moveToElement(mainElement).moveToElement(subElement).click().build().perform();
	}

	public void doubleClick(MobileElement element) {
		Actions actions = new Actions(deviceDriver);
		actions.moveToElement(element).doubleClick().perform();
	}

	public void navigateBack() {
		deviceDriver.navigate().back();
	}

	public void navigateForward() {
		deviceDriver.navigate().forward();
	}

	public void refreshPage() {
		deviceDriver.navigate().refresh();
	}

	public void tap(MobileElement element){
		TouchAction touchAction=new TouchAction(deviceDriver);
		touchAction.tap(element).perform();
	}

	public void tap(int x,int y){
		TouchAction touchAction=new TouchAction(deviceDriver);
		touchAction.tap(x,y).perform();
	}
	public void tap(MobileElement element, int x,int y){
		TouchAction touchAction=new TouchAction(deviceDriver);
		touchAction.tap(element,x,y).perform();
	}

	public void longPress(MobileElement element){
		TouchAction touchAction=new TouchAction(deviceDriver);
		touchAction.longPress(element).perform().release();
	}

	public void swipeBasedOnCoordinates(int startx, int starty, int endx, int endy){
		TouchAction touchAction=new TouchAction(deviceDriver);
		touchAction.press(startx, starty).waitAction().moveTo(endx, endy).release().perform();
	}
	
	public void scrollDown() {
		int height = deviceDriver.manage().window().getSize().getHeight();
		int startx = 250;
		int starty = (int) ((height * 2) / 3);
		int endy = (int) (height / 3);
		TouchAction touchAction=new TouchAction(deviceDriver);
		touchAction.press(startx, starty).waitAction().moveTo(startx, endy).release().perform();
		
		}

	// ================================================================================
	// End of page action methods
	// ================================================================================	

	// ================================================================================
	// Start of page get/set data methods
	// ================================================================================

	public String getPageTitle() {
		return deviceDriver.getTitle();
	}

	public String getPageUrl() {
		return deviceDriver.getCurrentUrl();
	}

	// ================================================================================
	// End of page get/set data methods
	// ================================================================================

	// ================================================================================
	// Start of js helper methods
	// ================================================================================

	public void jsClick(By byLocator){
		MobileElement element = findElement(byLocator);
		((JavascriptExecutor) deviceDriver).executeScript("arguments[0].click();", element);
	}

	public void clickOnDeviceBackButton(){
		((PressesKeyCode) deviceDriver).pressKeyCode(AndroidKeyCode.BACK);
	} 

	public void hideKeyboard(){
		deviceDriver.hideKeyboard();
	}

	public void getKeyboard(){
		deviceDriver.getKeyboard();
	}
	
	// ================================================================================
	// End of js helper methods
	// ================================================================================

	
	// Logging
	// ================================================================================

	protected void logErrorForNotFindingElement(By byLocator) {
		logger.error("Could not find element based on locator: " + byLocator.toString());
	}

	protected void logErrorForNotFindingElement(WebElement element) {
		//logger.error("Could not find element based on locator: " + getBy("element").toString());
	}

	protected void logErrorForNotFindingElement() {
		logger.error("Element is null and can not be acted upon");
	}

	protected void throwNullPointerExeptionForNullDriver() {
		throw new NullPointerException(
				"The Driver object you are using is null.  Please make sure you are passing the correct driver instance into the PageObject.");
	}

}
