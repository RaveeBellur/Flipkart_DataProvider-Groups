package com.davinta.webdriver.main;

import java.io.File;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.CapabilityType;

import java.net.MalformedURLException;
import java.net.URL;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Cookie;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.webdriver.utils.EnvTaskManager;
import com.davinta.webdriver.utils.TimeManager;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.android.AndroidElement;
import org.openqa.selenium.WebElement;
import io.appium.java_client.MobileElement;
import io.appium.java_client.remote.AndroidMobileCapabilityType;

/**
 * @author rbellur/Shivanand/Vijay Sreenivas 
 * @throws   
 * @category
 * 
 */

public class DriverInitializer {
	final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	private static DriverInitializer driverInitializerInstance = null;

	private DriverInitializer() {}

	/** The WebDriver object */
	protected WebDriver driver;
	/** The Appium Server object*/
	protected AppiumDriverLocalService appiumService;
	/** The Device driver object */
	protected AppiumDriver deviceDriver;
		
	public static String NodePath="C:/Program Files/nodejs/node.exe";
	final static String userName = System.getProperty("user.name");
	public static String AppiumMainJs_Path="C:/Users/"+userName+"/AppData/Local/Programs/appium-desktop/resources/app/node_modules/appium/build/lib/main.js";
	
	public WebDriver getDriver() {
		return driver;
	}
	
	public AppiumDriverLocalService getAppiumServer(){
		return appiumService;
	}

	public AppiumDriver<WebElement> getDeviceDriver(){
		return deviceDriver;
	}

		public static DriverInitializer getDriverInitializerInstance(){
			if(driverInitializerInstance==null){
				driverInitializerInstance = new DriverInitializer();
			}
			return driverInitializerInstance;
		}

		public WebDriver getAppropriateDriver(String browsertype, String location) throws Exception {
			// WebDriver driver = null;
			if (browsertype.equalsIgnoreCase("firefox")) {
				EnvTaskManager.killProcess("geckodriver.exe");
				EnvTaskManager.killProcess("firefox.exe");
				TimeManager.waitInSeconds(5);
				System.setProperty("webdriver.gecko.driver", location + "/geckodriver.exe");
				DesiredCapabilities caps= new DesiredCapabilities();
				caps.setCapability("acceptInsecureCerts", true);
				FirefoxProfile profile = new FirefoxProfile();
				profile.setPreference("browser.helperApps.neverAsk.saveToDisk" , "application/octet-stream;application/csv;text/csv;application/vnd.ms-excel;application/zip;application/x-zip;application/x-zip-compressed;application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;"); 
				profile.setPreference("browser.helperApps.alwaysAsk.force", false);
				profile.setPreference("browser.download.manager.showWhenStarting",false);
				profile.setPreference("browser.download.folderList", 1); 
				// profile.setPreference("browser.download.dir","E:\\Downloads"); 
				caps.setCapability(FirefoxDriver.PROFILE, profile);
				driver = new FirefoxDriver(caps);
			} else if (browsertype.equalsIgnoreCase("Chrome")) {
				EnvTaskManager.killProcess("chromedriver.exe");
				EnvTaskManager.killProcess("chrome.exe");
				TimeManager.waitInSeconds(5);
				System.setProperty("webdriver.chrome.driver", location + "/chromedriver.exe");
				driver = new ChromeDriver();
			} else if (browsertype.equalsIgnoreCase("IE")) {
				EnvTaskManager.killProcess("iexplore.exe", "mshta.exe", "IEDriverServer.exe");
				TimeManager.waitInSeconds(5);
			}

			if (! browsertype.equalsIgnoreCase("firefox")) {
				driver.manage().window().maximize();
			}
			driver.manage().deleteAllCookies();

			logger.debug("is the browser session id null " + ((RemoteWebDriver) driver).getSessionId().toString());
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(120, TimeUnit.SECONDS);
			driver.manage().timeouts().setScriptTimeout(60, TimeUnit.SECONDS);

			return driver;
		}
		
		public AppiumDriverLocalService getAppropriateAppiumServer(){
			appiumService = AppiumDriverLocalService.buildService(new AppiumServiceBuilder()
			.usingDriverExecutable(new File(NodePath))
			.withAppiumJS(new File(AppiumMainJs_Path))
			.withIPAddress("0.0.0.0")
			.usingPort(4723));
			return appiumService;
		}

		public AppiumDriver getAppropriateDeviceDriver(String deviceName, String deviceType, String platformName, String packageName, String activityName ) throws MalformedURLException {
			if (deviceType.equalsIgnoreCase("android")) {
				TimeManager.waitInSeconds(5);
				DesiredCapabilities capabilities = new DesiredCapabilities();
				capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, platformName);
				capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, deviceName);
				capabilities.setCapability("appPackage", packageName);
				capabilities.setCapability("appActivity", activityName);
				capabilities.setCapability(AndroidMobileCapabilityType.UNICODE_KEYBOARD, true);
				capabilities.setCapability(AndroidMobileCapabilityType.RESET_KEYBOARD, false);
				capabilities.setCapability("autoDismissAlerts", true);
				deviceDriver = new AndroidDriver<>(new URL("http://0.0.0.0:4723/wd/hub"),capabilities);
				deviceDriver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				return deviceDriver;
			}
			else
			{
				return null;
			}
		}

		public void triggerURL(String URL) {
			if (driver != null) {
				try {
					driver.get(URL);
					System.out.println("Trigger URL: URL is loaded successfully");
					logger.debug("Trigger URL: URL is loaded successfully");
				} catch (Exception e) {
					System.out.println("Trigger URL: URL load failed");
					logger.debug("Trigger URL: URL load failed");
					e.printStackTrace();
				}

			} else {

			}
		}

		public void closeAllBrowsers() {
			try {
				if (driver != null) {
					driver.quit();
					logger.debug("Close Browser : Closing the browser");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public AppiumDriver closeApp() {
			try {
				if (deviceDriver != null) {
					deviceDriver.resetApp();
					deviceDriver.quit();
					logger.debug("Close App : Closing the app");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			return deviceDriver;
		}

		public void deleteCookie(Cookie cookie) {
			if (driver != null) {
				driver.manage().deleteCookie(cookie);
			} else {

			}
		}

		public void deleteAllCookies() {

			if (driver != null) {
				driver.manage().deleteAllCookies();
			} else {

			}
		}

	}
