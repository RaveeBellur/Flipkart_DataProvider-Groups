package com.davinta.databaseaccesslayer.service;

import java.util.HashMap;

//import static org.neo4j.helpers.collection.MapUtil.map;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.neo4j.driver.v1.Record;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.driver.v1.Value;

import com.davinta.databaseaccesslayer.common.Base;
import com.davinta.databaseaccesslayer.dao.DB;
import com.davinta.databaseaccesslayer.utils.Constants;
import com.davinta.databaseaccesslayer.utils.ResourceHelper;

/**
 * @author rbellur
 * @throws   
 * @category
 * 
 */

public class Test {
	public static void main(String[] args) {
		//testQuery();
		testNeoQuery();
	}
	
	public static void testNeoQuery() {
		
		String bankTerminalCode = "12345678";
        Map<String, Object> param  = new HashMap<String, Object>();
        param.put("bankTerminalCode",bankTerminalCode);

    	String query = Base.DB_QueriesMap.get(Constants.FETCH_TERMINAL);
    	List<Map<String,Map<String, Object>>> neoDbResult = NeoDataSource.getData(Constants.FETCH_TERMINAL,param,Constants.NEO4J);
        
    	System.out.println(neoDbResult);
	}	
	
	
	public static void testQuery() {
		String productType = "LIABILITY";
		int status  = 13;
		try {
			String query=Base.DB_QueriesMap.get(Constants.PRODUCT_DETAILS);
			String db_query=DB.prepareQuery(query, new Object[]{productType, status});
			List<List<Object>> result = DB.getDBValueInList(Constants.TRANSACTION, db_query);
			
			Object status2=null;
			
			if(result !=null && result.size()>0){
				 status2=result.get(0).get(18);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			// Connection closing
			ResourceHelper.closeQuitely();
		}
	}
		

}
