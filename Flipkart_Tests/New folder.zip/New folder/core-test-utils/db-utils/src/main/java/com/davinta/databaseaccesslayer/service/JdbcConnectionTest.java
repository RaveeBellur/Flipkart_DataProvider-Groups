package com.davinta.databaseaccesslayer.service;

 
import java.sql.*;
import java.util.*;

import org.apache.http.impl.execchain.MainClientExec;
import org.neo4j.driver.v1.Record;
import org.neo4j.driver.v1.Value;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

public class JdbcConnectionTest 
{
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		JdbcConnectionTest.jdbcConnectionExample1();
	}
	
    public static void jdbcConnectionExample1() throws ClassNotFoundException, SQLException
    {
    	Class.forName("org.neo4j.jdbc.Driver");
    	Connection con = DriverManager.getConnection("jdbc:neo4j:bolt://172.19.231.175:7687","neo4j","admin");
    	//String query = "MATCH (t:Terminal) where t.terminalId  = {1} RETURN t";
    	String query = "MATCH (t:Terminal) where t.bankTerminalCode ={1} RETURN t";

    	
    	Iterator<Map<String, Object>> dbResultIterator  = query(query,con);
    	
    	while (dbResultIterator.hasNext()) {
    		Map<String, Object> map = dbResultIterator.next();

    		Iterator it = map.entrySet().iterator();
		    while (it.hasNext()) {
		    	Map.Entry pair = (Map.Entry)it.next();
		        System.out.println(pair.getKey() + " ::: " + pair.getValue());
			    //it.remove(); // avoids a ConcurrentModificationException

		        //Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		        Gson gson = new Gson();
		        Map<String, Object> map1 = new HashMap<String, Object>();
		        
		        map1 = (Map<String, Object>)gson.fromJson(gson.toJson(pair.getValue()), map.getClass());
		        
		        Iterator it2 = map1.entrySet().iterator();
		        while (it2.hasNext()) {
		            Map.Entry pair2 = (Map.Entry)it2.next();
		            System.out.println(pair2.getKey() + " = " + pair2.getValue());
		            it2.remove(); // avoids a ConcurrentModificationException
		        }
		        
		        
		        
		    }
    	}    
	 
    	
   }

    public static void jdbcConnectionExample2( ) throws ClassNotFoundException, SQLException 
    {
    	Class.forName("org.neo4j.jdbc.Driver");
    	Connection con = DriverManager.getConnection("jdbc:neo4j:bolt://172.19.231.175:7687","neo4j","admin");
    	String query = "MATCH (a:Agent)-[HAS_TERMINAL]->(t:Terminal) where a.entityState =\"ACTIVE\" AND a.userId = {1} RETURN a,t";
	    
    	Iterator<Map<String, Object>> dbResultIterator  = query(query,con);
    	
    	while (dbResultIterator.hasNext()) {
    		Map<String, Object> map = dbResultIterator.next();

    		Iterator it = map.entrySet().iterator();
		    while (it.hasNext()) {
		    	Map.Entry pair = (Map.Entry)it.next();
		        System.out.println(pair.getKey() + " ::: " + pair.getValue());
			    //it.remove(); // avoids a ConcurrentModificationException

		        //Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		        Gson gson = new Gson();
		        Map<String, Object> map1 = new HashMap<String, Object>();
		        map1 = (Map<String, Object>)gson.fromJson(gson.toJson(pair.getValue()), map.getClass());
		        
		        Iterator it2 = map1.entrySet().iterator();
		        while (it2.hasNext()) {
		            Map.Entry pair2 = (Map.Entry)it2.next();
		            System.out.println(pair2.getKey() + " = " + pair2.getValue());
		            it2.remove(); // avoids a ConcurrentModificationException
		        }
		        
		    }
    	}    
   }

     public static Iterator<Map<String, Object>> query(String query,Connection conn) {
        try {
            final PreparedStatement statement = conn.prepareStatement(query);
            //setParameters(statement, params);
           
            
            //statement.setString(1,"TE000001");
           // statement.setString(1,"AG000002");
            statement.setString(1,"12345678");
            
            
            final ResultSet result = statement.executeQuery();
            return new Iterator<Map<String, Object>>() {

                boolean hasNext = result.next();
                public List<String> columns;

                @Override
                public boolean hasNext() {
                    return hasNext;
                }

                private List<String> getColumns() throws SQLException {
                    if (columns != null) return columns;
                    ResultSetMetaData metaData = result.getMetaData();
                    int count = metaData.getColumnCount();
                    List<String> cols = new ArrayList<>(count);
                    for (int i = 1; i <= count; i++) cols.add(metaData.getColumnName(i));
                    return columns = cols;
                }

                @Override
                public Map<String, Object> next() {
                    try {
                        if (hasNext) {
                            Map<String, Object> map = new LinkedHashMap<>();
                            for (String col : getColumns()) map.put(col, result.getObject(col));
                            hasNext = result.next();
                            if (!hasNext) {
                                result.close();
                                statement.close();
                            }
                            return map;
                        } else throw new NoSuchElementException();
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                }

                @Override
                public void remove() {
                }
            };
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }






     private void setParameters(PreparedStatement statement, Map<String, Object> params) throws SQLException {
         for (Map.Entry<String, Object> entry : params.entrySet()) {
             int index = Integer.parseInt(entry.getKey());
             statement.setObject(index, entry.getValue());
         }
     }






}
