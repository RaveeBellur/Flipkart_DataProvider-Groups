package com.davinta.databaseaccesslayer.exception;

/**
 * @author rbellur
 *
 */
public class JsonDatabaseCompareException extends Exception {

	/**
	 * @param string
	 */
	public JsonDatabaseCompareException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

	public JsonDatabaseCompareException(Exception e) {
		// TODO Auto-generated constructor stub
		super(e);
	}

}
