package com.davinta.databaseaccesslayer.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Type;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Time;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.databaseaccesslayer.common.Base;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * @author rbellur
 * @throws   
 * @category
 * 
 */

public class Convert{

    private static final Logger logger = LoggerFactory.getLogger(Convert.class);

	public static List<List<Object>> toList(java.sql.ResultSet rs){
		List<List<Object>> list= new ArrayList<List<Object>>();
		try{
		if(rs!=null){
		ResultSetMetaData rsmd=rs.getMetaData();
		int noOfCols=rsmd.getColumnCount();
		while(rs.next()){
			List<Object> RowList= new ArrayList<Object>();
			for (int i = 1; i <= noOfCols; i++){
				RowList.add(rs.getObject(i));
			}
			list.add(RowList);
		}
		}
		else{
			logger.info("ResultSet pointing to Null");
		}
		}catch (SQLException e) {
			logger.error("Error while converting ResultSet to List");
		}
		finally{
			
				try {
					if(rs!=null)
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return list;
	}
	
	public static List<Map<String,Object>> toListOfMap(java.sql.ResultSet rs){
		List<Map<String, Object>> list= new ArrayList<Map<String,Object>>();
		try{
		if(rs!=null){
		ResultSetMetaData rsmd=rs.getMetaData();
		int noOfCols=rsmd.getColumnCount();
		while(rs.next()){
			Map<String,Object> RowMap= new HashMap<String,Object>();
			for (int i = 1; i <= noOfCols; i++){
				RowMap.put(rsmd.getColumnName(i),rs.getObject(i));
			}
			list.add(RowMap);
		}
		}
		else{
			logger.info("ResultSet pointing to Null");
		}
		}catch (SQLException e) {
			logger.error("Error while converting ResultSet to Map");
		}
		finally{
			
				try {
					if(rs!=null)
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return list;
	}

	public static List<Map<String,Map<String, Object>>> toListOfMapOfMap(Iterator<Map<String,Object>>  dbResult){
		if (dbResult==null) return Collections.emptyList(); 

		List<Map<String,Map<String, Object>>> list = new ArrayList<Map<String,Map<String, Object>>>();
		
		while (dbResult.hasNext()) {
			logger.debug("Iterating DB result");
			Map<String,Map<String, Object>> nodeMap = new HashMap<String,Map<String, Object>>();
    		
			//get the node
			Map<String, Object> map = dbResult.next();
    		Iterator it = map.entrySet().iterator();
		    while (it.hasNext()) {
		    	Map.Entry pair = (Map.Entry)it.next();	
				logger.debug("node name: {} :: node value: {}", pair.getKey(), pair.getValue());
		        //convert the node->row->properties from json to map
		        Gson gson = new Gson();
		        Type type = new TypeToken<Map<String, Object>>(){}.getType();
		        //convert to db row to json representation
		        String dbRow = gson.toJson(pair.getValue());
				logger.debug("db row found: {}",dbRow);
		        //convert json to map
		        Map<String, Object> propertyMap = (Map<String, Object>)gson.fromJson(dbRow, type);
				logger.debug("property map: {}",propertyMap);
		        System.out.println(propertyMap);
		        nodeMap.put(pair.getKey().toString(), propertyMap);
		        
		    }
		    list.add(nodeMap);
		}	
		return list;
	}

	public static int extractIntValues(String input){
		Pattern p = Pattern.compile("(\\d+)");
	    Matcher m = p.matcher(input);
	    Integer j = null;
	    if (m.find()) {
	        j = Integer.valueOf(m.group(1));
	    }
	    return j;
	}
	
	
	public static String processQuery(String query,String replaceValue){
    	return (query!=null?(query.replaceAll("@@@@",replaceValue)).trim():"");	
    }
	
	public static  String formatDate(Date date  )   {  
	      DateFormat df = new SimpleDateFormat( "yyyy-MM-dd" ) ; 
	      return ( df.format(date)  ) ;   
	}
	
	public static int StringToInt(String value){
		if(value==null||value.equalsIgnoreCase(""))
			return 0;
		else
			return Integer.parseInt(value.trim());
	}
	
}
