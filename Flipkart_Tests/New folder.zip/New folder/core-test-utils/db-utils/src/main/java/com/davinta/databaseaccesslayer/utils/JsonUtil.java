package com.davinta.databaseaccesslayer.utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.stream.JsonReader;

public class JsonUtil {
    private static final Logger logger = LoggerFactory.getLogger(JsonUtil.class);

    public static JsonReader jsonReader(String fileName) {
		JsonReader reader = null;
		try {
			reader = new JsonReader(new FileReader(fileName));
		} catch (FileNotFoundException e) {
			logger.error(e.getMessage());
		}
		return reader;
	}

	public static String disableHtmlEscaping(Map<String, ?> payload) {
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		return gson.toJson(payload);
	}

	public static String toJson(Object src) {
		Gson gson = new Gson();
		return gson.toJson(src);
	}
	
	
}
