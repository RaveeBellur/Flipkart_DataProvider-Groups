package com.davinta.databaseaccesslayer.utils;

/**
 * @author rbellur
 *
 */
public class JsonToDbMapping {

	private String jsonPath;
	private String databaseField;
	private String dataType;
	private String format;

	public String getJsonPath() {
		return jsonPath;
	}

	public String getDatabaseField() {
		return databaseField;
	}

	public String getDataType() {
		return dataType;
	}

	public String getFormat() {
		return format;
	}
}