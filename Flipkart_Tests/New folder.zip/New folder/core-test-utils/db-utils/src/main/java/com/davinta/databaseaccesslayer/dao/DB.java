package com.davinta.databaseaccesslayer.dao;

import java.lang.reflect.Type;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.Format;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.neo4j.driver.v1.StatementResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.databaseaccesslayer.executor.BoltCypherExecutor;
import com.davinta.databaseaccesslayer.executor.CypherExecutor;
import com.davinta.databaseaccesslayer.utils.Constants;
import com.davinta.databaseaccesslayer.utils.Convert;
import com.davinta.databaseaccesslayer.utils.JsonUtil;
import com.davinta.databaseaccesslayer.utils.ResourceHelper;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * @author rbellur
 * @throws   
 * @category
 * 
 */

public class DB {
    private static final Logger logger = LoggerFactory.getLogger(DB.class);

	/**
	 * Returns the String object, which is Query by substitute values
	 * The Query and args [Object []]. 
	 * <p>
	 * This method always returns String. When this method attempts to return the String,
	 * by replacing the argument in the given Querry.  
	 *
	 * @param  query	String
	 * @param  args		String
	 * @return      	String object which is query for the provided query with values
	 * @see         	String
	 */
	public static String prepareQuery(String query, Object[] args) {
		query = MessageFormat.format(query, args);
		if(query.contains("where")){
			String queryArr[] = query.split("where");
			queryArr[0]=queryArr[0].replaceAll("'", "");
			
			String whereArr[]=queryArr[1].split("=");
			whereArr[0]=whereArr[0].replaceAll("'", "");
			
			
			
			query = queryArr[0].trim()+" where "+whereArr[0]+" ="+whereArr[1];
		}else if(query.contains("from")){
			String queryArr[] = query.split("from");
			queryArr[0]=queryArr[0].replaceAll("'", "");
			query = queryArr[0].trim()+" from "+queryArr[1].trim();
		}
	return query;
	}
	
	public static String prepareQuery(String flag,String query, Object[] args) {
		query = MessageFormat.format(query, args);
		//String org = query;
		//String rep = org.subSting(0,org.indexOf("where"));
		query = query.replaceAll("'","");
		return query;
	}

	public static List<List<Object>> getDBValueInList(String conName,String query){
		List<List<Object>> resultList=null;
		ResourceHelper rsh=new ResourceHelper();
		ResultSet rs= rsh.executeQuery(ResourceHelper.getConnection(conName),query);
		if(rs!=null){
			 resultList=Convert.toList(rs);
		}
		ResourceHelper.closeStatement();
		return resultList; 
	}
	
	public static List<Map<String,Object>> getDBValueInMap(String conName, String query){
		List<Map<String,Object>> resultMap = null;
		ResourceHelper rsh = new ResourceHelper();
		ResultSet rs= rsh.executeQuery(ResourceHelper.getConnection(conName),query);
		if(rs!=null){
			resultMap=Convert.toListOfMap(rs);
		}
		ResourceHelper.closeStatement();
		return resultMap; 
	}

/*	public static StatementResult getNeoDBValueInMap(String conName, String query){
		List<HashMap<String,Object>> resultMap = null;
		ResourceHelper rsh = new ResourceHelper();
		StatementResult sr= rsh.executeNeoQuery(ResourceHelper.getNeoSession(conName),query);
		if(sr!=null){
			//resultMap=Convert.toListOfMap(sr);
		}
		return sr; 
	}*/
	
	public static List<Map<String,Map<String, Object>>> getNeoDBValueInMap(String query, Map<String, Object> param,String dbName){
		List<Map<String,Map<String, Object>>> resultMap = null;
		CypherExecutor cypher = new BoltCypherExecutor();
		Iterator<Map<String,Object>> collection = cypher.executeQuery(dbName,query,param);
		if(collection!=null){
			resultMap=Convert.toListOfMapOfMap(collection);
		}
		cypher.closeQuitely();
		return resultMap; 
	}

	//For MySQL delete
	public static Boolean deleteRecord(String conName,String query){
		ResourceHelper rsh=new ResourceHelper();
		try{
			rsh.executeDeleteQuery(ResourceHelper.getConnection(conName),query);
			return true;
		}catch (Exception e) {
			return false;
		}finally{
			ResourceHelper.closeStatement();
		}
	}
	
	//Neo4j query execute
	public static Boolean executecypherQuery(String query, Map<String, Object> param,String dbName){
		CypherExecutor cypher = new BoltCypherExecutor();
		try{
			Boolean result = cypher.runQuery(dbName,query,param);
			cypher.closeQuitely();
			return result;
		}catch (Exception e) {
			return false;
		}
	}
	
	/**
	 * Returns the String Object. 
	 * . 
	 * <p>
	 * This method will convert the given Date value to formated Date String.\
	 * so that we can use it further without any modification  
	 *
	 * @param  date   	Date Object 
	 * @return      	Object
	 * @throws 			SQLException, IOException 
	 * @see         	Object
	 */
	private static Object formatDate(java.sql.Timestamp date) {
		Format formatter = new SimpleDateFormat(Constants.DATE_FORMAT);    
		String formattedDate = formatter.format(date);
		return formattedDate;
	}

}
