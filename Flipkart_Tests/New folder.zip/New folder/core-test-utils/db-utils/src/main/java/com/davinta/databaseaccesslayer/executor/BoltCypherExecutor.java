package com.davinta.databaseaccesslayer.executor;

import org.neo4j.driver.v1.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.databaseaccesslayer.utils.ConProperties;
import com.davinta.databaseaccesslayer.utils.Constants;
import java.io.FileInputStream;
import java.sql.Connection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * @author rbellur
 */

public class BoltCypherExecutor implements CypherExecutor {
	private static final Logger logger = LoggerFactory.getLogger(BoltCypherExecutor.class);

	private static Properties properties = new Properties();
	
	private static Driver neoDriver = null;	
	private static ConProperties neo4j=new ConProperties();
	
	static{
		try {
			properties.load(new FileInputStream("./config/Neo4j_DB.properties"));
			neo4j.setDrivers(properties.getProperty("db.driver"));
			neo4j.setUrl(properties.getProperty("db.url"));
			neo4j.setUserName(properties.getProperty("db.username"));
			neo4j.setPassword(properties.getProperty("db.password"));
		} catch (Exception e) {
			logger.error(".An Exception occurred while loading the Neo4j_DB.properties file."+ e);
		}
	}
	
	public static Driver getDriver(String dbName){
		if(dbName.equalsIgnoreCase(Constants.NEO4J)){
			neoDriver = GraphDatabase.driver(properties.getProperty("db.url"),
							AuthTokens.basic(properties.getProperty("db.username"), 
							properties.getProperty("db.password")));
		}
		return neoDriver;
	}
	
    @Override
    public Iterator<Map<String, Object>> executeQuery(String dbName,String query, Map<String, Object> params) {
    	BoltCypherExecutor.getDriver(dbName);
    	
        try (Session session = neoDriver.session()) {
        	logger.info("Params: {}",params);
        	logger.info("Executing Query: {}", query);
        	 List<Map<String, Object>> list = session.run(query, params)
                     .list( r -> r.asMap(BoltCypherExecutor::convert));
             return list.iterator();
        }
    }
    
    static Object convert(Value value) {
        switch (value.type().name()) {
            case "PATH":
                return value.asList(BoltCypherExecutor::convert);
            case "NODE":
            case "RELATIONSHIP":
                return value.asMap();
        }
        return value.asObject();
    }

    @Override
	public void closeQuitely(){
        logger.info("Closing Db connection........");
		if(neoDriver!=null){
			neoDriver.close();
	    }
    }
	
    @Override
    public Boolean runQuery(String dbName,String query, Map<String, Object> params) {
    	BoltCypherExecutor.getDriver(dbName);
    	
        try (Session session = neoDriver.session()) {
        	logger.info("Params: {}",params);
        	logger.info("Executing Query: {}", query);
        	session.run(query, params);
             return true;
        }catch (Exception e) {
			return false;
		}
    }
}
