package com.davinta.databaseaccesslayer.utils;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.neo4j.driver.v1.AuthTokens;
import org.neo4j.driver.v1.Driver;
import org.neo4j.driver.v1.GraphDatabase;
import org.neo4j.driver.v1.Session;
import org.neo4j.driver.v1.StatementResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author rbellur
 * @throws NamingException 
 * @throws SQLException 
 * @category Load driver ,registering driver with data base ,returning connection and statement
 * 
 */

public class ResourceHelper {
			private static final Logger logger = LoggerFactory.getLogger(ResourceHelper.class);

			private static Properties properties = new Properties();
			
			private static Connection  transactionCon = null;
			private static Connection  enrollmentCon = null;
			private static Connection mifosCon = null;
			private static Connection groupmanagementCon = null;

			private static ConProperties transaction=new ConProperties();
			private static ConProperties enrollment=new ConProperties();
			private static ConProperties mifos=new ConProperties();
			private static ConProperties groupmanagement=new ConProperties();
			private static ConProperties neo4j=new ConProperties();

/*			private static Driver neoDriver = null;;	
			private static Session neoSession = null;;
*/			
			private static ResourceHelper rs=new ResourceHelper();
			
			private static Statement stmt=null;
			
			
	static{
		
		try {
			// Reading Transaction DB Details
			properties.load(new FileInputStream("./config/Transaction_DB.properties"));
			transaction.setDrivers(properties.getProperty("db.driver"));
			transaction.setUrl(properties.getProperty("db.url"));
			transaction.setDatabaseName(properties.getProperty("db.databaseName"));
			transaction.setUserName(properties.getProperty("db.username"));
			transaction.setPassword(properties.getProperty("db.password"));
		} catch (Exception e) {
			logger.error("An Exception occurred while loading the Transaction_DB.properties file."+ e);
		}
		
		try {
			properties.load(new FileInputStream("./config/Enrollment_DB.properties"));
			enrollment.setDrivers(properties.getProperty("db.driver"));
			enrollment.setUrl(properties.getProperty("db.url"));
			enrollment.setDatabaseName(properties.getProperty("db.databaseName"));
			enrollment.setUserName(properties.getProperty("db.username"));
			enrollment.setPassword(properties.getProperty("db.password"));
		} catch (Exception e) {
			logger.error("An Exception occurred while loading the Enrollment_DB.properties file."+ e);
		}
		
		try {
			properties.load(new FileInputStream("./config/Mifos_DB.properties"));
			mifos.setDrivers(properties.getProperty("db.driver"));
			mifos.setUrl(properties.getProperty("db.url"));
			mifos.setDatabaseName(properties.getProperty("db.databaseName"));
			mifos.setUserName(properties.getProperty("db.username"));
			mifos.setPassword(properties.getProperty("db.password"));
		} catch (Exception e) {
			logger.error("An Exception occurred while loading the Mifos_DB.properties file."+ e);
		}
		try {
			properties.load(new FileInputStream("./config/GroupManagement_DB.properties"));
			groupmanagement.setDrivers(properties.getProperty("db.driver"));
			groupmanagement.setUrl(properties.getProperty("db.url"));
			groupmanagement.setDatabaseName(properties.getProperty("db.databaseName"));
			groupmanagement.setUserName(properties.getProperty("db.username"));
			groupmanagement.setPassword(properties.getProperty("db.password"));
		} catch (Exception e) {
			logger.error("An Exception occurred while loading the GroupManagement_DB.properties file."+ e);
		}
		
/*		try {
			properties.load(new FileInputStream("./config/Neo4j_DB.properties"));
			neo4j.setDrivers(properties.getProperty("db.driver"));
			neo4j.setUrl(properties.getProperty("db.url"));
			neo4j.setUserName(properties.getProperty("db.username"));
			neo4j.setPassword(properties.getProperty("db.password"));
		} catch (Exception e) {
			logger.error(".An Exception occurred while loading the Neo4j_DB.properties file."+ e);
		}*/
	}
	
	public static Connection getConnection(String dbName){
		if(dbName!=null){
			return rs.getConection(dbName);
		}else{
			return null;
		}
	}
	
	private synchronized Connection getConection(String dbName){
		Connection con=null;
		try{
			if(dbName.equalsIgnoreCase(Constants.TRANSACTION)){
				if(transactionCon==null){
					Class.forName(transaction.getDrivers());
					transactionCon=DriverManager.getConnection(getConnectionUrl(transaction),transaction.getUserName(),transaction.getPassword());
					con=transactionCon;
				}else{
					con=transactionCon;
				}
			}
			else if(dbName.equalsIgnoreCase(Constants.ENROLLMENT)){
				    if(enrollmentCon==null){
				    	Class.forName(enrollment.getDrivers());
				    	enrollmentCon=DriverManager.getConnection(getConnectionUrl(enrollment),enrollment.getUserName(),enrollment.getPassword());
				    	con=enrollmentCon;
					}else{
						con=enrollmentCon;
					}
			}
			else if(dbName.equalsIgnoreCase(Constants.MIFOS)){
			    if(mifosCon==null){
			    	Class.forName(mifos.getDrivers());
			    	mifosCon=DriverManager.getConnection(getConnectionUrl(mifos),mifos.getUserName(),mifos.getPassword());
			    	con=mifosCon;
				}else{
					con=mifosCon;
				}
		}
			else if(dbName.equalsIgnoreCase(Constants.GROUPMANAGEMENT)){
			    if(groupmanagementCon==null){
			    	Class.forName(groupmanagement.getDrivers());
			    	groupmanagementCon=DriverManager.getConnection(getConnectionUrl(groupmanagement),groupmanagement.getUserName(),groupmanagement.getPassword());
			    	con=groupmanagementCon;
				}else{
					con=groupmanagementCon;
				}
		}
			
		}catch(ClassNotFoundException cn){
			logger.error("Unable to Load Driver Class: {}",cn);
		}catch(SQLException sq){
			logger.error("Data Base Error Unable to get Connection: ",sq);
		}
		return con;
    }
	
/*	public static Session getNeoSession(String dbName){
		if(dbName!=null){
			return rs.getNeoSesion(dbName);
		}else{
			return null;
		}
	}
	
	private synchronized Session getNeoSesion(String dbName){
		Session session=null;
		try {
			if(dbName.equalsIgnoreCase(Constants.NEO4J)){
				if(neoDriver==null){
					//Class.forName(neo4j.getDrivers());
					neoDriver = GraphDatabase.driver(properties.getProperty("db.url"),
									AuthTokens.basic(properties.getProperty("db.username"), 
									properties.getProperty("db.password")));
					neoSession =neoDriver.session();
					session=neoSession;
				} else {
		    	session=neoSession;
				}
			}  
		} catch (Exception cn) {
			logger.error("Unable to Load Driver Class: {}" ,cn);
		}
		return session;
	}*/
	
	private String  getConnectionUrl(ConProperties dbDetails) {
		//return dbDetails.getUrl()+dbDetails.getServerName()+":"+dbDetails.getPortNumber()+":"+dbDetails.getDatabaseName();
		return dbDetails.getUrl()+dbDetails.getDatabaseName();
	}
	
	public static Statement getStatement(Connection con){
		Statement st=null;
		if( con!=null){
		try{
    		 st=con.createStatement();
    	}
    	catch (SQLException e) {
    		logger.error("Error while creating Statement: {}" ,e);
		}}
        return st;
    }
	
	public static void closeStatement(){
		try{
			if(stmt!=null)
    		 stmt.close();
    	}
    	catch (SQLException e) {
    		logger.error("Error while closing Statement: {}" ,e);
		}
        
    }
	
	
	public static PreparedStatement getPrepareStatement(Connection con,String query){
		PreparedStatement pstmt=null;
		if( con!=null){
		try{
    		 pstmt=con.prepareStatement(query);
    	}
    	catch (SQLException e) {
    		logger.error("Error while creating PrepareStatement: {}",e);
		}}
        return pstmt;
    }
	
	
	
	public static void closeQuitely(String dbName){
        logger.debug("Closing Db connection........");
        if(dbName!=null){
			Connection con=null;
			if(dbName.equalsIgnoreCase(Constants.TRANSACTION)){
				con=transactionCon;
				transactionCon=null;
			}
			try{
				if(con!=null)
					con.close();
			}catch( SQLException ignored) { 
				logger.error("Problem in closing connection: {}",ignored);
			} 
			finally{
				con = null;
			}
		}
	}
	
	public static void closeQuitely(ResultSet rs){
        logger.debug("Closing Db connection........");
		try{
			if(rs!=null){
		         rs.close();
		        }
		}catch( SQLException ignored) { 
			logger.error("Problem in closing ResultSet: {}",ignored);
	        } 
	    finally{
	         rs = null;
	    }
	}
	
	public static void closeQuitely(Statement stmt){
        logger.debug("Closing Db connection........");
		try{
			if(stmt!=null){
				stmt.close();
		        }
		}catch( SQLException ignored) { 
			logger.error("Problem in closing Statement: {}",ignored);
	        } 
	    finally{
	    	stmt = null;
	    }
	}
	
	public static void closeQuitely(Connection con,Statement stmt,ResultSet rs){
        logger.debug("Closing Db connection........");
		try 
        {  
     	   if(stmt!=null){
     		   stmt.close();
     	   }
        if(rs!=null){
            rs.close();
        }
           
        if(con!=null){
         con.close();
        }
        }

        catch( SQLException ignored)  
        {
        	logger.error("Problem in closing con,rs,statement");
        } 
        finally{
            con = null;
            stmt=null;
            rs=null;
        }
	}
	
	public static void closeQuitely(){
        logger.debug("Closing Db connection........");
        try 
        { 
	        if(transactionCon!=null){
	        	transactionCon.close();
	        }
	        if(enrollmentCon!=null){
	        	enrollmentCon.close();
	        }
/*	        if(neoSession!=null){
	        	neoSession.close();
	        }
	        if(neoDriver!=null){
	        	neoDriver.close();
	        }*/
        }
        catch( SQLException ignored)  
        {
        	logger.error("Problem in closing Data Base Connections: {}",ignored);
        } 
        finally{
        	transactionCon = null;
        	enrollmentCon=null;         
    /*    	neoSession = null;
        	neoDriver = null;*/

        }
	}
	
	public  ResultSet executeQuery(Connection con,String query){
		stmt=getStatement(con);
		ResultSet rs=null;
		if( stmt!=null){
		try{
			 logger.info("Executing Query : {}",query);
    		 rs= stmt.executeQuery(query);
//    		 stmt.close();
    	}
    	catch (SQLException e) {
    		logger.error(Constants.FAILED_QUERY+query);
    		logger.error("Error while getting ResultSet --> {} ",e.getMessage());
		}}
        return rs;
    }

	public  ResultSet executeQuery(String conName,String query){
		Connection con = getConnection(conName);
		stmt=getStatement(con);
		ResultSet rs=null;
		if( stmt!=null){
		try{
			 logger.info("Executing Query: {}",query);
			 rs= stmt.executeQuery(query);
//			 stmt.close();
		}
		catch (SQLException e) {
			logger.error(Constants.FAILED_QUERY+query);
			logger.error("Error while getting ResultSet --> {}",e.getMessage());
		}}
	    return rs;
	}

	public void executeDeleteQuery(Connection con,String query){
		stmt=getStatement(con);
		if( stmt!=null){
		try{
			 logger.info("Executing Query : {}",query);
    		 stmt.execute(query);
    	}
    	catch (SQLException e) {
    		logger.error(Constants.FAILED_QUERY+query);
    		logger.error("Error while executing Query --> {}",e.getMessage());
		}}
    }
	
	public StatementResult executeNeoQuery(Session session,String query){
		StatementResult sr=null;
		logger.info("Executing Neo Query : {}", query);
		sr = session.run(query);
        return sr;
    }

}
