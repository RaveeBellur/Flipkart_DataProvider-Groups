package com.davinta.databaseaccesslayer.service;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.databaseaccesslayer.common.Base;
import com.davinta.databaseaccesslayer.dao.DB;
import com.davinta.databaseaccesslayer.utils.Constants;
import com.davinta.databaseaccesslayer.utils.Convert;
import com.davinta.databaseaccesslayer.utils.DataTransformUtil;
import com.davinta.databaseaccesslayer.utils.JsonUtil;
import com.davinta.databaseaccesslayer.utils.ResourceHelper;
import com.google.gson.stream.JsonReader;

/**
 * @author rbellur
 * @throws   
 * @category
 * 
 */

public class DataSource {
    private static final Logger logger = LoggerFactory.getLogger(DataSource.class);

	public static List<Map<String, Object>> getData(String queryConstant, Object[] param, String dbName) throws Throwable {
		List<Map<String, Object>> dbResult = null;
 		
		//Query DB
		String query = Base.DB_QueriesMap.get(queryConstant);
		String db_query = DB.prepareQuery(query, param);
		dbResult = DB.getDBValueInMap(dbName, db_query);

		ResourceHelper.closeQuitely();
		
		return dbResult;
	}
	
	public static List<Map<String, Object>> getDataForDataTable(String queryConstant, Object[] param, String dbName) throws Throwable {
		List<Map<String, Object>> dbResult = null;
 		
		//Query DB
		String query = Base.DB_QueriesMap.get(queryConstant);
		String db_query = DB.prepareQuery("DB",query, param);
		dbResult = DB.getDBValueInMap(dbName, db_query);

		ResourceHelper.closeQuitely();
		
		return dbResult;
	}
	
	public static Boolean deleteRecord(String queryConstant, Object[] param, String connectionName) {
		Boolean result;
		try{
			//Query DB
			String query = Base.DB_QueriesMap.get(queryConstant);
			String db_query = DB.prepareQuery(query, param);
			result = DB.deleteRecord(connectionName, db_query);

		} catch (Exception e) {
			logger.debug("Exception : "+e);
			return false;
		} finally {
			ResourceHelper.closeQuitely();
		}
		return true;	
	}
	
}
