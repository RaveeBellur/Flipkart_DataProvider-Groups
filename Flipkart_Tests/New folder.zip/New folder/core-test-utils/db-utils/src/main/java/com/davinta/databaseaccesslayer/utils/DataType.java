package com.davinta.databaseaccesslayer.utils;

public enum DataType  {
	String,
	Special,
	Date,
	Varchar,
	Double,		
	Number,
	Other
}


