package com.davinta.databaseaccesslayer.utils;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.databaseaccesslayer.common.Base;
import com.davinta.databaseaccesslayer.dao.DB;

/**
 * @author rbellur
 * @throws   
 * @category
 * 
 */

public class RecordFinder {

    private static final Logger logger = LoggerFactory.getLogger(RecordFinder.class);

    public static boolean waitForExistence(String query,String db,String description,String waitingTime) throws InterruptedException{
		boolean flag=false;
		long waitTime=Long.parseLong(waitingTime);
		logger.info("Database check in progress...");
		System.out.println("Database check in progress...");
		for(int i=1;i<=20;i++){
			List<List<Object>> result=DB.getDBValueInList(db, query);
			if(result.size()==0){
				logger.info("");
				logger.info("Test Attempt '"+i+"' Waiting for Existence of Record  in "+description);
				for(int j=1;j<=5;j++){
					Thread.sleep(waitTime);
					System.out.print(".");
				}

			}
			else{
				flag=true;
				break;
			}
		}
		if(flag)
			System.out.println("Database validated"+description);
		else{
			System.out.println("Unable to fetch records from Database"+description);
			System.out.println("Failed Query : "+ query);
		}
		return flag;

	}
}
