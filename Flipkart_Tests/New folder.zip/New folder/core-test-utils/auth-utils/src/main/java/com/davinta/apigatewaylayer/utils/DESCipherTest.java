package com.davinta.apigatewaylayer.utils;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

import org.bouncycastle.util.encoders.Base64;

public class DESCipherTest {
	// private byte[] encKey;
	private static final int desKeyLength = 16;
	private DESCipher desEncCipher;

	public DESCipherTest() {
		desEncCipher = new DESCipher(desKeyLength);
	}

	public void generateEncKey() {
		try {
			byte[] encKey = "1234123412341234".getBytes();// desEncCipher.generateKey();
			//System.out.println("Length: " + new String(encKey));
			setKeyParity(encKey);
			desEncCipher.setKey(encKey);
		} catch (Exception e) {

		}
	}

	public void generateEncKey(String secretKey) {
		try {
			byte[] encKey = secretKey.getBytes();// desEncCipher.generateKey();
			//System.out.println("Length: " + new String(encKey));
			setKeyParity(encKey);
			desEncCipher.setKey(encKey);
		} catch (Exception e) {

		}
	}
	
	private void setKeyParity(byte[] generatedKey) {
		for (int i = 0; i < desKeyLength; i++) {
			byte b = generatedKey[i];
			boolean needsParity = (((b >>> 7) ^ (b >>> 6) ^ (b >>> 5) ^ (b >>> 4) ^ (b >>> 3) ^ (b >>> 2) ^ (b >>> 1))
					& 0x01) == 0;
			if (needsParity) {
				generatedKey[i] |= (byte) 0x01;
			} else {
				generatedKey[i] &= (byte) 0xfe;
			}
		}
	}

	// ISO9797 Padding Method 2
	private byte[] padISO9797M2(byte[] data) {
		int j = data.length;
		int k = j % 8;
		if (k != 0) {
			k = 8 - k;
		} else {
			k = 8;
		}
		byte[] abyte1 = new byte[j + k];
		System.arraycopy(data, 0, abyte1, 0, j);
		abyte1[j] = (byte) 0x80;
		return abyte1;
	}

	private byte[] unPadISO9797M2(byte[] data) throws UnsupportedEncodingException {
		byte[] abyte1 = null;
		for (int i = data.length - 1; i >= 0; i--) {
			if ((data[i] & 0xFF) == 0x80) {
				abyte1 = new byte[i];
				System.arraycopy(data, 0, abyte1, 0, i);
				break;
			} else if (data[i] != 0) {
				throw new UnsupportedEncodingException();
			}
		}
		return abyte1;
	}

	public byte[] encryptData(byte[] data,String secKey) throws Exception {
		try {
			return desEncCipher.encrypt(padISO9797M2(data),secKey);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public byte[] decryptData(byte[] encryptedData) throws Exception {
		try {
			return unPadISO9797M2(desEncCipher.decrypt(encryptedData));
		} catch (Exception e) {
			e.getMessage();
			throw new Exception(e.toString());
		}
	}

	/*public static String clientInfoKey(String payload) throws Exception {
		DESCipherTest object = new DESCipherTest();
		object.generateEncKey();
		String encData = new String(Base64.encode(object.encryptData(payload.getBytes())));
		String decData = new String(object.decryptData(Base64.decode(encData)));
		return encData;
	}*/

	public String clientInfoKey(String payload,String secretKey) throws Exception {
		DESCipherTest object = new DESCipherTest();
		generateEncKey(secretKey);
		/*setKeyParity(secretKey.getBytes(StandardCharsets.UTF_8));
		desEncCipher.setKey(secretKey.getBytes(StandardCharsets.UTF_8));*/
		String encData = new String(Base64.encode(object.encryptData(payload.getBytes(),secretKey)));
		String decData = new String(object.decryptData(Base64.decode(encData)));
		return encData;

	}
	/*public static void main(String[] args) {
		DESCipherTest object = new DESCipherTest();
		Scanner input = new Scanner(System.in);
		object.generateEncKey();
		System.out.println();
		System.out.println("Please Enter the data");
		String str = input.nextLine();
		try {
			String encData = new String(Base64.encode(object.encryptData(str.getBytes())));
			System.out.println(encData);
			String decData = new String(object.decryptData(Base64.decode(encData)));
			System.out.println(decData);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}*/
}
