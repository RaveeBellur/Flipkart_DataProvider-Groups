package com.davinta.admin.agent;
import org.junit.runner.RunWith;
import com.davinta.admin.TestBase;
import com.intuit.karate.junit4.Karate;
import cucumber.api.CucumberOptions;

@RunWith(Karate.class)
@CucumberOptions(monochrome = true)
public class AgentRunner extends TestBase {

}
 