package com.davinta.admin.location;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.databaseaccesslayer.service.NeoDataSource;
import com.davinta.common.utils.Constants;
import com.davinta.databaseaccesslayer.utils.DataTransformUtil;
import com.davinta.databaseaccesslayer.utils.JsonUtil;
import com.google.gson.stream.JsonReader;

public class LocationChecker {
	private static final Logger logger = LoggerFactory.getLogger(LocationChecker.class);

	public static Boolean getLocationInfo(Map<String, Object> jsonResponseMap) throws Throwable {
		if(Constants.DB_CHECK){
			Map<String, Object> message = ((Map)jsonResponseMap.get("message"));
					
			List<Map<String,Map<String, Object>>> neoDbResult = null; 
			boolean neoDbCompare;
			String arrayName;
	
			//1. Read mapping rules
			JsonReader mappingRules = JsonUtil.jsonReader("src/test/java/com/davinta/admin/location/locationfieldmapper.json");
	
			//2. Get Neo DB records 
			arrayName = "locationFieldValidator";
	        String guid = message.get("guid").toString();
	        
	        Map<String, Object> param  = new HashMap<String, Object>();
	        param.put("guid",guid);
	        
	        //neoDbResult = NeoDataSource.getData(Constants.FETCH_TERMINAL,param,Constants.NEO4J);
	        neoDbResult = NeoDataSource.getData(Constants.FETCH_LOCATION_DETAILS,param,Constants.NEO4J);
			logger.debug("Neo DB result: {}",neoDbResult);
			
			//3. Compare API response with DB 
			neoDbCompare =  DataTransformUtil.compareApiResponseToNeoDbRecords(message, neoDbResult, mappingRules,arrayName);
	
			if(!neoDbCompare)
				logger.error("API response values didn't match Neo4j Database Value");
			
			if(neoDbCompare) 
				return true;
			else 
				return false;
		}
		else
			return true;
	}
	
	public static Boolean deleteLocation(String val) throws Throwable {
        Map<String, Object> param  = new HashMap<String, Object>();
        param.put("guid",val);        
        Boolean result = NeoDataSource.executeQuery(Constants.DELETE_LOCATION,param,Constants.NEO4J);
		logger.debug("Neo DB result: {}",result);
		return result;
	}

}
