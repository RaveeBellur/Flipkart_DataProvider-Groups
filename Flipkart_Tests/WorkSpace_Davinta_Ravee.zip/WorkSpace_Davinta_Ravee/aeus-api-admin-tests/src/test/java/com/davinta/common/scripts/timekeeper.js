function(secs) {
	karate.log('sleeping');
	java.lang.Thread.sleep(secs * 1000);
}