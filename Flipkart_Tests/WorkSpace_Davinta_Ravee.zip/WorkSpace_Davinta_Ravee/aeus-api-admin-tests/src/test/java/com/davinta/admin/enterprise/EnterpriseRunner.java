package com.davinta.admin.enterprise;

import org.junit.runner.RunWith;

import com.davinta.admin.TestBase;
import com.intuit.karate.junit4.Karate;
import cucumber.api.CucumberOptions;

@RunWith(Karate.class)
@CucumberOptions(monochrome = true)
public class EnterpriseRunner extends TestBase {
	
}
