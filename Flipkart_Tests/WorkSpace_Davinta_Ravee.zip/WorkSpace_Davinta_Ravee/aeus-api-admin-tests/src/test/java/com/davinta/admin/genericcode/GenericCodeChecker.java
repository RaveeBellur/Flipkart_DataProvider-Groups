package com.davinta.admin.genericcode;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.databaseaccesslayer.service.DataSource;
import com.davinta.databaseaccesslayer.service.NeoDataSource;
import com.davinta.common.utils.Constants;
import com.davinta.databaseaccesslayer.utils.DataTransformUtil;
import com.davinta.databaseaccesslayer.utils.JsonUtil;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.stream.JsonReader;

import net.minidev.json.JSONObject;

public class GenericCodeChecker {
	private static final Logger logger = LoggerFactory.getLogger(GenericCodeChecker.class);

	public static Boolean getGenericCodeDetails(Map<String, Object> jsonResponseMap) throws Throwable {
		if(Constants.DB_CHECK){	
				
		Map<String, Object> message = ((Map)jsonResponseMap.get("message"));
				
		List<Map<String,Map<String, Object>>> neoDbResult = null; 
		boolean neoDbCompare;
		String arrayName;

		//1. Read mapping rules
		JsonReader mappingRules = JsonUtil.jsonReader("src/test/java/com/davinta/admin/genericcode/genericcodefieldmapper.json");

		//2. Get Neo DB records 
		arrayName = "gcFieldValidator";
        String guid = message.get("guid").toString();
        
        Map<String, Object> param  = new HashMap<String, Object>();
        param.put("guid",guid);
        
        //neoDbResult = NeoDataSource.getData(Constants.FETCH_TERMINAL,param,Constants.NEO4J);
        neoDbResult = NeoDataSource.getData(Constants.FETCH_GENERICCODE_DETAILS,param,Constants.NEO4J);
		logger.debug("Neo DB result: {}",neoDbResult);
		
		//3. Compare API response with DB 
		neoDbCompare =  DataTransformUtil.compareApiResponseToNeoDbRecords(message, neoDbResult, mappingRules,arrayName);

		if(!neoDbCompare)
			logger.error("API response values didn't match Neo4j Database Value");
		
		if(neoDbCompare) 
			return true;
		else 
			return false;
		}
		else 
			return true;
	}
	public static Boolean deleteGenericCode(String val) throws Throwable {
		Map<String, Object> param  = new HashMap<String, Object>();
		param.put("guid",val);        
		Boolean result = NeoDataSource.executeQuery(Constants.DELETE_AGENT,param,Constants.NEO4J);
		logger.debug("Neo DB result: {}",result);
		return result;
	
	}
	
	/*public static Boolean getGenericCode(Map<String, Object> jsonResponseMap){
			
			Gson gson = new Gson();
			
			Type genericCodeListType = new TypeToken<ArrayList<GenericCodeChecker>>(){}.getType();
			
		//	GenericCodeChecker[] genericCodeArray = gson.fromJson(, GenericCodeChecker[].class)
		
		return true;
	
	
	}*/
	
	
			
}
	

