function() { 
	  karate.configure('connectTimeout', 500000);
	  karate.configure('readTimeout', 500000);
	  
	  var scripts = 'classpath:com/davinta/common/scripts/';
	  var expectedJson = 'classpath:com/davinta/admin/expectedjson/';
	  
	  karate.set('jsBaseUrl', scripts+'urldetector.js');
	  karate.set('jsAuthorization', scripts+'headers.js');
	  karate.set('jsJwtHeaderAdmin', scripts+'jwtheadersadmin.js');
	  karate.set('jsRandomNumGenerator', scripts+'randomnumgenarator.js');	
	  karate.set('jsStrGenerator', scripts+'stringgenarator.js');
	  karate.set('jsTimeKeeper', scripts+'timekeeper.js');
	  karate.set('jsIsoformatDate', scripts+'isoformatdate.js');
	  karate.set('jsonEmpty', scripts+'empty.json');
	   
	  karate.set('expectedJsonEnterpriseTemplate', expectedJson+'enterprisetemplatecreation.json');
	  karate.set('expectedJsonGetEnterpriseTemplate', expectedJson+'getenterprisetemplate.json');
	  karate.set('expectedJsonEnterpriseTenant', expectedJson+'enterprisetenantcreation.json');
	  karate.set('expectedJsonTenant', expectedJson+'tenantcreation.json');
	  karate.set('expectedJsonEnterprise', expectedJson+'enterprisecreation.json');
	  karate.set('expectedJsonEnterprisePost', expectedJson+'enterprise.json');
	  karate.set('expectedJsonEnterpriseByCode', expectedJson+'enterprisebycode.json');
	  karate.set('expectedJsonAdminAgent', expectedJson+'adminagent.json');
	  karate.set('expectedJsonLocation', expectedJson+'location.json');
	  karate.set('expectedJsonCountry', expectedJson+'country.json');
	  karate.set('expectedJsonCountryPost', expectedJson+'countrypost.json');
	  karate.set('expectedJsonTimeZone', expectedJson+'timezone.json');
	  karate.set('expectedJsonOrgType', expectedJson+'organizationtype.json');
	  karate.set('expectedJsonTitle', expectedJson+'title.json');
	  karate.set('expectedJsonLanguage', expectedJson+'language.json');
	  karate.set('expectedJsonAdress', expectedJson+'addressproof.json');
	  karate.set('expectedJsonUser', expectedJson+'user.json');
	  karate.set('expectedJsonEnterpriseTemplateByType', expectedJson+'enterprisetemplatebytype.json');
	  karate.set('expectedJsonAgentByUserId', expectedJson+'agentbyuserid.json');
	  karate.set('expectedJsonCurrency', expectedJson+'currency.json');
	  karate.set('expectedJsonEnterpriseByGuid', expectedJson+'enterprisebyguid.json');
	  karate.set('expectedJsonRole', expectedJson+'rolecreation.json');
	  karate.set('expectedJsonPrivilege', expectedJson+'privilege.json');
	  karate.set('expectedJsonTerminal', expectedJson+'terminal.json');
	  karate.set('expectedJsonGenericCode', expectedJson+'genericcode.json');
	  karate.set('expectedJsonBankRegistration', expectedJson+'bankregistration.json');
	  
	  //Input Data for ADMIN Services
	  //Enterprise data
	  karate.set('varEnterpriseCode', karate.properties['varEnterpriseCode']);
      karate.set('varTenantId', karate.properties['varTenantId']);
      //Agent data
      karate.set('varAadharNumber', karate.properties['varAadharNumber']);
      karate.set('varUserId', karate.properties['varUserId']);
      karate.set('varTerminalId', karate.properties['varTerminalId']);
	  } 