package com.davinta.aeus.stepdefs.steps;

import com.davinta.aeus.stepdefs.BaseSteps;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BankRegistrationSteps extends BaseSteps{
	
	@Given("^there is an existing agent onboarded and listed as unregistered$")
	public void there_is_an_existing_agent_onboarded_and_listed_as_unregistered() throws Throwable {
		bankRegistrationPage = getBankRegistrationPage();
		
	}

	@When("^I want to add Bank registration$")
	public void i_want_to_add_Bank_registration() throws Throwable {
		bankRegistrationPage.addBankRegistration("AG000148");

	}

	@When("^I enter the bank registration details$")
	public void i_enter_the_bank_registration_details() throws Throwable {
		bankRegistrationPage.bankRegistrationDetails();

	}

	@Then("^Bank registration for an agent is successfully completed$")
	public void bank_registration_for_an_agent_is_successfully_completed() throws Throwable {
		commonActionsPage.messageValidation();
		

	}

	@Then("^the Bank registration status is \"([^\"]*)\"$")
	public void the_Bank_registration_status_is(String arg1) throws Throwable {
		commonActionsPage.statusValidation();
	}



}
