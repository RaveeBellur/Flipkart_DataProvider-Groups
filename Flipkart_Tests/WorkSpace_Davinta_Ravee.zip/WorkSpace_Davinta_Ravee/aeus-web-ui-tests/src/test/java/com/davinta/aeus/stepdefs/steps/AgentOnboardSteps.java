package com.davinta.aeus.stepdefs.steps;


import java.util.List;

import com.davinta.aeus.pageobjects.AgentOnboardPage;
import com.davinta.aeus.stepdefs.BaseSteps;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AgentOnboardSteps extends BaseSteps {
	
	@When("^I want to onboard an agent$")
	public void i_want_to_onboard_an_agent() throws Throwable {
		agentOnboardPage = getAgentOnboardPage();
		
	}
	
	@When("^I enter the agent information$")
	public void i_enter_an_agent_information() throws Throwable {
		agentOnboardPage.agentInformation();

	}

	@When("^I assign the user roles$")
	public void i_assign_the_user_roles(List<String> lstRoles) throws Throwable {
		commonActionsPage=getCommonActionsPage();
		commonActionsPage.roleAssignment(lstRoles);

	}

	@When("^I enter the agent address$")
	public void i_enter_the_agent_address() throws Throwable {
		agentOnboardPage.agentAddress();
		agentOnboardPage.agentPrimaryContact();
		
		
	}
	@When("^I enter the account details$")
	public void i_enter_the_account_details() throws Throwable {
		agentOnboardPage.agentAccountDetails();
	}

	@When("^I enter the KYC information$")
	public void i_enter_the_KYC_information() throws Throwable {
		agentOnboardPage.agentKycInformation();
	    
	}

	@Then("^an agent onboarding is completed$")
	public void an_agent_onboarding_is_completed() throws Throwable {
		commonActionsPage.messageValidation();
	    
	}

	@Then("^the agent status is \"([^\"]*)\"$")
	public void the_agent_status_is(String arg1) throws Throwable {
		commonActionsPage.statusValidation();
	}


}


