package com.davinta.aeus.resources;

import java.util.HashMap;
import java.util.Map;

public class TestConstants {

	public static String DRIVER_LIB_DIR = System.getProperty("driverLibDir");
	public static String BROWSER_TYPE = System.getProperty("browserType");
	
	public static String MAKER = "maker";
	public static String CHECKER = "checker";
	public static String ADMIN = "admin";
	public static String SYSADMIN = "sysadmin";



}


