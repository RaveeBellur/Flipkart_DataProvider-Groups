package com.davinta.aeus.pageobjects;

import java.util.List;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.aeus.resources.DbChecker;
import com.davinta.data.utils.DataManager;
import com.davinta.webdriver.main.PageObject;
import com.davinta.webdriver.utils.TimeEntity;

public class AgentOnboardPage extends PageObject {

	final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
	final String AADHAAR_NUMBER= "999999999999";
	public String agentID;
	DbChecker dbChecker =new DbChecker();
	HomePageTabs homePageTabs;
	CommonActionsPage commonActionsPage;

	//Agent Information page elements
	final By labelAgentinfo = By.xpath("//div[contains(text(),'Agent Information')]");
	final By drpDwnTimeZone=By.id("timeZone");
	final By selTimeZone=By.xpath("//md-option/div[text()='India Standard Time']");
	final By drpDwnTaxLocation=By.id("taxLocation");
	final By selTaxLocation=By.xpath("//md-option/div[text()='India']");
	final By btnPageNavigation=By.id("gotoAgentRolesbtnId");

	//Agent Address page elements
	final By lablAgentAddress = By.xpath("//div[contains(text(),'Location Information')]");
	final By lablAddAddress =By.xpath("//h2[contains(text(),'Add Address')]");
	//final By btnAgentAddressSubmit=By.xpath(".//*[@id='addressContactForm']//md-card/md-card-actions/div[2]/button");
	final By btnAgentAddressSubmit=By.id("gotoAgentAccDatabtnId");

	//Add Primary Contact address page elements
	final By lablAddContact =By.xpath("//h2[contains(text(),'ADD CONTACT')]");
	final By alrtOk=By.xpath("//span[text()='Ok']");


	//Account Details page elements
	final By labCommissionAccountNumber=By.xpath("//label[text()='Commission Account Number']");
	final By txtCommissionAccountNumber=By.id("commissionAccountNumber");
	final By labIfcCode=By.xpath("//label[text()='IFSC Code']");
	final By txtIfcCode=By.id("commissionAccountIfscCode");
	final By btnAgreementStatdate=By.xpath("//md-datepicker[@id='agreementStartDate']/button");
	final By calTodaysDate=By.xpath("//td[@class='md-calendar-date md-calendar-date-today md-focus']");
	final By chkbxSalesAccountdetails=By.id("sameAsCAD");
	final By txtSalesAccountNumber=By.id("commisionAccountNumber");
	final By txtAccountSalesIfcCode=By.id("salesAccountIfscCode");
	final By btnAccountDetailsSubmit=By.xpath(".//*[@id='AccountDetailsForm']//md-card/md-card-actions/div[2]/button");

	//KYC information  page elements
	final By chkbxEKYCCompleted=By.id("salesKycCompleted");
	final By btnSubmit=By.cssSelector(".btn-next-blue.submit-btn-text.md-button.md-ink-ripple.btn-enable");


	@Override
	protected void isLoaded() throws Error {
		logger.debug("AgentOnboardPage {} isLoaded() ", this.getClass().getName());
		this.init();
		homePageTabs = (HomePageTabs) new HomePageTabs().get();
		commonActionsPage = (CommonActionsPage) new CommonActionsPage().get();
	}

	@Override
	protected void load() {
		logger.debug("AgentOnboardPage {} load() ", this.getClass().getName());
	}

	public void clickAgencyBanking() {
		homePageTabs.clickAgencyBanking();
	}

	public void clickAgencyBankingOnboard() {
		homePageTabs.clickAgencyBankingOnboard();
	}	
	public void clickAgencyBankingOnboardAgent() {
		homePageTabs.clickAgencyBankingOnboardAgent();

	}


	public void agentInformation() throws Throwable {

		try {
			dbChecker.deleteUserByAadhaar(AADHAAR_NUMBER);
		} catch (Exception e) {
			logger.info("Aadhar number doesn't exists");
		}

		clickAgencyBanking();
		clickAgencyBankingOnboardAgent();
		clickAgencyBankingOnboardAgent();

		waitUntilLoadedAndElementClickable(CommonElements.drpDwnTitle);
		jsClick(CommonElements.drpDwnTitle);
		waitUntilLoadedAndElementClickable(CommonElements.drpDwnValTitle);
		jsClick(CommonElements.drpDwnValTitle);
		type(DataManager.randomIdentifier(),CommonElements.txtFirstName);
		type(DataManager.randomIdentifier(),CommonElements.txtLastName);
		type(AADHAAR_NUMBER,CommonElements.txtAadharNumber);

		waitUntilLoadedAndElementClickable(CommonElements.drpDwnLanguage);
		jsClick(CommonElements.drpDwnLanguage);
		waitUntilLoadedAndElementClickable(CommonElements.drpDwnValLanguage);
		jsClick(CommonElements.drpDwnValLanguage);

		jsClick(drpDwnTimeZone);
		waitUntilLoadedAndElementClickable(selTimeZone);
		jsClick(selTimeZone);

		jsClick(drpDwnTaxLocation);
		waitUntilLoadedAndElementClickable(selTaxLocation);
		jsClick(selTaxLocation);

		click(btnPageNavigation,TimeEntity.SEC_10.getSeconds());
	}

	public void agentAddress(){
		String lablAgentAdrs=getText(lablAgentAddress);
		waitUntilLoadedAndTextPresentInElement(lablAgentAddress, lablAgentAdrs);

		waitUntilLoadedAndElementClickable(CommonElements.btnAddOfficeAddress);
		jsClick(CommonElements.btnAddOfficeAddress);
		String lablAddAdrs=getText(lablAddAddress);
		waitUntilLoadedAndTextPresentInElement(lablAddAddress, lablAddAdrs);

		type(DataManager.randomIdentifier(), CommonElements.txtAddressLine1);
		type(DataManager.randomIdentifier(), CommonElements.txtAddressLine2);
		waitUntilLoadedAndElementClickable(CommonElements.drpDwnCountry);
		jsClick(CommonElements.drpDwnCountry);

		List<WebElement> allCntrName= findElements(CommonElements.drpDwnValCountry);
		for (WebElement cntrName: allCntrName){
			String strCntr=cntrName.getText();
			if (strCntr.equals("India")){
				click(cntrName);
			}
		}
		waitUntilLoadedAndElementClickable(CommonElements.drpDwnState);
		jsClick(CommonElements.drpDwnState);
		waitUntilLoadedAndElementClickable(CommonElements.drpDwnValState);
		jsClick(CommonElements.drpDwnValState);

		waitUntilLoadedAndElementClickable(CommonElements.drpDwnDistrict);
		jsClick(CommonElements.drpDwnDistrict);
		waitUntilLoadedAndElementClickable(CommonElements.drpDwnValDistrict);
		jsClick(CommonElements.drpDwnValDistrict);

		waitUntilLoadedAndElementClickable(CommonElements.drpDwnSubDistrict);
		jsClick(CommonElements.drpDwnSubDistrict);
		List<WebElement> allSubDistname= findElements(CommonElements.drpDwnValSubDistrict);
		for (WebElement subDistname: allSubDistname){
			String strSubDist=subDistname.getText();
			if (strSubDist.equals("Sira")){
				click(subDistname);
			}
		}

		waitUntilLoadedAndElementClickable(CommonElements.drpDwnTown);
		jsClick(CommonElements.drpDwnTown);
		List<WebElement> allTown= findElements(CommonElements.drpDwnValTown);
		for (WebElement town: allTown){
			String strTown=town.getText();
			if (strTown.equals("Agrahara")){
				click(town);
			}
		}
		type("560001",CommonElements.txtZipCode);

		waitUntilLoadedAndElementClickable(CommonElements.chkbxAddressVerified);
		jsClick(CommonElements.chkbxAddressVerified);

		waitUntilLoadedAndElementClickable(CommonElements.btnSave);
		jsClick(CommonElements.btnSave);
	}

	public void agentPrimaryContact(){
		waitUntilLoadedAndElementClickable(CommonElements.btnAddPrimaryContact);
		jsClick(CommonElements.btnAddPrimaryContact);
		String lablContact=getText(lablAddContact);
		waitUntilLoadedAndTextPresentInElement(lablAddContact, lablContact);

		click(CommonElements.lablJobTitle,TimeEntity.SEC_10.getSeconds());
		waitUntilElementPresent(CommonElements.txtJobTitle);
		type(DataManager.randomIdentifier(),CommonElements.txtJobTitle);

		click(CommonElements.lablMobileNumber,30);
		waitUntilElementPresent(CommonElements.txtMobileNumber);
		type("9945686900",CommonElements.txtMobileNumber);

		waitUntilLoadedAndElementClickable(CommonElements.btnSave);
		jsClick(CommonElements.btnSave);

		waitUntilLoadedAndElementClickable(btnAgentAddressSubmit);
		jsClick(btnAgentAddressSubmit);

		//*****************Alert should not pop up, bug is raised AEUSFI-70********************
		click(alrtOk,TimeEntity.SEC_10.getSeconds());

		waitUntilLoadedAndElementClickable(btnAgentAddressSubmit);
		jsClick(btnAgentAddressSubmit);
	}

	public void agentAccountDetails(){
		click(labCommissionAccountNumber,TimeEntity.SEC_10.getSeconds());
		waitUntilElementPresent(txtCommissionAccountNumber);
		type(DataManager.randomNumberGenerator(), txtCommissionAccountNumber);

		click(labIfcCode,TimeEntity.SEC_30.getSeconds());
		waitUntilElementPresent(txtIfcCode);
		type("CITI0000004", txtIfcCode);

		waitUntilLoadedAndElementClickable(btnAgreementStatdate);
		jsClick(btnAgreementStatdate);

		waitUntilLoadedAndElementClickable(calTodaysDate);
		jsClick(calTodaysDate);
		jsClick(chkbxSalesAccountdetails);
		waitUntilLoadedAndElementClickable(btnAccountDetailsSubmit);
		jsClick(btnAccountDetailsSubmit);
	}
	public void agentKycInformation(){
		waitUntilLoadedAndElementClickable(chkbxEKYCCompleted);
		jsClick(chkbxEKYCCompleted);
		click(btnSubmit,TimeEntity.SEC_10.getSeconds());
	}
}





