package com.davinta.aeus.stepdefs.steps;

import java.util.List;

import com.davinta.aeus.pageobjects.UserOnboardPage;
import com.davinta.aeus.stepdefs.BaseSteps;

import cucumber.api.PendingException;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UserSteps extends BaseSteps {
	
	
	@When("^I want to onboard an user$")
	public void i_want_to_onboard_an_user() throws Throwable {
		userPage = getUserPage();
	}
	
	@When("^I enter the user onboarding data$")
	public void i_enter_the_user_onboarding_data() throws Throwable {
		userPage.userInformation();
	}

	@When("^I enter the address details$")
	public void i_enter_the_address_details() throws Throwable {
		userPage.addAddress();
	}

	@When("^I enter the contact details$")
	public void i_enter_the_contact_details() throws Throwable {
		userPage.addPrimaryContact();
	}

	@Then("^the user onboarding is completed$")
	public void the_user_onboarding_is_completed() throws Throwable {
		
	}
	
	@Then("^the user ID is generated$")
	public void the_user_ID_is_generated() throws Throwable {
		
	}

	@Then("^the user status is \"([^\"]*)\"$")
	public void the_user_status_is(String arg1) throws Throwable {
		
	}
}
