package com.davinta.aeus.stepdefs.steps;

import com.davinta.aeus.stepdefs.BaseSteps;
import com.davinta.file.utils.PropertyFileReader;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class LoginSteps extends BaseSteps {

	String appURL = PropertyFileReader.getProperty("app.url"); 

	@Given("^I am logged in as \"([^\"]*)\"$")
	public void i_am_logged_in_as_admin(String userType) throws Throwable {
		openBrowser(appURL);
		loginPage = getLoginPage();		
		loginPage.login(userType);
	}
	
	
}

