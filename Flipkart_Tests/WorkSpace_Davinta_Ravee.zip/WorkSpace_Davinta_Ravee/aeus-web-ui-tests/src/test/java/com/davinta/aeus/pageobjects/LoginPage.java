package com.davinta.aeus.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.aeus.dataobjects.LoginUserData;
import com.davinta.aeus.resources.TestConstants;
import com.davinta.aeus.resources.User;
import com.davinta.webdriver.main.PageObject;

public class LoginPage extends PageObject {

	final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	final By txtUsername = By.id("username");
	final By txtPassword = By.id("userpassword");
	final By btnSubmit = By.xpath("//form[@id='frmLogin']//button");
	final By drpDwnTenantName = By.xpath("//md-select[@aria-label='Tenant name' and @role='listbox']");
	final By drpDwnEnterpriseName = By.xpath("//form[@id='frmLogin']//button");
	
	
	@Override
	protected void isLoaded() throws Error {
		logger.debug("LoginPage {} isLoaded() ", this.getClass().getName());
		this.init();
	}

	@Override
	protected void load() {
		logger.debug("LoginPage {} load() ", this.getClass().getName());
		// ASSERT -  CHECK WHETHER THE PAGE HAS LOADED
	}
	
	public void login(String userType) {
		LoginUserData loginUserData=User.getUser(userType);
		type(loginUserData.getUserName(),txtUsername);
		type(loginUserData.getPassword(),txtPassword);
		submit(btnSubmit);
	}

	public void logout() {

	}

}
