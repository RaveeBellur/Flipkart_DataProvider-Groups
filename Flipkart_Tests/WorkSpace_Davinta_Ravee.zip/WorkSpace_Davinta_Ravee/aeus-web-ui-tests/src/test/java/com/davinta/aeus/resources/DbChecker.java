package com.davinta.aeus.resources;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.databaseaccesslayer.service.NeoDataSource;
import com.google.gson.stream.JsonReader;

public class DbChecker {
	
	final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
	public static Boolean deleteUserByAadhaar(String val) throws Throwable {
        Map<String, Object> param  = new HashMap<String, Object>();
        param.put("aadharNumber",val);        
        Boolean result = NeoDataSource.executeQuery(Constants.DELETE_USER_AADHAAR,param,Constants.NEO4J);
		return result;
	}
}