package com.davinta.aeus.pageobjects;

import java.util.List;
import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.davinta.webdriver.main.PageObject;
import com.davinta.webdriver.utils.TimeEntity;

import org.junit.Assert;

public class CommonActionsPage extends PageObject {

	final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
	public String genaratedId;
	HomePageTabs homePageTabs;

	final By lablRoleAssgnmt = By.xpath("//div[contains(text(),'Role Assignment')]");
	final By btnAddRoles = By.xpath("//button[@ ng-click='addRole()']");
	final By btnRolePageNext=By.id("gotoAddressbtnId");
	final By btnRolePageBack =By.id("backtoCardOnebtnId");
	final By stusTitle=By.xpath("//md-card-content//span");
	final By valGenaratedId=By.xpath("(//div[@class='result-content-color flex-50']//../div[@class='result-content-color flex'])[1]");
	final By valStatus=By.xpath("//div[@class='result-status-color flex']");

	@Override
	protected void isLoaded() throws Error {
		logger.debug("CommonPage {} isLoaded() ", this.getClass().getName());
		this.init();
		homePageTabs = (HomePageTabs) new HomePageTabs().get();
	}

	@Override
	protected void load() {
		logger.debug("CommonPage {} load() ", this.getClass().getName());
		String lableRole=getText(lablRoleAssgnmt);
		waitUntilLoadedAndTextPresentInElement(lablRoleAssgnmt,lableRole);
	}

	public void roleAssignment(List<String> lstRoles) throws InterruptedException{

		//Select list of roles	check boxes
		for (String role : lstRoles) {
			String strXpathRole = "//label[text()='";
			strXpathRole = strXpathRole + role + "']";
			By xpathRole = By.xpath(strXpathRole);  
			waitUntilElementPresent(xpathRole);
			jsClick(xpathRole);
		}
		//Add all the selected roles
		waitUntilElementPresent(btnAddRoles);
		jsClick(btnAddRoles);
		//Validate List of Roles added to Assigned Roles
		for (String role : lstRoles) {
			String strXpathRole = "//label[text()='";
			strXpathRole = strXpathRole + role + "']";
			By xpathRole = By.xpath(strXpathRole);  
			waitUntilElementPresent(xpathRole);
			String roleLabel=getText(xpathRole);
			Assert.assertEquals("Assigned Roles"+" "+"<"+ role+">"+" "+"is added" ,role, roleLabel);

		}
		click(btnRolePageNext,TimeEntity.SEC_10.getSeconds());
	}

	public void messageValidation(){
		String msg=findElement(stusTitle).getText();
		waitUntilLoadedAndTextPresentInElement(stusTitle, msg);
	}
	public void statusValidation(){
		//Get the Agent ID value
		genaratedId=findElement(valGenaratedId).getText();
		waitUntilLoadedAndTextPresentInElement(valGenaratedId, genaratedId);
		//Get the Status value
		String status=findElement(valStatus).getText();
		waitUntilLoadedAndTextPresentInElement(valStatus, status);
	}

}


