package com.davinta.aeus.stepdefs.steps;

import com.davinta.aeus.pageobjects.SurveyPage;
import com.davinta.aeus.stepdefs.BaseSteps;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SurveySteps extends BaseSteps {
	
	@When("^I want to collect customer data$")
	public void i_want_to_collect_customer_data() throws Throwable {
		    survey = getSurveyPage();
			survey.addNewCustomerSurveyDetails();
	}

	@When("^I enter the General Information data$")
	public void i_enter_the_General_Information_data() throws Throwable {
	    //Thread.sleep(2000);
	    survey.fillGeneralInfo();
	}

	@When("^I enter the Entitlement Records data$")
	public void i_enter_the_Entitlement_Records_data() throws Throwable {
		survey.fillEntitlementRecords();
	}

	@When("^I enter the Family Members Details data$")
	public void i_enter_the_Family_Members_Details_data() throws Throwable {
		survey.fillFamilyMemberDetails();
	}

	@When("^I enter the Family Annual Income data$")
	public void i_enter_the_Family_Annual_Income_data() throws Throwable {
		survey.fillFamilyAnnualIncome();
	}

	@When("^I enter the Land Owned data$")
	public void i_enter_the_Land_Owned_data() throws Throwable {
		survey.fillLandOwnedInfo();
	}

	@When("^I enter the Land & Crops data$")
	public void i_enter_the_Land_Crops_data() throws Throwable {
	    survey.fillLandAndCorpInfo();
	}

	@When("^I enter the Live Stocks data$")
	public void i_enter_the_Live_Stocks_data() throws Throwable {
	    survey.fillLiveStocksInfo();
	}

	@When("^I enter the Immovable Assets data$")
	public void i_enter_the_Immovable_Assets_data() throws Throwable {
	    survey.fillImmovableAssetsInfo();
	}

	@When("^I enter the Movable Assets data$")
	public void i_enter_the_Movable_Assets_data() throws Throwable {
		survey.fillMovableAssetsInfo();
	}

	@When("^I enter the Soil & Water Conservation Structures data$")
	public void i_enter_the_Soil_Water_Conservation_Structures_data() throws Throwable {
	    survey.fillSoilAndWaterInfo();
	}

	@When("^I enter the Present Trees data$")
	public void i_enter_the_Present_Trees_data() throws Throwable {
		survey.fillPresentTreesrInfo();
	}

	@When("^I enter the Family Liabilities data$")
	public void i_enter_the_Family_Liabilities_data() throws Throwable {
	    survey.fillFamilyLiabilitiesInfo();
	}

	@When("^I enter the Family-Other Bank Dealings data$")
	public void i_enter_the_Family_Other_Bank_Dealings_data() throws Throwable {
	    survey.fillOtherBankInfo();
	}

	@When("^I enter the Training Requirements data$")
	public void i_enter_the_Training_Requirements_data() throws Throwable {
		survey.fillTrainingRequirementsInfo();
	}

	@When("^I enter the Family-Development Plan Needs data$")
	public void i_enter_the_Family_Development_Plan_Needs_data() throws Throwable {
		survey.fillFamilyDevelopmentPlanInfo();
	}

	@When("^I enter the Indirect Liabilities as Guarantor data$")
	public void i_enter_the_Indirect_Liabilities_as_Guarantor_data() throws Throwable {
		survey.fillIndirectLiabilitiesInfo();
	}

	@When("^I enter the Application data$")
	public void i_enter_the_Application_data() throws Throwable {
		survey.fillApplicationInfo();
	}

	@When("^I submit the survey data$")
	public void i_submit_the_survey_data() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^the Customer Survey data is saved successfully$")
	public void the_Customer_Survey_data_is_saved_successfully() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^the maker status is \"([^\"]*)\"$")
	public void the_maker_status_is(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}



}
