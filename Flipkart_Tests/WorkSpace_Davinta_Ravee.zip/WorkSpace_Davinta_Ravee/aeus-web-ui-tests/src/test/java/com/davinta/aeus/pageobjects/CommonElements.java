package com.davinta.aeus.pageobjects;

import org.openqa.selenium.By;

public class CommonElements {

	final static By drpDwnTitle=By.id("nameTitle");
    final static By drpDwnValTitle=By.xpath("//div[contains(text(),'Mr.')]");
    final static By txtFirstName=By.id("firstName");
    final static By txtLastName=By.id("lastName");
    final static By txtAadharNumber=By.id("aadharNumber");
    final static By drpDwnLanguage=By.id("userLanguage");
    final static By drpDwnValLanguage=By.xpath("//div[contains(text(),'English')]");
    final static By drpDwnUserType=By.id("userType");
    final static By drpDwnValUserType=By.xpath("//div[text()='User']"); 
    
    final static By btnAddOfficeAddress=By.id("addOfficeAddress");
    final static By txtAddressLine1=By.id("addressLine1");
    final static By txtAddressLine2=By.id("addressLine2");
    final static By drpDwnCountry=By.id("country");
    final static By drpDwnValCountry=By.xpath("//md-option/div[text()='India']");
    final static By drpDwnState=By.id("state");
    final static By drpDwnValState=By.xpath(("//div[text()='Karnataka']"));
    final static By drpDwnDistrict=By.id("district");
    final static By drpDwnValDistrict=By.xpath(("//md-option/div[text()='Tumkur']"));
    final static By drpDwnSubDistrict=By.id("subDistrict");
    final static By drpDwnValSubDistrict=By.xpath(("//md-option/div[text()='Sira']"));
    final static By drpDwnTown=By.id("town");
    final static By drpDwnValTown=By.xpath(("//md-option/div[text()='Agrahara']"));
    final static By txtZipCode=By.id("zipCode");
    final static By chkbxAddressVerified=By.id("addressProofVerified");
    final static By btnSave=By.xpath("//span[text()=' Save ']");

    final static By btnAddPrimaryContact=By.id("addPrimaryContactAddress");
    final static By lablJobTitle=By.xpath("//label[text()='Job Title']");
    final static By txtJobTitle =By.id("jobTitle");
    final static By lablMobileNumber=By.xpath("//label[text()='Mobile Number']");
    final static By txtMobileNumber=By.id("mobileNumber");  

}



