package com.davinta.aeus.resources;

import java.util.HashMap;

import com.davinta.aeus.dataobjects.LoginUserData;
import com.davinta.file.utils.PropertyFileReader;


public class User {

	private static HashMap<String, LoginUserData> users = new HashMap<String, LoginUserData>();

	public static LoginUserData MAKER = initUser("maker");
	public static LoginUserData CHECKER = initUser("checker");
	public static LoginUserData ADMIN = initUser("admin");

	private static LoginUserData initUser(String propertyRef) {
		LoginUserData userData = new LoginUserData();
		userData.setUserName(PropertyFileReader.getProperty(propertyRef + "UserName"));
		userData.setPassword(PropertyFileReader.getProperty(propertyRef + "Password"));
		userData.setFirstName(PropertyFileReader.getProperty(propertyRef + "FirstName"));
		userData.setLastName(PropertyFileReader.getProperty(propertyRef + "LastName"));
		users.put(propertyRef, userData);
		return userData;
	}

	public static LoginUserData getUser(String userType) {
		LoginUserData user = null;
		user = users.get(userType);
		return user;
	}

}
