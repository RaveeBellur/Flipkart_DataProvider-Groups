package com.davinta.aeus.stepdefs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.aeus.pageobjects.AgentOnboardPage;
import com.davinta.aeus.pageobjects.BankRegistrationPage;
import com.davinta.aeus.pageobjects.CommonActionsPage;
import com.davinta.aeus.pageobjects.GroupsPage;
import com.davinta.aeus.pageobjects.HomePageTabs;
import com.davinta.aeus.pageobjects.LoginPage;
import com.davinta.aeus.pageobjects.SurveyPage;
import com.davinta.aeus.pageobjects.TerminalManagementPage;
import com.davinta.aeus.pageobjects.UserOnboardPage;
import com.davinta.aeus.resources.TestConstants;
import com.davinta.webdriver.main.DriverInitializer;

public class BaseSteps {
	final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
	DriverInitializer driverInitializer = DriverInitializer.getDriverInitializerInstance();

	public LoginPage loginPage;
	public HomePageTabs homePageTabs;
	public CommonActionsPage commonActionsPage;
	public BankRegistrationPage bankRegistrationPage;
	public AgentOnboardPage agentOnboardPage;
	public GroupsPage groupPage;
	public SurveyPage survey;
	public UserOnboardPage userPage;
	public TerminalManagementPage terminalManagementPage;
	
	public LoginPage getLoginPage() {
		return (LoginPage) new LoginPage().get();
	}
 
	public HomePageTabs getHomePageTabs() {
		return (HomePageTabs) new HomePageTabs().get();
	}
	
	public GroupsPage getGroupsPage() {
		return (GroupsPage) new GroupsPage().get();
	}
	
	public UserOnboardPage getUserPage() {
		return (UserOnboardPage) new UserOnboardPage().get();
	}
	
	public AgentOnboardPage getAgentOnboardPage(){
		return (AgentOnboardPage) new AgentOnboardPage().get();
	}

	public CommonActionsPage getCommonActionsPage(){
		return (CommonActionsPage) new CommonActionsPage().get();
	}
	
	public BankRegistrationPage getBankRegistrationPage(){
		return ( BankRegistrationPage) new  BankRegistrationPage().get();
	}
	
	public SurveyPage getSurveyPage() {
		return (SurveyPage) new SurveyPage().get();
	} 
	
	public TerminalManagementPage getTerminalManagementPage() {
		return (TerminalManagementPage) new TerminalManagementPage().get();
	} 
	
	public void triggerURL(String URL) {
		logger.debug("driver init :: {}", driverInitializer);
		driverInitializer.triggerURL(URL);
	}

	public void openBrowser(String URL) {
		try {
			// driverInitializer.getAppropriateDriver(browserType);
			logger.info("Launching App on browser type:: {}", TestConstants.BROWSER_TYPE);
			logger.info("URL:: {}", URL);
			driverInitializer.getAppropriateDriver(TestConstants.BROWSER_TYPE, TestConstants.DRIVER_LIB_DIR);
		} catch (Exception e) {
			e.printStackTrace();
		}
		triggerURL(URL);
	}

}
