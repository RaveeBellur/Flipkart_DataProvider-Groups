package com.davinta.aeus.pageobjects;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.webdriver.main.PageObject;
import com.davinta.webdriver.utils.TimeEntity;

public class HomePageTabs extends PageObject {

	final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	// Customer Data tab
	final By tabCustomerData = By.id("CustomerDataMenu");
	final By tabCustomerDataSurvey = By.id("SurveyMenuSubItem");
	final By tabCustomerDataGroups = By.id("GroupsMenuSubItem");
	final By tabCustomerDataCIS = By.id("CISMenuSubItem");

	// Agency Banking tab
	final By tabAgencyBanking = By.id("AgencyBankingMenu");
	final By tabAgencyBankingOrgStructure = By.id("OrganizationalStructureMenuItem");
	final By tabAgencyBankingOnboard = By.id("OnboardMenuItem");
	final By tabAgencyBankingOnboardAgent = By.id("AgentMenuSubItem");
	final By tabAgencyBankingOnboardUser = By.id("UserMenuSubItem");
	final By tabAgencyBankingOnboardAgentBankReg = By.id("BankRegistrationMenuSubItem");
	final By tabAgencyBankingOnboardAgentTerminalLinking = By.id("TerminalLinkingMenuSubItem");
	final By tabAgencyBankingDevicesTerminals = By.id("DevicesandTerminalMenuItem");
	final By tabAgencyBankingDevicesTerminalsTerminal = By.id("TerminalMenuSubItem");
	final By tabAgencyBankingReports = By.id("ReportsMenuItem");
	final By tabAgencyBankingReportsTransaction = By.id("TransactionReportMenuSubItem");
	final By tabAgencyBankingReportsTerminalAllocation = By.id("TerminalAllocationReportMenuSubItem");
	final By tabAgencyBankingReportsEnrollmentSummary = By.id("EnrollmentSummaryReportMenuSubItem");
	final By tabAgencyBankingReportsEnrollmentDetail = By.id("EnrollmentDetailsReportMenuSubItem");
	
	// Validation Elements
	final By txtSurvey = By.xpath("//div[contains(text(),'List Of Customer Data')]");
	final By txtGroup = By.xpath("//div[contains(text(),'Group List')]");
	final By txtCIS = By.xpath("//div[contains(text(),'Customer Information System')]");
	final By txtAgent = By.xpath("//div[contains(text(),'Agent Information')]");
	final By txtBankRegistration = By.xpath("//div[contains(text(),'UNREGISTERED AGENT LIST')]");
	final By txtTerminalLinking = By.xpath("//div[contains(text(),'Agent List')]");
	final By txtUser = By.xpath("//div[contains(text(),'User Onboarding')]");
	final By txtTerminal=By.cssSelector(".triangle-view-title.head-title");
	final By txtTransactionReport = By.xpath("//div[text()='AGENT TRANSACTION REPORT']");
	final By txtTerminalAllocationReport = By.xpath("//div[text()='TERMINAL ALLOCATION REPORT']");
	final By txtEnrollmentSummaryReport = By.xpath("//div[text()='CUSTOMER ENROLLMENT SUMMARY REPORT']");
	final By txtEnrollmentDetailReport = By.xpath("//div[text()='CUSTOMER ENROLLMENT DETAILED REPORT']");
	
	// Text to Verify
	final String SURVEY_TEXT = "List Of Customer Data";
	final String GROUP_TEXT = "Group List";
	final String CIS_TEXT = "Customer Information System";
	final String AGENT_TEXT = "AGENT INFORMATION";
	final String BANKREGISTRATION_TEXT = "UNREGISTERED AGENT LIST";
	final String TERMINAL_LINKING_TEXT = "Agent List";
	final String USER_TEXT = "User Onboarding";
	final String TERMINAL_TEXT ="TERMINAL MANAGEMENT";
	final String TRANSACTION_REPORT_TEXT = "AGENT TRANSACTION REPORT";
	final String TERMINAL_ALLOCATION_REPORT_TEXT = "TERMINAL ALLOCATION REPORT";
	final String ENROLLMENT_SUMMARY_REPORT_TEXT = "CUSTOMER ENROLLMENT SUMMARY REPORT";
	final String ENROLLMENT_DETAIL_REPORT_TEXT = "CUSTOMER ENROLLMENT DETAILED REPORT";
	
	// Loans tabs
	final By tabLoans = By.id("LoansMenu");

	@Override
	protected void isLoaded() throws Error {
		logger.debug("HomePageTabs {} isLoaded() ", this.getClass().getName());
		this.init();
		waitUntilLoadedAndElementClickable(tabCustomerData);
	}

	@Override
	protected void load() {
		logger.debug("HomePageTabs {} load() ", this.getClass().getName());
	}

	// Customer Data tab
	public void clickCustomerData() {
		click(tabCustomerData,TimeEntity.SEC_10.getSeconds());
	}

	public void clickCustomerDataSurvey() {
		click(tabCustomerDataSurvey,TimeEntity.SEC_10.getSeconds());
		waitUntilLoadedAndTextPresentInElement(txtSurvey,SURVEY_TEXT);
	}

	public void clickCustomerDataGroups() {
		click(tabCustomerDataGroups,TimeEntity.SEC_10.getSeconds());
		waitUntilLoadedAndTextPresentInElement(txtGroup,GROUP_TEXT);
	}

	public void clickCustomerDataCIS() {
		click(tabCustomerDataCIS,TimeEntity.SEC_10.getSeconds());
		waitUntilLoadedAndTextPresentInElement(txtCIS,CIS_TEXT);
	}

	// Agency Banking tab
	public void clickAgencyBanking() {
		click(tabAgencyBanking,TimeEntity.SEC_10.getSeconds());
	}

	public void clickAgencyBankingOrgStructure() {
		click(tabAgencyBankingOrgStructure,TimeEntity.SEC_10.getSeconds());
	}

	public void clickAgencyBankingOnboard() {
		click(tabAgencyBankingOnboard,TimeEntity.SEC_10.getSeconds());
	}

	public void clickAgencyBankingDevicesTerminals() {
		click(tabAgencyBankingDevicesTerminals,TimeEntity.SEC_10.getSeconds());
	}

	public void clickAgencyBankingReports() {
		click(tabAgencyBankingReports,TimeEntity.SEC_10.getSeconds());
	}

	public void clickAgencyBankingOnboardAgent() {
		click(tabAgencyBankingOnboardAgent,TimeEntity.SEC_10.getSeconds());
		waitUntilLoadedAndTextPresentInElement(txtAgent,AGENT_TEXT);
	}

	public void clickAgencyBankingOnboardUser() {
		click(tabAgencyBankingOnboardUser,TimeEntity.SEC_10.getSeconds());
		//waitUntilLoadedAndTextPresentInElement(txtUser,USER_TEXT);
	}

	public void clickAgencyBankingOnboardAgentBankReg() {
		click(tabAgencyBankingOnboardAgentBankReg,TimeEntity.SEC_10.getSeconds());
		String txtBankReg=findElement(txtBankRegistration).getText();
		waitUntilLoadedAndTextPresentInElement(txtBankRegistration,txtBankReg);
	}

	public void clickAgencyBankingOnboardAgentTerminalLinking() {
		click(tabAgencyBankingOnboardAgentTerminalLinking,TimeEntity.SEC_10.getSeconds());
		waitUntilLoadedAndTextPresentInElement(txtTerminalLinking,TERMINAL_LINKING_TEXT);
	}

	public void clickAgencyBankingDevicesTerminalsTerminal() {
		click(tabAgencyBankingDevicesTerminalsTerminal,TimeEntity.SEC_30.getSeconds());
		waitUntilLoadedAndTextPresentInElement(txtTerminal, TERMINAL_TEXT);
	}
	
	public void clickAgencyBankingReportsTransaction() {
		click(tabAgencyBankingReportsTransaction,TimeEntity.SEC_10.getSeconds());
		waitUntilLoadedAndTextPresentInElement(txtTransactionReport,TRANSACTION_REPORT_TEXT);
	}
	
	public void clickAgencyBankingReportsTerminalAllocation() {
		click(tabAgencyBankingReportsTerminalAllocation,TimeEntity.SEC_10.getSeconds());
		waitUntilLoadedAndTextPresentInElement(txtTerminalAllocationReport,TERMINAL_ALLOCATION_REPORT_TEXT);
	}
	
	public void clickAgencyBankingReportsEnrollmentSummary() {
		click(tabAgencyBankingReportsEnrollmentSummary,TimeEntity.SEC_10.getSeconds());
		waitUntilLoadedAndTextPresentInElement(txtEnrollmentSummaryReport,ENROLLMENT_SUMMARY_REPORT_TEXT);
	}
	
	public void clickAgencyBankingReportsEnrollmentDetails() {
		click(tabAgencyBankingReportsEnrollmentDetail,TimeEntity.SEC_10.getSeconds());
		waitUntilLoadedAndTextPresentInElement(txtEnrollmentDetailReport,ENROLLMENT_DETAIL_REPORT_TEXT);
	}

	// Loans tab
	public void clickLoans() {
		click(tabLoans,10);
	}

}
