package com.davinta.aeus.stepdefs.steps;

import com.davinta.aeus.pageobjects.GroupsPage;
import com.davinta.aeus.stepdefs.BaseSteps;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GroupSteps extends BaseSteps {

	@When("^I want to create group$")
	public void i_want_to_create_group() throws Throwable {
		groupPage = getGroupsPage();
	}

	@When("^I submit the group info data with \"([^\"]*)\"$")
	public void i_submit_the_group_info_data_with(String groupType) throws Throwable {
		groupPage.createGroup(groupType);
	}

	@Then("^the group status is \"([^\"]*)\"$")
	public void the_group_status_is(String status) throws Throwable {
		groupPage.verifyGroup();
		//Do AssertEquas
	}
	
	
}
