package com.davinta.aeus.pageobjects;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.data.utils.DataManager;
import com.davinta.webdriver.main.PageObject;
import com.davinta.webdriver.utils.TimeEntity;
import com.davinta.webdriver.utils.TimeManager;

public class GroupsPage extends PageObject {

	final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
	HomePageTabs homePageTabs;
	Date dt = new Date();
	final String SUCCESSMSG = "Group Created Successfully";
	
	final By btnAdd = By.id("createGroupbtnId");
	final By drpDwnGroupType = By.id("groupType");
	final By txtGroupName = By.id("groupName");
	final By drpDwnState = By.id("state");
	final By drpDwnStateValue = By.xpath("//md-option[@value='Karnataka']");
	final By drpDwnDistrict = By.id("district");
	final By drpDwnDistrictValue = By.xpath("//md-option[@value='Kolar']");
	final By drpDwnSubDistrict = By.id("subDistrict");
	final By drpDwnSubDistrictValue = By.xpath("//md-option[@value='Srinivaspur']");
	final By drpDwnVillage = By.id("village");
	final By drpDwnVillageValue = By.xpath("//md-option[@value='Upparapalli']");
	final By calendar = By.id("groupRegistrationDate");
	final By currentDate = By.xpath("//td[@class='md-calendar-date md-calendar-date-today md-focus']");
	final By btnCreate = By.xpath("//span[contains(text(),'Create')]");
	final By btnCancel = By.xpath("//span[contains(text(),'Cancel')]");
	final By btnPopUpOk = By.xpath("//span[contains(text(),'Ok')]");
	final By btnPopUpOkTime = By.xpath("//span[contains(text(),'OK')]");
	final By msgFailurePopUp = By.xpath("//h2[contains(text(),'Failure Message')]");
	
	final By inactiveGroupState = By.xpath("//span[contains(text(),'Inactive')]");
     		
	@Override
	protected void isLoaded() throws Error {
		logger.debug("GroupsPage {} isLoaded() ", this.getClass().getName());
		this.init();
		homePageTabs = (HomePageTabs) new HomePageTabs().get();
	}

	@Override
	protected void load() {
		logger.debug("GroupsPage {} load() ", this.getClass().getName());
	}
	
	public void clickCustomerData(){
		homePageTabs.clickCustomerData();
	}
	
	public void clickCustomerDataGroups(){
		homePageTabs.clickCustomerDataGroups();
	}

	public void createGroup(String groupType) throws InterruptedException
	{
		clickCustomerData();
		clickCustomerDataGroups();
		String xpathGroupType = "//md-option[@value='";
		TimeManager.waitInSeconds(TimeEntity.SEC_2.getSeconds());
		// Pop Up Appears
		if(isDisplayed(msgFailurePopUp)){
			logger.info("Popup Appeared");
			click(btnPopUpOkTime);
			}
		else{
			logger.error("Popup Didn't Appeared");
		}
		click(btnAdd,TimeEntity.SEC_10.getSeconds());
        waitUntilLoadedAndElementClickable(drpDwnGroupType);
        jsClick(drpDwnGroupType);
        
        if(groupType.equals("SHG")){
        	xpathGroupType = xpathGroupType + "CBO_GROUP_TYPE_SHG']";
        } else if(groupType.equals("JLG")){
        	xpathGroupType = xpathGroupType + "CBO_GROUP_TYPE_JLG']";
        }
      
    	By drpDwnGroupTypeValue = By.xpath(xpathGroupType);
        click(drpDwnGroupTypeValue,TimeEntity.SEC_10.getSeconds());
        type(DataManager.randomIdentifier(), txtGroupName);
        waitUntilLoadedAndElementClickable(drpDwnState);
        jsClick(drpDwnState);
        waitUntilLoadedAndElementClickable(drpDwnStateValue);
        jsClick(drpDwnStateValue);
        waitUntilLoadedAndElementClickable(drpDwnDistrict);
        jsClick(drpDwnDistrict);
        waitUntilLoadedAndElementClickable(drpDwnDistrictValue);
        jsClick(drpDwnDistrictValue);
        waitUntilLoadedAndElementClickable(drpDwnSubDistrict);
        jsClick(drpDwnSubDistrict);
        waitUntilLoadedAndElementClickable(drpDwnSubDistrictValue);
        jsClick(drpDwnSubDistrictValue);
        waitUntilLoadedAndElementClickable(drpDwnVillage);
        jsClick(drpDwnVillage);
        waitUntilLoadedAndElementClickable(drpDwnVillageValue);
        jsClick(drpDwnVillageValue);
        click(calendar,TimeEntity.SEC_10.getSeconds());
        click(currentDate,TimeEntity.SEC_10.getSeconds());
        click(btnCreate,TimeEntity.SEC_10.getSeconds());
        click(btnPopUpOk,TimeEntity.SEC_10.getSeconds());
	} 
	
	public void verifyGroup()
	{
		isDisplayed(inactiveGroupState,TimeEntity.SEC_10.getSeconds());
	}
	
	public String currentMonthYear(){
		Date date = new Date();

	    SimpleDateFormat sdf = new SimpleDateFormat("MMM");
	    String month = sdf.format(date).toString();

	    Format formatter = new SimpleDateFormat("yyyy"); 
	    String s = formatter.format(new Date());
	    
	    String str = month+" "+s;
		return str;
	}
}
