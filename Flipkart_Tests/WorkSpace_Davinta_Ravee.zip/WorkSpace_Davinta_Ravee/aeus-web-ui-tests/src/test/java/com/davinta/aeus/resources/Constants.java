package com.davinta.aeus.resources;

/**
 * @author rbellur
 * @throws   
 * @category
 * 
 */

public interface Constants {
	// DAO Mappings
	public String TRANSACTION="TRANSACTION";
	public String ENROLLMENT="ENROLLMENT";
	public String NEO4J="NEO4J";
	//Admin DB constants
	
	public String DELETE_LOCATION = "DELETE_LOCATION";
	public String DELETE_COUNTRY = "DELETE_COUNTRY";
	public String DELETE_CURRENCY = "DELETE_CURRENCY";
	public String DELETE_ENTERPRISETEMPLATE = "DELETE_ENTERPRISETEMPLATE";
	public String DELETE_ENTERPRISE = "DELETE_ENTERPRISE";
	public String DELETE_TERMINAL = "DELETE_TERMINAL";
	public String DELETE_AGENT = "DELETE_AGENT";
	public String DELETE_AGENT_AADHAAR = "DELETE_AGENT_AADHAAR";
	public String DELETE_ROLE = "DELETE_ROLE";
	public String DELETE_PRIVILEGE = "DELETE_PRIVILEGE";
	public String DELETE_USER = "DELETE_USER";
	public String DELETE_USER_AADHAAR = "DELETE_USER_AADHAAR"; 
	
	public String  DATE_FORMAT="yyyy-MM-dd";
	public String  FAILED_QUERY="Failed Query : ";

	/**
	 * Below are the DB datatype constant
	 * 
	 */
	public String CLOB_DATA_TYPE="mysql.sql.CLOB";
	public String DATE_DATA_TYPE="java.sql.Timestamp";
	public boolean DB_CHECK = true;

	
	
}
