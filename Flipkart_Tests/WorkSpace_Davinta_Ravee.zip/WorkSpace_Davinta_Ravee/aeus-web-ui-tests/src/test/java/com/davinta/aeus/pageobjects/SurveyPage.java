package com.davinta.aeus.pageobjects;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.eclipse.jetty.client.ValidatingConnectionPool;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.data.utils.DataManager;
import com.davinta.webdriver.main.PageObject;
import com.davinta.webdriver.utils.TimeEntity;
import com.davinta.webdriver.utils.TimeManager;
import com.sun.jna.platform.unix.X11.XClientMessageEvent.Data;

public class SurveyPage extends PageObject {
	private static final String GROUP_TEXT = "General Information";
	final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
	HomePageTabs homePageTabs;
	
	final By btnAddNewSurvey = By.xpath("//button[@class='md-button md-small btn-add-green']/i");
	final By btnNext = By.xpath("//button[@class='md-button md-small btn-next-loan md-button md-ink-ripple'][@ng-click='gotoNextPage()']");
	final By btnAdd = By.xpath("//button[@class='md-button md-medium btn-next-blue save_add_ch md-button md-ink-ripple']");
	final By icnExpand = By.xpath("//i[@class='fa fa-angle-down']");
	final By icnCollapse = By.xpath("//i[@class='fa fa-angle-up']");
	final By navFamily = By.xpath("//li[@data-title='Family Members Details']");
	final By btnSubmit = By.xpath("//button[@ng-click='submitCustomerSurveyData()']");
	
	final By txtGeneral = By.xpath("//div[text()='General Information'][@class='page-title']");
	
	//General Information
	final By txtApplicantName = By.id("applicantName");
	final By chkBoxFamilyHead = By.xpath("//md-checkbox[@aria-label='Family Head']//div[@class='md-icon']");
    final By dtpDob = By.xpath("//button[@class='md-datepicker-button md-icon-button md-button md-ink-ripple']");
    final By dtpDate = By.xpath("(//span[@class='md-calendar-date-selection-indicator'])[last()]");
    final By drpDwnCaste = By.id("caste");
    final By drpDwnValCasteOBC = By.xpath("//div[@class='md-text'][text()='OBC']");
    final By txtFatherName = By.id("fatherName");
    final By drpDwnRelationship = By.id("relationship");
    final By drpDwnValRelation = By.xpath("//div[@class='md-text'][text()='son/of']");
    final By drpDwnMinorityReligion = By.id("minorityReligion");
    final By drpDwnValMinReligion = By.xpath("//div[@class='md-text'][text()='Jain']");
    final By drpDwnHandicapped = By.id("handicapped");
    final By drpDwnValHandicapped = By.xpath("//md-option[@value='No']");
    final By drpDwnRationCardType = By.id("rationCardType");
    final By drpDwnValRationCardType = By.xpath("//md-option[@value='APL']");
    final By drpDwnHealthInsurance = By.id("healthInsurance");
    final By drpDwnValHealthInsurance = By.xpath("//md-option[@value='RSBY']");
    final By drpDwnState = By.id("state");
    final By drpDwnValState = By.xpath("//md-option[@value='Karnataka']");
    final By drpDwnDistrict = By.id("district");
    final By drpDwnValDistrict = By.xpath("//div[@class='md-text'][text()='Mandya']");
    final By drpDwnSubDistrict = By.id("subDistrict");
    final By drpDwnValSubDistrict = By.xpath("//md-option[@value='Krishnarajpet']");
    final By drpDwnVillage = By.id("village");
    final By drpDwnValVillage = By.xpath("//md-option[@value='Manchibeedu']");
    final By txtGramPanchayat = By.id("gramPanchayat");
    final By txtHobli = By.id("hobli");
    final By txtCurrentAddress = By.id("currentAddress");
    final By txtPermanentAddress = By.id("permanentAddress");
    final By drpDwnHouseType = By.id("houseType");
    final By drpDwnValHouseType = By.xpath("//md-option[@value='Rcc']");
    final By drpDwnReligion = By.id("religion");
    final By drpDwnValReligion = By.xpath("//md-option[@value='Hindu']");    
    final By drpDwnApplicantCaste = By.id("appCaste");
    final By drpDwnValApplicantCaste = By.xpath("//md-option[@value='General – Men']");
    
    //Entitlement Records
    final By drpDwnRationCard = By.id("rationCard");
    final By drpDwnValRationCard = By.id("select_option_473");    
    final By drpDwnJobCard = By.id("jobCard");
    final By drpDwnValJobCard = By.id("select_option_474");
    final By drpDwnOldAgePension = By.id("oldAgePension");
    final By drpDwnValOldAgePension = By.id("select_option_477");
    final By drpDwnWidowRelief = By.id("widowRelief");
    final By drpDwnValWidowRelief = By.id("select_option_479");
    final By drpDwnPhysicallyHandicapped = By.id("physicallyHandicapped");
    final By drpDwnValPhysicallyHandicapped = By.id("select_option_481");
    final By drpDwnScholarship = By.id("scholarship");
    final By drpDwnValScholarship = By.id("select_option_482");
    final By drpDwnOthers = By.id("others");
    final By drpDwnValOthers = By.id("select_option_485");
    final By drpDwnToilet = By.id("toilet");
    final By drpDwnValToilet = By.id("select_option_486");
    
    //Family Members Details
    final By txtFamilyName = By.id("familyname");
    final By txtName = By.id("name");
    final By drpDwnGender = By.id("gender");
    final By drpDwnValGender = By.xpath("//md-option[@value='Male']");
    final By drpDwnEducation = By.id("education");
    final By drpDwnValEducation = By.xpath("//md-option[@value='Post_Grad']");
    final By drpDwnProfession = By.id("profession");
    final By drpDwnValProfession = By.xpath("//md-option[@value='Salary']");
    final By drpDwnAgriInterest = By.id("agriInterest");
    final By drpDwnValAgriInterest = By.xpath("//md-option[@value='Yes']");
    final By txtMobilenumber = By.id("mobilenumber");
    final By txtAdhaarnumber = By.id("adhaarnumber");
    final By txtVoterIdNumber = By.id("voteridnumber");
    final By txtDlNumber = By.id("dlumber");
    final By txtNareganumber = By.id("nareganumber");
    
    //Family Annual Income
    final By drpDwnSource = By.id("corp");
    final By drpDwnValSource = By.xpath("//md-option[@value='Salary']");
    final By txtAnnualIncome = By.id("annualincome");
    final By txtAnnualExpence = By.id("annualexpence");
    final By txtNetIncome = By.id("netincome");
   
    //Land Owned
    final By txtVillageName = By.id("villagename");
    final By txtSurveyNumber = By.id("surveynumber");
    final By drpDwnOwnedOrLeased = By.id("ownedorleased");
    final By drpDwnValOwnedOrLeased = By.xpath("//md-option[@value='Own']");
    final By txtAcre = By.id("acre");
    final By txtGunta = By.id("gunta");
    final By txtTax = By.id("tax");
    final By drpDwnIrrigationSource = By.id("irrigationsource");
    final By drpDwnValIrrigationSource = By.xpath("//md-option[@value='Borewell']");
    final By txtIrrigationAcre = By.id("irrigationacre");
    final By txtIrrigationGunta = By.id("irrigationgunta");
    final By txtEncumberance = By.id("encumberance");
    
    //Land & Crops
    final By drpDwnCorp = By.id("corp");
    final By drpDwnValCorp = By.xpath("//md-option[@value='Paddy_Irrigated']");
    final By drpDwnSeason = By.id("season");
    final By drpDwnValSeason = By.xpath("//md-option[@value='Annual']");
    final By txtLCVillageName = By.id("villagename");
    final By txtLCSurveyNumber = By.id("surveynumber");
    final By txtLCAcre = By.id("acre");
    final By txtLCGunta = By.id("gunta");
    
    //Live Stocks
    final By drpDwnLiveStocks = By.id("corp");
    final By drpDwnValLiveStocks = By.xpath("//md-option[@value='Local Cow']");
    final By txtNumbers = By.id("stocknumbers");
    final By txtValue = By.id("stockvalue");
    final By txtAnnualStockIncome = By.id("annualstockincome");
    final By txtAnnualExpenditure = By.id("annualstockexpenditure");
    final By drpDwnInsurance = By.id("insurance");
    final By drpDwnValInsurance = By.xpath("//md-option[@value='Yes']");
    
    //Immovable Assets
    final By drpDwnImovableAssetType = By.id("imovableassettype");
    final By drpDwnValImovableAssetType = By.xpath("//md-option[@value='Agricultural Land']");    
    final By txtImovableAssetNumbers = By.id("imovableassetnumbers");
    final By txtImovableAssetValues =  By.id("imovableassetvalues");
    
    //Movable Assets
    final By drpDwnMovableAssetType = By.id("movableassettype");
    final By drpDwnValMovableAssetType = By.xpath("//md-option[@value='Tractor']");
    final By txtMovableAssetNumbers = By.id("movableassetnumbers");
    final By txtMovableAssetValues = By.id("movableassetvalues");
    
    //Soil & Water Conservation Structures
    final By drpDwnStructures = By.id("structures");
    final By drpDwnValStructures = By.xpath("//md-option[@value='Field_Bunds']");
    final By txtSWNumbers = By.id("soilwaterconsrvnum");
    final By txtSWAcre = By.id("soilwaterconsrvacre");
    final By txtSWGunta = By.id("soilwaterconsrvgunta");
    
    //Present Trees
    final By drpDwnTreeType = By.id("treetype");
    final By drpDwnValTreeType = By.xpath("//md-option[@value='Horticultural']");
    final By drpDwnTreeName = By.id("treename");
    final By drpDwnValTreeName = By.xpath("//md-option[@value='Coconut']");
    final By txtTreeNumbers = By.id("treenumbers");
    
    //Family Liabilities
    final By drpDwnCreditSource = By.id("creditsource");
    final By drpDwnValCreditSource = By.xpath("//md-option[@value='Cooperative Bank']");
    final By txtBankName = By.id("bankname");
    final By txtBranch = By.id("branchname");
    final By txtPurpose = By.id("purpose");
    final By txtLoanAmount = By.id("loanamount");
    final By txtRateOfInterest = By.id("annualrateofinterest");
    final By txtBalance = By.id("balance");
    final By txtoverdues = By.id("overdues");
    final By drpDwnSecurityOffered = By.id("securityoffered");
    final By drpDwnValSecurityOffered = By.xpath("//md-option[@value='Mortgage']");
    
    //Family-Other Bank Dealings
    final By drpDwnType = By.id("type");
    final By drpDwnValType = By.xpath("//md-option[@value='Savings Account']");    
    final By txtAccountNumber = By.id("accountNumber");
    final By txtFamBalance = By.id("balance");
    
    //Training Requirement
    final By txtMemberName = By.id("memberName");
    final By txtTrainingType = By.id("trainingType");
    final By txtDepartment = By.id("department");
    
    //Family-Development Plan Needs
    final By drpDwnLivelihoodPlan = By.id("livelihoodplan");
    final By drpDwnValLivelihoodPlan = By.xpath("//md-option[@value='Check_dams']");
    final By txtDevPlanNumber = By.id("devplannumber");
    final By txtDevPlanAcre = By.id("devplanacre");
    final By txtDevPlanGunta = By.id("devplangunta");
    final By txtDevPlanInvestment = By.id("devplaninvestment");
    final By txtDevPlanDepartment = By.id("devplandepartment");
    
    //Indirect Liabilities as Guarantor
    final By txtBorrowerName = By.id("borrowername");
    final By txtLendingInstitution = By.id("lendinginstitution");
    final By txtLoanAmountNumber = By.id("loanamountnumber");
    final By txtGuarantorLoan = By.id("guarantorloan");
    final By txtGuarantorBalance = By.id("guarantorbalance");
    final By txtGuarantorOverdues = By.id("guarantoroverdues");
    
    //Application
    final By txtApplicationNo = By.id("applicationNo");
    final By dtpDateOfApplication = By.id("dateOfApplication");
    final By drpDwnexisitingCustomer = By.id("exisitingCustomer");
    final By drpDwnValexisitingCustomer = By.xpath("//md-option[@value='YES']");
    final By txtPanNumber = By.id("panNumber");
    final By txtSbAccountNumber = By.id("sbAccountNumber");
    final By txtSbAccountBalance = By.id("sbAccountBalance");
    final By drpDwnSalutationOfApplicant = By.id("salutationOfApplicant");
    final By drpDwnValSalutationOfApplicant = By.id("select_option_860");
    final By drpDwnCustomerTitle = By.id("customerTitle");
    final By drpDwnValCustomerTitle = By.id("select_option_862");
    final By drpDwnRelationshipWithFatherOrSpouse = By.id("relationshipWithFatherOrSpouse");
    final By drpDwnValRelationshipWithFatherOrSpouse = By.xpath("//md-option[@value='s/o']");
    final By txtNationality = By.id("nationality");
    final By txtMothersMaidenName = By.id("mothersMaidenName");
    final By drpDwnAppEducation = By.id("education");
    final By drpDwnValAppEducation = By.xpath("//md-option[@value='Post Graduate']");
    final By txtGuardianName = By.id("guardianName");
    final By drpDwnMaritalStatus = By.id("maritalStatus");   
    final By drpDwnValMaritalStatus = By.xpath("//md-option[@value='SINGLE']");
    final By drpDwnAppProfession = By.id("profession");
    final By drpDwnValAppProfession = By.xpath("//md-option[@value='Service State Government']");
    final By drpDwnMotherTongue = By.id("motherTongue");
    final By drpDwnValAppMotherTongue = By.xpath("//md-option[@value='Tamil']");
    final By drpDwnDisability = By.id("disability");
    final By drpDwnValAppDisability = By.xpath("//md-option[@value='Individual']");
    final By drpDwnBloodGroup = By.id("bloodGroup");
    final By drpDwnValBloodGroup = By.xpath("//md-option[@value='B+']");
    final By txtHouseNo = By.id("houseNo");
    final By txtPostOffice = By.id("postOffice");
    final By txtTalukOrMandal = By.id("talukOrMandal");
    //final By drpDwnCountry = By.id("countries");
    //final By valAppEducation = By.xpath("//md-option[@value='']")
    final By txtPinCode = By.id("pinCode");
    final By txtLandPhone = By.id("landPhone");
    final By txtApplicantEmailID = By.id("applicantEmailID");
    final By drpDwnRetiredDefencePerson = By.id("retiredDefencePerson");
    final By drpDwnValRetiredDefencePerson = By.id("select_option_920");
    final By drpDwnExServiceMen = By.id("exServiceMen");
    final By drpDwnValExServiceMen = By.id("select_option_922");
    final By drpDwnVillageCensus = By.id("villageCensus");
    final By drpDwnValDwnVillageCensus = By.xpath("//md-option[@value='Rural Population Less than 10,000']");
    final By drpDwnIdProofType = By.id("idProofType");
    final By drpDwnValAppIdProofType = By.xpath("//md-option[@value='PAN Card']");
    final By drpDwnAddProofType = By.id("addProofType");
    final By drpDwnValDwnAddProofType = By.xpath("//md-option[@value='Ration Card']");
    final By dtpDateOfApprisal = By.id("dateOfAppraisal");
    final By dtpDateOfProcess = By.id("dateOfProcess");
    final By dtpDateOfAgreement = By.id("dateOfAgreement");
    final By txtTdsCode = By.id("tdsCode");
    final By txtBranchCode = By.id("branchCode");
    final By drpDwnNomineeSalutation = By.id("nomineeSalutation");
    final By drpDwnValNomineeSalutation = By.id("select_option_945");
    final By txtNomineeName = By.id("nomineeName");
    final By drpDwnNomineeGender = By.id("gender");
    final By drpDwnValNomineeGender = By.xpath("//md-option[@value='Male']");
    final By drpDwnNomineeRelation = By.id("nomineeRelationWithApplicant");
    final By drpDwnValNomineeRelation = By.xpath("//md-option[@value='Father']");
    final By dtpNomineeDob = By.id("nomineeDob");
    //final By drpDwnNomineeCountry = By.id("nomineeCountry");
    //final By valNomineeCountry = By.xpath("//md-option[@value='']")
    final By txtNomineeState = By.id("nomineeState");
    final By txtNomineeCity = By.id("nomineeCity");
    final By txtNomineeZipCode = By.id("nomineeZipCode");    
    final By txtBeneficiaryName = By.id("beneficiaryName");
    final By dtpBeneficiaryDob = By.id("beneficiaryDob");
    final By txtBeneficiaryAddressLine1 = By.id("beneficiaryAddressLine1");
    final By txtBeneficiaryAddressLine2 = By.id("beneficiaryAddressLine2");
    final By drpDwnBeneficiarycountry = By.id("beneficiarycountry");
    final By drpDwnValBenAppEducation = By.xpath("//md-option[@value='']");
    final By txtBeneficiaryState = By.id("beneficiaryState");
    //final By txtBeneficiaryCity = By.id("beneficiaryCity	");
    final By txtCustomerId = By.id("customerId");
    final By txtAccountNumber_319 = By.id("accountNumber_319");
    
	@Override
	protected void load() {
		logger.debug("SurveyPage {} load() ", this.getClass().getName());
	}

	@Override
	protected void isLoaded() throws Error {
		logger.debug("SurveyPage {} isLoaded() ", this.getClass().getName());
		this.init();
		homePageTabs = (HomePageTabs) new HomePageTabs().get();
	}
	
	public void clickCustomerData() {
		homePageTabs.clickCustomerData();
	}
	
	public void clickCustomerData_Survey() {
		homePageTabs.clickCustomerDataSurvey();
	}
	
	public void addNewCustomerSurveyDetails() {
		clickCustomerData();
		clickCustomerData_Survey();
	}
	
	public void fillGeneralInfo() {
		waitUntilElementPresent(btnAddNewSurvey); // Add in to isLoaded
		click(btnAddNewSurvey);
		waitUntilLoadedAndTextPresentInElement(txtGeneral,GROUP_TEXT);
		
		waitUntilLoadedAndElementClickable(chkBoxFamilyHead);
		
		type(DataManager.randomIdentifier(), txtApplicantName);
		jsClick(chkBoxFamilyHead);
		TimeManager.waitInSeconds(TimeEntity.SEC_5.getSeconds());
		waitUntilLoadedAndElementClickable(dtpDob);
		click(dtpDob);
		waitUntilLoadedAndElementClickable(dtpDate);
		click(dtpDate);
		
		jsClick(drpDwnCaste);
		waitUntilLoadedAndElementClickable(drpDwnValCasteOBC);
		jsClick(drpDwnValCasteOBC);
		type(DataManager.randomIdentifier(), txtFatherName);
		
		jsClick(drpDwnRelationship);
		waitUntilLoadedAndElementClickable(drpDwnValRelation);
		jsClick(drpDwnValRelation);
		
		/*jsClick(drpDwnMinorityReligion );
		waitUntilLoadedAndElementClickable(drpDwnValMinReligion);
		jsClick(drpDwnValMinReligion);*/
		
		jsClick(drpDwnHandicapped);
		waitUntilLoadedAndElementClickable(drpDwnValHandicapped);
		jsClick(drpDwnValHandicapped);
		
		jsClick(drpDwnRationCardType);
		waitUntilLoadedAndElementClickable(drpDwnValRationCardType);
		jsClick(drpDwnValRationCardType);
		
		jsClick(drpDwnHealthInsurance);
		waitUntilLoadedAndElementClickable(drpDwnValHealthInsurance);
		jsClick(drpDwnValHealthInsurance);
		
		jsClick(drpDwnState);
		waitUntilLoadedAndElementClickable(drpDwnValState);
		jsClick(drpDwnValState);
		
		jsClick(drpDwnDistrict);
		waitUntilLoadedAndElementClickable(drpDwnValDistrict);
		jsClick(drpDwnValDistrict);
		
		jsClick(drpDwnSubDistrict);
		waitUntilLoadedAndElementClickable(drpDwnValSubDistrict);
		jsClick(drpDwnValSubDistrict);
		
		jsClick(drpDwnVillage);
		waitUntilLoadedAndElementClickable(drpDwnValVillage);
		jsClick(drpDwnValVillage);
		
		type(DataManager.randomIdentifier(), txtGramPanchayat);
		type(DataManager.randomIdentifier(),txtHobli);
		type(DataManager.randomIdentifier(),txtCurrentAddress);
		type(DataManager.randomIdentifier(),txtPermanentAddress);
		
		jsClick(drpDwnHouseType);
		waitUntilLoadedAndElementClickable(drpDwnValHouseType);
		jsClick(drpDwnValHouseType);
		
		jsClick(drpDwnReligion);
		waitUntilLoadedAndElementClickable(drpDwnValReligion);
		jsClick(drpDwnValReligion);
		
		jsClick(drpDwnApplicantCaste);
		waitUntilLoadedAndElementClickable(drpDwnValApplicantCaste);
		jsClick(drpDwnValApplicantCaste);
		
		click(btnNext);
	}
	
	public void fillEntitlementRecords() {
		TimeManager.waitInSeconds(TimeEntity.SEC_1.getSeconds());
		
		jsClick(drpDwnRationCard);
		waitUntilLoadedAndElementClickable(drpDwnValRationCard);
		jsClick(drpDwnValRationCard);
		
		click(drpDwnJobCard);
		waitUntilLoadedAndElementClickable(drpDwnValJobCard);
		jsClick(drpDwnValJobCard);
		
		click(drpDwnOldAgePension);
		waitUntilLoadedAndElementClickable(drpDwnValOldAgePension);
		jsClick(drpDwnValOldAgePension);
		
		click(drpDwnWidowRelief);
		waitUntilLoadedAndElementClickable(drpDwnValWidowRelief);
		jsClick(drpDwnValWidowRelief);
		
		click(drpDwnPhysicallyHandicapped);
		waitUntilLoadedAndElementClickable(drpDwnValPhysicallyHandicapped);
		jsClick(drpDwnValPhysicallyHandicapped);
		
		click(drpDwnScholarship);
		waitUntilLoadedAndElementClickable(drpDwnValScholarship);
		jsClick(drpDwnValScholarship);
		
		click(drpDwnOthers);
		waitUntilLoadedAndElementClickable(drpDwnValOthers);
		jsClick(drpDwnValOthers);
		
		click(drpDwnToilet);
		waitUntilLoadedAndElementClickable(drpDwnValToilet);
		jsClick(drpDwnValToilet);
		
		click(navFamily);
	}
	
	public void fillFamilyMemberDetails() {
		click(icnExpand);
		
		TimeManager.waitInSeconds(TimeEntity.SEC_1.getSeconds());
		type(DataManager.randomIdentifier(), txtFamilyName);
		
		click(drpDwnGender);
		waitUntilLoadedAndElementClickable(drpDwnValGender);
		jsClick(drpDwnValGender);
		
		click(drpDwnEducation);
		waitUntilLoadedAndElementClickable(drpDwnValEducation);
		jsClick(drpDwnValEducation);
		
		click(drpDwnProfession);
		waitUntilLoadedAndElementClickable(drpDwnValProfession);
		jsClick(drpDwnValProfession);
		
		click(drpDwnAgriInterest);
		waitUntilLoadedAndElementClickable(drpDwnValAgriInterest);
		jsClick(drpDwnValAgriInterest);
		
		type("1234567890", txtMobilenumber);
		type("999999999999", txtAdhaarnumber);
		type("ASD12345678", txtVoterIdNumber);
		type("DL1234545412347", txtDlNumber);
		type("1234567890", txtNareganumber);
		
		click(btnAdd);
		click(btnNext);		
	}
	
	public void fillFamilyAnnualIncome() {
		click(icnExpand);
		TimeManager.waitInSeconds(TimeEntity.SEC_1.getSeconds());
		
		click(drpDwnSource);
		waitUntilLoadedAndElementClickable(drpDwnValSource);
		jsClick(drpDwnValSource);
		
		type("500000", txtAnnualIncome);
		type("250000", txtAnnualExpence);
		
		click(btnAdd);
		click(btnNext);
	}
	
	public void fillLandOwnedInfo() {
		click(icnExpand);
		TimeManager.waitInSeconds(TimeEntity.SEC_1.getSeconds());
		
		type(DataManager.randomIdentifier(), txtVillageName);
		type(DataManager.randomNumberGenerator(), txtSurveyNumber);
		
		click(drpDwnOwnedOrLeased);
		waitUntilLoadedAndElementClickable(drpDwnValOwnedOrLeased);
		jsClick(drpDwnValOwnedOrLeased);
		
		
		type("100", txtAcre);
		type("35", txtGunta);
		type(DataManager.randomNumberGenerator(), txtTax);
		type("90", txtTax);
		type(DataManager.randomNumberGenerator(), txtSurveyNumber);
		
		click(drpDwnIrrigationSource );
		waitUntilLoadedAndElementClickable(drpDwnValIrrigationSource);
		jsClick(drpDwnValIrrigationSource);
		
		type("75", txtIrrigationAcre);
		type("30", txtIrrigationGunta );
		type(DataManager.randomIdentifier(), txtEncumberance);
		
		click(btnAdd);
		click(btnNext);		
	}
	
	public void fillLandAndCorpInfo() {
		click(icnExpand);
		TimeManager.waitInSeconds(TimeEntity.SEC_1.getSeconds());
		
		click(drpDwnCorp);
		waitUntilLoadedAndElementClickable(drpDwnValCorp);
		jsClick(drpDwnValCorp);
		
		click(drpDwnSeason);
		waitUntilLoadedAndElementClickable(drpDwnValSeason);
		jsClick(drpDwnValSeason);
		
		type(DataManager.randomIdentifier(), txtLCVillageName);
		type(DataManager.randomNumberGenerator(), txtLCSurveyNumber);
		
		type("100", txtLCAcre);
		type("35", txtLCGunta);
		
		click(btnAdd);
		click(btnNext);
	}
	
	public void fillLiveStocksInfo() {
		click(icnExpand);
		TimeManager.waitInSeconds(TimeEntity.SEC_1.getSeconds());
		
		click(drpDwnLiveStocks);
		waitUntilLoadedAndElementClickable(drpDwnValLiveStocks);
		jsClick(drpDwnValLiveStocks);
		
		type(DataManager.randomNumberGenerator(), txtNumbers);	
		type(DataManager.randomNumberGenerator(), txtValue);
		type(DataManager.randomNumberGenerator(), txtAnnualStockIncome);
		type(DataManager.randomNumberGenerator(), txtAnnualExpenditure);
		
		click(drpDwnInsurance);
		waitUntilLoadedAndElementClickable(drpDwnValInsurance);
		jsClick(drpDwnValInsurance);
		
		click(btnAdd);
		click(btnNext);
	}
	public void fillImmovableAssetsInfo() {
		click(icnExpand);
		TimeManager.waitInSeconds(TimeEntity.SEC_1.getSeconds());
		
		click(drpDwnImovableAssetType);
		waitUntilLoadedAndElementClickable(drpDwnValImovableAssetType);
		jsClick(drpDwnValImovableAssetType);
		
		type(DataManager.randomNumberGenerator(), txtImovableAssetNumbers);	
		type(DataManager.randomNumberGenerator(), txtImovableAssetValues);
		
		click(btnAdd);
		click(btnNext);
	}
	
	public void fillMovableAssetsInfo() {
		click(icnExpand);
		TimeManager.waitInSeconds(TimeEntity.SEC_1.getSeconds());
		
		click(drpDwnMovableAssetType);
		waitUntilLoadedAndElementClickable(drpDwnValMovableAssetType);
		jsClick(drpDwnValMovableAssetType);
		
		type(DataManager.randomNumberGenerator(), txtMovableAssetNumbers);	
		type(DataManager.randomNumberGenerator(), txtMovableAssetValues);
		
		click(btnAdd);
		click(btnNext);
	}
	
	public void fillSoilAndWaterInfo() {
		click(icnExpand);
		TimeManager.waitInSeconds(TimeEntity.SEC_1.getSeconds());
		
		click(drpDwnStructures);
		waitUntilLoadedAndElementClickable(drpDwnValStructures);
		jsClick(drpDwnValStructures);
		
		type(DataManager.randomNumberGenerator(), txtSWNumbers);	
		type("50", txtSWAcre);
		type("20", txtSWGunta);
		
		click(btnAdd);
		click(btnNext);
	}
	
	public void fillPresentTreesrInfo() {
		click(icnExpand);
		TimeManager.waitInSeconds(TimeEntity.SEC_1.getSeconds());
		
		click(drpDwnTreeType);
		waitUntilLoadedAndElementClickable(drpDwnValTreeType);
		jsClick(drpDwnValTreeType);
		
		click(drpDwnTreeName);
		waitUntilLoadedAndElementClickable(drpDwnValTreeName);
		jsClick(drpDwnValTreeName);
		
		type("500", txtTreeNumbers);
		
		click(btnAdd);
		click(btnNext);
	}
	
	public void fillFamilyLiabilitiesInfo() {
		click(icnExpand);
		TimeManager.waitInSeconds(TimeEntity.SEC_1.getSeconds());
		
		click(drpDwnCreditSource);
		waitUntilLoadedAndElementClickable(drpDwnValCreditSource);
		jsClick(drpDwnValCreditSource);
		
		type(DataManager.randomIdentifier(), txtBankName);
		type(DataManager.randomIdentifier(), txtBranch);
		type(DataManager.randomIdentifier(), txtPurpose);
		type("10000", txtLoanAmount);
		type("8.9", txtRateOfInterest);
		type("8000", txtBalance);
		type("1000", txtoverdues);
		
		click(drpDwnSecurityOffered);
		waitUntilLoadedAndElementClickable(drpDwnValSecurityOffered);
		jsClick(drpDwnValSecurityOffered);
		
		click(btnAdd);
		click(btnNext);
	}
	
	public void fillOtherBankInfo() {
		click(icnExpand);
		TimeManager.waitInSeconds(TimeEntity.SEC_1.getSeconds());
		
		click(drpDwnType);
		waitUntilLoadedAndElementClickable(drpDwnValType);
		jsClick(drpDwnValType);
		
		type(DataManager.randomNumberGenerator(), txtAccountNumber);
		type(DataManager.randomNumberGenerator(), txtFamBalance);
		
		click(btnAdd);
		click(btnNext);
	}
	
	public void fillTrainingRequirementsInfo() {
		click(icnExpand);
		type(DataManager.randomIdentifier(), txtMemberName);
		type(DataManager.randomIdentifier(), txtTrainingType);
		type(DataManager.randomIdentifier(), txtDepartment);
		click(btnAdd);
		click(btnNext);
	}
	
	public void fillFamilyDevelopmentPlanInfo() {
		click(icnExpand);
		
		click(drpDwnLivelihoodPlan);
		waitUntilLoadedAndElementClickable(drpDwnValLivelihoodPlan);
		jsClick(drpDwnValLivelihoodPlan);
		
		type(DataManager.randomNumberGenerator(), txtDevPlanNumber);
		type(DataManager.randomNumberGenerator(), txtDevPlanAcre);
		type("35", txtDevPlanGunta);
		type(DataManager.randomNumberGenerator(), txtDevPlanInvestment);
		type(DataManager.randomIdentifier(), txtDevPlanDepartment);
		click(btnAdd);
		click(btnNext);		
	}
	
	public void fillIndirectLiabilitiesInfo() {
		click(icnExpand);
		
		type(DataManager.randomIdentifier(), txtBorrowerName);
		type(DataManager.randomIdentifier(), txtLendingInstitution);
		type(DataManager.randomNumberGenerator(), txtLoanAmountNumber);
		type(DataManager.randomNumberGenerator(), txtGuarantorLoan);
		type(DataManager.randomNumberGenerator(), txtGuarantorBalance);
		type(DataManager.randomNumberGenerator(), txtGuarantorOverdues);
		click(btnAdd);
		click(btnNext);		
	}
	
	public void fillApplicationInfo() throws AWTException {
		click(icnExpand);
		type(DataManager.randomNumberGenerator(), txtApplicationNo);
		
		click(drpDwnexisitingCustomer);
		waitUntilLoadedAndElementClickable(drpDwnValexisitingCustomer);
		jsClick(drpDwnValexisitingCustomer);
		
		type("ASDQW6754B", txtPanNumber);
		type(DataManager.randomNumberGenerator(), txtSbAccountNumber);
		type(DataManager.randomNumberGenerator(), txtSbAccountBalance);
				
		click(drpDwnSalutationOfApplicant);
		waitUntilLoadedAndElementClickable(drpDwnValSalutationOfApplicant);
		jsClick(drpDwnValSalutationOfApplicant);
		
		click(drpDwnCustomerTitle);
		waitUntilLoadedAndElementClickable(drpDwnValCustomerTitle);
		jsClick(drpDwnValCustomerTitle);
		
		click(drpDwnRelationshipWithFatherOrSpouse);
		waitUntilLoadedAndElementClickable(drpDwnValRelationshipWithFatherOrSpouse);
		jsClick(drpDwnValRelationshipWithFatherOrSpouse);
		
		type(DataManager.randomIdentifier(), txtMothersMaidenName);
		
		click(drpDwnAppEducation);
		waitUntilLoadedAndElementClickable(drpDwnValAppEducation);
		jsClick(drpDwnValAppEducation);
		
		type(DataManager.randomIdentifier(), txtGuardianName);
		
		click(drpDwnMaritalStatus);
		waitUntilLoadedAndElementClickable(drpDwnValMaritalStatus);
		jsClick(drpDwnValMaritalStatus);
		
		click(drpDwnAppProfession);
		waitUntilLoadedAndElementClickable(drpDwnValAppProfession);
		jsClick(drpDwnValAppProfession);
		
		click(drpDwnMotherTongue);
		waitUntilLoadedAndElementClickable(drpDwnValAppMotherTongue);
		jsClick(drpDwnValAppMotherTongue);
		
		click(drpDwnDisability);
		waitUntilLoadedAndElementClickable(drpDwnValAppDisability);
		jsClick(drpDwnValAppDisability);
		
		click(drpDwnBloodGroup);
		waitUntilLoadedAndElementClickable(drpDwnValBloodGroup);
		jsClick(drpDwnValBloodGroup);
		
		type(DataManager.randomNumberGenerator(), txtHouseNo);
		type(DataManager.randomIdentifier(), txtPostOffice);
		type(DataManager.randomIdentifier(), txtTalukOrMandal);
		type("123456",txtPinCode);
		type("01212345678", txtLandPhone);
		type("test@test.com", txtApplicantEmailID);
				
		click(drpDwnRetiredDefencePerson);
		waitUntilLoadedAndElementClickable(drpDwnValRetiredDefencePerson);
		jsClick(drpDwnValRetiredDefencePerson);
		
		click(drpDwnExServiceMen);
		waitUntilLoadedAndElementClickable(drpDwnValExServiceMen);
		jsClick(drpDwnValExServiceMen);
		
		click(drpDwnVillageCensus);
		waitUntilLoadedAndElementClickable(drpDwnValDwnVillageCensus);
		jsClick(drpDwnValDwnVillageCensus);
		
		click(drpDwnIdProofType);
		waitUntilLoadedAndElementClickable(drpDwnValAppIdProofType);
		jsClick(drpDwnValAppIdProofType);
		
		click(drpDwnAddProofType);
		waitUntilLoadedAndElementClickable(drpDwnValDwnAddProofType);
		jsClick(drpDwnValDwnAddProofType);
		
		type(DataManager.randomNumberGenerator(), txtTdsCode);
		type(DataManager.randomNumberGenerator(), txtBranchCode);
		
		click(drpDwnNomineeSalutation);
		waitUntilLoadedAndElementClickable(drpDwnValNomineeSalutation);
		jsClick(drpDwnValNomineeSalutation);
		
		type(DataManager.randomIdentifier(), txtNomineeName);
				
		click(drpDwnNomineeGender);
		waitUntilLoadedAndElementClickable(drpDwnValNomineeGender);
		jsClick(drpDwnValNomineeGender);
		
		click(drpDwnNomineeRelation);
		waitUntilLoadedAndElementClickable(drpDwnValNomineeRelation);
		jsClick(drpDwnValNomineeRelation);
		
		click(dtpNomineeDob);
		String currentMMMYYYY = getMonthYear();
		
		By calMonthYear = By.xpath("//span[text()='"+currentMMMYYYY+"']");
		jsClick(calMonthYear);
		Actions act = new Actions(driver);
		WebElement cal = driver.findElement(By.xpath("//div[@id='md-date-pane847']"));
		act.moveToElement(cal).clickAndHold().build().perform();
		
		
		/*JavascriptExecutor Scrool = (JavascriptExecutor) driver;
		Scrool.executeScript("window.scrollTo(0,-3000)", "");*/
		
		Point p =cal.getLocation();
		Robot robot = new Robot();

	    robot.mouseMove(p.getX()+100,p.getY()+100);

	    robot.mousePress(InputEvent.BUTTON1_MASK);
	    robot.mouseRelease(InputEvent.BUTTON1_MASK);
	    robot.mouseWheel(-20000);
	    
		TimeManager.waitInSeconds(TimeEntity.SEC_5.getSeconds());
		
		type(DataManager.randomIdentifier(), txtNomineeState);
		type(DataManager.randomIdentifier(), txtNomineeCity);
		type("123456", txtNomineeZipCode);
		type(DataManager.randomNumberGenerator(), txtCustomerId);
		type(DataManager.randomNumberGenerator(),txtAccountNumber_319);
		
		click(btnSubmit);
	}
	
	public String getMonthYear(){
		 Date date = new Date();
		 
         SimpleDateFormat sdf = new SimpleDateFormat("MMM");
         String month = sdf.format(date).toString();

         Format formatter = new SimpleDateFormat("yyyy");
         String s = formatter.format(new Date());
        
         String str = month+" "+s;
         System.out.println(str);
         return str;
	}
	
	
}
