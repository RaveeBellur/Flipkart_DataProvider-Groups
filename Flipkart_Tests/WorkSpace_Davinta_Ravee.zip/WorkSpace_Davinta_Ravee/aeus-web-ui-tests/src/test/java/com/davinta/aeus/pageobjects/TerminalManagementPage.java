package com.davinta.aeus.pageobjects;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.data.utils.DataManager;
import com.davinta.webdriver.main.PageObject;

public class TerminalManagementPage extends PageObject { 
	final Logger logger=LoggerFactory.getLogger(this.getClass().getName());
	HomePageTabs homePageTabs;

	//Terminal Management Elements
	final By btnAddTerminal=By.xpath("//div/div/div/button");
	final By txtBankTerminalCode=By.id("bankTerminalCode");
	final By txtBankTerminalLocation=By.id("bankTerminalLocation");
	final By txtTerminalName=By.id("terminalName");
	final By drpDwnDeviceType=By.id("deviceCode");
	final By drpDwnValTablet=By.xpath(("//md-option/div[text()='Tablet']"));
	final By drpDwnValFP=By.xpath(("//md-option/div[contains(text(),'Finger Print Scanner')]"));
	final By drpDwnValPax=By.xpath(("//md-option/div[contains(text(),'PAX Device')]"));
	final By drpDwnValDeviceType=By.xpath("//md-option[@role='option']");
	final By txtImeiNo=By.id("imeiNo");
	final By txtManufacturerName=By.id("manufacturerName");
	final By btnAddDevice=By.xpath("//span[text()='Add Device']");
	final By txtSerialNo=By.id("serialNo");
	final By txtBluetoothName=By.id("bluetoothName");
	final By txtBluetoothAddress=By.id("bluetoothAddress");
	final By txtManufactureName=By.id("manufacturerName");
	final By deviceTablet=By.xpath("//md-card-title-text/span[text()='Tablet']");
	final By deviceFP=By.xpath("//md-card-title-text/span[contains(text(),'Finger Print Scanner')]");
	final By devicePax=By.xpath("//md-card-title-text/span[contains(text(),'PAX Device')]");
	
	@Override
	protected void load() {

	}

	@Override
	protected void isLoaded() throws Error {
		logger.debug("TerminalManagementPage {} isLoaded() ", this.getClass().getName());
		this.init();
		homePageTabs=(HomePageTabs) new HomePageTabs().get();

	}

	public void clickAgencyBanking() {
		homePageTabs.clickAgencyBanking();
	}

	public void clickAgencyBankingDevicesTerminals() {
		homePageTabs.clickAgencyBankingDevicesTerminals();
	}

	public void clickAgencyBankingDevicesTerminalsTerminal() {

		homePageTabs.clickAgencyBankingDevicesTerminalsTerminal();
	}

	public void addTerminal() {
		clickAgencyBanking();
		clickAgencyBankingDevicesTerminals();
		clickAgencyBankingDevicesTerminalsTerminal();

		waitUntilLoadedAndElementClickable(btnAddTerminal);
		jsClick(btnAddTerminal);

		type("12345678",txtBankTerminalCode);
		type(DataManager.randomIdentifier(), txtBankTerminalLocation);
		type(DataManager.randomIdentifier(),txtTerminalName);

	}

	public void addTablet() throws InterruptedException{

		waitUntilLoadedAndElementClickable(drpDwnDeviceType);
		jsClick(drpDwnDeviceType);
		waitUntilLoadedAndElementClickable(drpDwnValTablet);
		jsClick(drpDwnValTablet);
		type("132345344657766", txtImeiNo);
		type(DataManager.randomIdentifier(),txtManufacturerName);
		waitUntilLoadedAndElementClickable(btnAddDevice);
		click(btnAddDevice);
		
		/*List<WebElement> allDeviceType= findElements(drpDwnValDeviceType);
		for (WebElement deviceType: allDeviceType){

			String strDeviceType=deviceType.getText();
			System.out.println("++++++++++++++++++++++++++>>>>>"+strDeviceType);

			if (strDeviceType.equalsIgnoreCase("Tablet")){
				click(deviceType);
				System.out.println("=====>>>>Tablet selected");
				type("132345344657766", txtImeiNo);

				type(DataManager.randomIdentifier(),txtManufacturerName);
				waitUntilLoadedAndElementClickable(btnAddDevice);
				click(btnAddDevice);
				break;

			}


			else{
				logger.info("Required Device Type Tablet is not present in the dropdown list");
			}

		}*/


	}
	public void addFingerPrint() {

		waitUntilLoadedAndElementClickable(drpDwnDeviceType);
		jsClick(drpDwnDeviceType);
		waitUntilLoadedAndElementClickable(drpDwnValFP);
		jsClick(drpDwnValFP);
		
		/*List<WebElement> allDeviceType= findElements(drpDwnValDeviceType);
		for (WebElement deviceType: allDeviceType){

			String strDeviceType=deviceType.getText();
			System.out.println("++++++++++++++++++++++++++>>>>>"+strDeviceType);

			if (strDeviceType.equalsIgnoreCase("Finger Print Scanner")){
				click(deviceType);
				System.out.println("=====>>>>Finger Print Scanner selected");
				click(deviceType);
				System.out.println("=====>>>>Tablet selected");
				type("132345344657766", txtImeiNo);

				type(DataManager.randomIdentifier(),txtManufacturerName);
				waitUntilLoadedAndElementClickable(btnAddDevice);
				click(btnAddDevice);
				
				break;

			}


			else{
				logger.info("Required Device Type finger print is not present in the dropdown list");
			}
*/
		}


	

	public void addPax() {

		waitUntilLoadedAndElementClickable(drpDwnDeviceType);
		jsClick(drpDwnDeviceType);
		waitUntilLoadedAndElementClickable(drpDwnValPax);
		jsClick(drpDwnValPax);
		/*List<WebElement> allDeviceType= findElements(drpDwnValDeviceType);
		for (WebElement deviceType: allDeviceType){
			String strDeviceType=deviceType.getText();
			System.out.println("++++++++++++++++++++++++++>>>>>"+strDeviceType);

			if (strDeviceType.equalsIgnoreCase("PAX Device")){

				click(deviceType);
				System.out.println("=====>>>>PAX Device selected");
				//waitUntilLoadedAndElementClickable(drpDwnValDeviceType);

				click(deviceType);
				System.out.println("=====>>>>Tablet selected");
				type("132345344657766", txtImeiNo);

				type(DataManager.randomIdentifier(),txtManufacturerName);
				waitUntilLoadedAndElementClickable(btnAddDevice);
				click(btnAddDevice);
				
				break;

			}


			else{
				logger.info("Required Device Type Pax is not present in the dropdown list");
			}

		}*/


	}

}



