package com.davinta.aeus.pageobjects;

import java.util.List;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.aeus.resources.DbChecker;
import com.davinta.data.utils.DataManager;
import com.davinta.webdriver.main.PageObject;
import com.davinta.webdriver.utils.TimeEntity;
import com.davinta.webdriver.utils.TimeManager;

public class UserOnboardPage extends PageObject {
	final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
	DbChecker dbChecker =new DbChecker();
	HomePageTabs homePageTabs;
	CommonActionsPage rolePage;
	
	final By btnUserInfoPageNext=By.id("gotoUserRolesbtnId");
	final By btnAddressPageBack=By.id("backtoUserAddressbtnId");
	final By btnAddressPageSave=By.id("gotoUserCreationbtnId");
	
	 //Failure PopUp for existing Aadhaar number
	final String AADHAAR_NUMBER= "383742448358";
    final By popUpAadharNo=By.xpath("//p[contains(text(),'User already exists with aadhar number')]");
    final By btnPopUpOk = By.xpath("//span[contains(text(),'Ok')]");
    
    @Override
	protected void isLoaded() throws Error {
		logger.debug("UserPage {} isLoaded() ", this.getClass().getName());
		this.init();
		homePageTabs = (HomePageTabs) new HomePageTabs().get();
		rolePage = (CommonActionsPage) new CommonActionsPage().get();
	}

	@Override
	protected void load() {
		logger.debug("UserPage {} load() ", this.getClass().getName());
	}
    
    public void clickAgencyBanking(){
		homePageTabs.clickAgencyBanking();
	}
    public void clickAgencyBankingOnboard() {
    	homePageTabs.clickAgencyBankingOnboard();
	}
	public void clickAgencyBankingOnboardUser(){
		homePageTabs.clickAgencyBankingOnboardUser();
	}
    
    public void userInformation(){
    	clickAgencyBanking();
    	clickAgencyBankingOnboard();
    	clickAgencyBankingOnboardUser();
        waitUntilLoadedAndElementClickable(CommonElements.drpDwnTitle);
        jsClick(CommonElements.drpDwnTitle);
        waitUntilLoadedAndElementClickable(CommonElements.drpDwnValTitle);
        jsClick(CommonElements.drpDwnValTitle);

        type(DataManager.randomIdentifier(),CommonElements.txtFirstName );
        type(DataManager.randomIdentifier(),CommonElements.txtLastName );

        type(AADHAAR_NUMBER,CommonElements.txtAadharNumber);

        waitUntilLoadedAndElementClickable(CommonElements.drpDwnLanguage);
        jsClick(CommonElements.drpDwnLanguage);
        waitUntilLoadedAndElementClickable(CommonElements.drpDwnValLanguage);
        jsClick(CommonElements.drpDwnValLanguage);

        waitUntilLoadedAndElementClickable(CommonElements.drpDwnUserType);
        jsClick(CommonElements.drpDwnUserType);
        waitUntilLoadedAndElementClickable(CommonElements.drpDwnValUserType);
        jsClick(CommonElements.drpDwnValUserType);

        click(btnUserInfoPageNext,TimeEntity.SEC_10.getSeconds());
        }
    
    public void roleAssignment(List<String> lstRoles) throws InterruptedException{
    	rolePage.roleAssignment(lstRoles);
    }
    
    public void addAddress(){
        waitUntilLoadedAndElementClickable(CommonElements.btnAddOfficeAddress);
        jsClick(CommonElements.btnAddOfficeAddress);
        waitUntilLoadedAndElementClickable(CommonElements.txtAddressLine1);
        type(DataManager.randomIdentifier(), CommonElements.txtAddressLine1);
        waitUntilLoadedAndElementClickable(CommonElements.txtAddressLine2);
        type(DataManager.randomIdentifier(), CommonElements.txtAddressLine2);
       
        waitUntilLoadedAndElementClickable(CommonElements.drpDwnCountry);
        jsClick(CommonElements.drpDwnCountry);
        waitUntilLoadedAndElementClickable(CommonElements.drpDwnValCountry);
        jsClick(CommonElements.drpDwnValCountry);
        
        waitUntilLoadedAndElementClickable(CommonElements.drpDwnState);
        jsClick(CommonElements.drpDwnState);
        waitUntilLoadedAndElementClickable(CommonElements.drpDwnValState);
        jsClick(CommonElements.drpDwnValState);
        
        waitUntilLoadedAndElementClickable(CommonElements.drpDwnDistrict);
        jsClick(CommonElements.drpDwnDistrict);
        waitUntilLoadedAndElementClickable(CommonElements.drpDwnValDistrict);
        jsClick(CommonElements.drpDwnValDistrict);
        
        TimeManager.waitInSeconds(TimeEntity.SEC_1.getSeconds());
        waitUntilLoadedAndElementClickable(CommonElements.drpDwnSubDistrict);
        jsClick(CommonElements.drpDwnSubDistrict);
        waitUntilLoadedAndElementClickable(CommonElements.drpDwnValSubDistrict);
        jsClick(CommonElements.drpDwnValSubDistrict);
        
        TimeManager.waitInSeconds(TimeEntity.SEC_1.getSeconds());
        waitUntilLoadedAndElementClickable(CommonElements.drpDwnTown);
        jsClick(CommonElements.drpDwnTown);
        waitUntilLoadedAndElementClickable(CommonElements.drpDwnValTown);
        jsClick(CommonElements.drpDwnValTown);
        
        type("560100",CommonElements.txtZipCode);
        waitUntilLoadedAndElementClickable(CommonElements.chkbxAddressVerified);
        jsClick(CommonElements.chkbxAddressVerified);
        waitUntilLoadedAndElementClickable(CommonElements.btnSave);
        jsClick(CommonElements.btnSave);
        }

     public void addPrimaryContact() throws Throwable{
        waitUntilLoadedAndElementClickable(CommonElements.btnAddPrimaryContact);
        jsClick(CommonElements.btnAddPrimaryContact);
        waitUntilLoadedAndElementClickable(CommonElements.lablJobTitle);
        jsClick(CommonElements.lablJobTitle);
        type("AUTOMATION",CommonElements.txtJobTitle);
        waitUntilLoadedAndElementClickable(CommonElements.txtMobileNumber);
        jsClick(CommonElements.lablMobileNumber);
        type("9945686900",CommonElements.txtMobileNumber);
        waitUntilLoadedAndElementClickable(CommonElements.btnSave);
        jsClick(CommonElements.btnSave);
        TimeManager.waitInSeconds(TimeEntity.SEC_1.getSeconds());
       
        click(btnAddressPageSave,TimeEntity.SEC_5.getSeconds());
        if(isDisplayed(popUpAadharNo))
        {
        	click(btnPopUpOk,TimeEntity.SEC_10.getSeconds());
        	logger.error("Failure Message : Aadhar Number Already Exist");
        	dbChecker.deleteUserByAadhaar(AADHAAR_NUMBER);
        	click(btnAddressPageBack,5);
        }
        else
        {
        	logger.info("Aadhar number doesn't exists");
        }
        }
}
