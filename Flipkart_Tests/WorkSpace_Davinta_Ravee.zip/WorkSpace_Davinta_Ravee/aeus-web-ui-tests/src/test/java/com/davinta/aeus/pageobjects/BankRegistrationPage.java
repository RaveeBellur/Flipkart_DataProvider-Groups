package com.davinta.aeus.pageobjects;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.data.utils.DataManager;
import com.davinta.webdriver.main.PageObject;
import com.davinta.webdriver.utils.TimeEntity;

public class BankRegistrationPage extends PageObject {
	final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
	public String agentID;
	HomePageTabs homePageTabs;

	final By txtSearch=By.id("filterunRegisteredAgent");
	final By radiobtnSelect=By.xpath("//table/tbody/tr[1]/td[2]");
	final By btnProceed=By.xpath("//span[text()='PROCEED']");
	final By drpdwnBankName = By.id("bankName");
	final By drpdwnValBankName= By.id("agentBankRegistrationName");
	final By txtBankAgentId = By.id("bankagentID");
	final By txtRegisterationId = By.id("registrationID");
	final By calbtnRegistrationDate = By.xpath("//md-datepicker[@id='registrationDate']/button");
	final By calbtnRegistrationEffDate=By.xpath("//md-datepicker[@id='registrationEffectivefrom']/button");
	final By calbtnRegistrationExpDate=By.xpath("//md-datepicker[@id='registrationExpiryDate']/button");
	final By calTodaysDate=By.xpath("//td[@class='md-calendar-date md-calendar-date-today md-focus']");
	final By txtSettlementAccountNumber = By.id("accountNumber");
	final By btnSubmit=By.xpath("//span[text()='Submit']");

	@Override
	protected void isLoaded() throws Error {
		logger.debug("BankRegistartion {} isLoaded() ",this.getClass().getName());
		this.init();
		homePageTabs = (HomePageTabs) new HomePageTabs().get();
	}
	@Override
	protected void load() {
		logger.debug("BankRegistration {} load()",this.getClass().getName());
	}

	public void clickAgencyBanking() {
		homePageTabs.clickAgencyBanking();
	}

	public void clickAgencyBankingOnboard() {
		homePageTabs.clickAgencyBankingOnboard();
	}	

	public void clickAgencyBankingOnboardAgentBankReg() {
		homePageTabs.clickAgencyBankingOnboardAgentBankReg();
	}

	public void addBankRegistration(String agentID){
		clickAgencyBanking();
		clickAgencyBankingOnboard();
		clickAgencyBankingOnboardAgentBankReg();

		type(agentID, txtSearch);
		click(radiobtnSelect,TimeEntity.SEC_10.getSeconds());
		click(btnProceed,TimeEntity.SEC_10.getSeconds());
	}

	public void bankRegistrationDetails(){
		waitUntilLoadedAndElementClickable(drpdwnBankName);
		jsClick(drpdwnBankName);

		waitUntilLoadedAndElementClickable(drpdwnValBankName);
		jsClick(drpdwnValBankName);

		type("00015",txtBankAgentId);
		type(DataManager.randomNumberGenerator(),txtRegisterationId);

		waitUntilLoadedAndElementClickable(calbtnRegistrationDate);
		jsClick(calbtnRegistrationDate);

		waitUntilLoadedAndElementClickable(calTodaysDate);
		jsClick(calTodaysDate);

		waitUntilLoadedAndElementClickable(calbtnRegistrationEffDate);
		jsClick(calbtnRegistrationEffDate);

		waitUntilLoadedAndElementClickable(calTodaysDate);
		jsClick(calTodaysDate);

		waitUntilLoadedAndElementClickable(calbtnRegistrationExpDate);
		jsClick(calbtnRegistrationExpDate);

		waitUntilLoadedAndElementClickable(calTodaysDate);
		jsClick(calTodaysDate);

		type(DataManager.randomNumberGenerator(),txtSettlementAccountNumber);
		click(btnSubmit,TimeEntity.SEC_10.getSeconds());

	}



}
