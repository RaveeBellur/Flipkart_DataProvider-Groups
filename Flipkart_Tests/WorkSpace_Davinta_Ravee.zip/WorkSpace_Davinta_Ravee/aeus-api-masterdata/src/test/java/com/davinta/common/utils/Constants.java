package com.davinta.common.utils;

/**
 * @author rbellur
 * @throws   
 * @category
 * 
 */

public interface Constants {
	// DAO Mappings
	public String TRANSACTION="TRANSACTION";
	public String ENROLLMENT="ENROLLMENT";
	public String NEO4J="NEO4J";


	//Admin DB constants
	
	public String AGENT_TERMINAL = "AGENT_TERMINAL";
	public String AGENT_DEVICE = "AGENT_DEVICE";
	public String FETCH_TERMINAL = "FETCH_TERMINAL";
	public String FETCH_TXN_ADMIN_DETAILS = "FETCH_TXN_ADMIN_DETAILS";
	public String FETCH_COUNTRY_DETAILS = "FETCH_COUNTRY_DETAILS";
	public String FETCH_CURRENCY_DETAILS = "FETCH_CURRENCY_DETAILS";
	public String FETCH_LOCATION_DETAILS = "FETCH_LOCATION_DETAILS";
	public String DELETE_LOCATION = "DELETE_LOCATION";
	public String DELETE_COUNTRY = "DELETE_COUNTRY";
	public String DELETE_CURRENCY = "DELETE_CURRENCY";
	public String FETCH_ENTERPRISETEMPLATE_DETAILS = "FETCH_ENTERPRISETEMPLATE_DETAILS";
	public String DELETE_ENTERPRISETEMPLATE = "DELETE_ENTERPRISETEMPLATE";
	public String FETCH_ENTERPRISE_DETAILS = "FETCH_ENTERPRISE_DETAILS";
	public String DELETE_ENTERPRISE = "DELETE_ENTERPRISE";
	public String FETCH_TERMINAL_DETAILS = "FETCH_TERMINAL_DETAILS";
	public String DELETE_TERMINAL = "DELETE_TERMINAL";
	public String FETCH_AGENT_DETAILS = "FETCH_AGENT_DETAILS";
	public String DELETE_AGENT = "DELETE_AGENT";
	public String FETCH_ROLE_DETAILS = "FETCH_ROLE_DETAILS";
	public String DELETE_ROLE = "DELETE_ROLE";
	public String DELETE_PRIVILEGE = "DELETE_PRIVILEGE";
	public String FETCH_PRIVILEGE_DETAILS = "FETCH_PRIVILEGE_DETAILS";
	public String FETCH_DEVICE_DETAILS = "FETCH_DEVICE_DETAILS";		
	public String GET_OTP = "GET_OTP";
	public String SET_OTP = "SET_OTP";
	public String FETCH_USER_DETAILS = "FETCH_USER_DETAILS";
	public String DELETE_USER = "DELETE_USER";
	public String DELETE_USER_AADHAAR = "DELETE_USER_AADHAAR"; 
	public String FETCH_GENERICCODE_DETAILS = "FETCH_GENERICCODE_DETAILS";
	
	
	public String  DATE_FORMAT="yyyy-MM-dd";
	public String  FAILED_QUERY="Failed Query : ";

	/**
	 * Below are the DB datatype constant
	 * 
	 */
	public String CLOB_DATA_TYPE="mysql.sql.CLOB";
	public String DATE_DATA_TYPE="java.sql.Timestamp";
	public boolean DB_CHECK = true;

	
	
}
