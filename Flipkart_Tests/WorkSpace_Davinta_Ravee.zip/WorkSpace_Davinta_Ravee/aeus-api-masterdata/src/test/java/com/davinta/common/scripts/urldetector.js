function(port,path){
	var apiGatewayEnabled = karate.properties['api.gateway.enabled'];
	if (apiGatewayEnabled == 'true' && path!='prelogin') {
		karate.log('Invoking services through API Gateway layer...')
		if(path==null){
			//QA Server
			//return 'http://172.19.225.214/api-gateway/';
			//Dev Server
			return 'http://172.19.225.123/api-gateway/';
		}
		//return 'http://172.19.225.214/api-gateway/' + path;
		return 'http://172.19.225.123/api-gateway/' + path;
	  } else {
		  karate.log('Bypassing API Gateway layer...')
		  //QA Server
		  //return 'https://172.19.225.214:' + port;
		  //Dev Server
		  return 'https://172.19.225.123:' + port;
	  }
}
	
	

	
	
	