package com.davinta.admin.mastersetup;

public class DataStorage
{
	static String enterpriseId;
    static String terminalId;
    static String tenantId;
	static String userId;
	static String agentId;

}
