package com.davinta.admin.genericCodes;
import org.junit.runner.RunWith;

import com.davinta.base.TestBase;
import com.intuit.karate.junit4.Karate;
import cucumber.api.CucumberOptions;

@RunWith(Karate.class)
@CucumberOptions(monochrome = true)
public class GenericCodesRunner extends TestBase {

}
 