package com.davinta.admin.mastersetup;
import org.junit.runner.RunWith;

import com.davinta.base.TestBase;
import com.intuit.karate.junit4.Karate;
import cucumber.api.CucumberOptions;

@RunWith(Karate.class)
@CucumberOptions(monochrome = true,tags={"@user"})
public class EnterpriseRunner extends TestBase {

}
 