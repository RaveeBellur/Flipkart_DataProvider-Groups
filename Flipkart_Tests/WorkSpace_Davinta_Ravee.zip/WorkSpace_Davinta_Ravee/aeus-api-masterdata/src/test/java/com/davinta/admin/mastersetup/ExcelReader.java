package com.davinta.admin.mastersetup;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ExcelReader {

	public static Map<String, String> getInputsFromExcel(String apiName) throws Exception {

		File file = new File("..//aeus-masterdata-api-tests//config//DataSetUp.xlsx");
		FileInputStream fis = new FileInputStream(file);

		Workbook wb = WorkbookFactory.create(fis);
		wb.setForceFormulaRecalculation(true);
		Sheet sh = wb.getSheetAt(0);

		int keyColumn = 0, valueColumn = 0;

		for (int i = 0; i < sh.getRow(0).getLastCellNum(); i++) {
			if (sh.getRow(0).getCell(i).getStringCellValue().equalsIgnoreCase("FieldPath")) {
				keyColumn = i;
				break;
			}
		}
		for (int i = 0; i < sh.getRow(0).getLastCellNum(); i++) {
			if (sh.getRow(0).getCell(i).getStringCellValue().equalsIgnoreCase("Value")) {
				valueColumn = i;
				break;
			}
		}

		Map<String, String> map = new HashMap<String, String>();

		for (int i = 1; i <= sh.getLastRowNum(); i++) {
			if (sh.getRow(i).getCell(0).getStringCellValue().equalsIgnoreCase(apiName)) {
				String val;
				if (sh.getRow(i).getCell(valueColumn).getCellType() == Cell.CELL_TYPE_NUMERIC)
					val = Long.toString((long) sh.getRow(i).getCell(valueColumn).getNumericCellValue());
				else
					val = sh.getRow(i).getCell(valueColumn).getStringCellValue();
				map.put(sh.getRow(i).getCell(keyColumn).getStringCellValue(), val);
			}
		}
		return map;
	}

	public static void writeToExcel(String str, int rowNo, int colNo) throws Exception {
		// URL resource = ExcelReader.class.getResource("API_Inputs.xlsx");
		// File file = new File(resource.toURI());
		File file = new File("..//aeus-masterdata-api-tests//config//DataSetUp.xlsx");
		FileInputStream fis = new FileInputStream(file);
		Workbook wb = WorkbookFactory.create(fis);
		Sheet sh = wb.getSheet("Result");
		FileOutputStream fos = new FileOutputStream(file);
		Row row = sh.getRow(rowNo);
		Cell cell = row.getCell(colNo);
		cell.setCellValue(str);
		// sh=wb.getSheetAt(0);
		fis.close();
		// wb.setForceFormulaRecalculation(true);
		wb.getCreationHelper().createFormulaEvaluator().evaluateAll();
		wb.write(fos);
		wb.close();
		fos.close();
		System.out.println("Excel update completed");
	}

	public static String getFromResult(String fieldName) throws Exception {
		String val = null;
		File file = new File("..//aeus-masterdata-api-tests//config//DataSetUp.xlsx");
		FileInputStream fis = new FileInputStream(file);

		Workbook wb = WorkbookFactory.create(fis);
		wb.setForceFormulaRecalculation(true);
		Sheet sh = wb.getSheet("Result");
		for(int i=0;i<sh.getLastRowNum();i++){
			if(sh.getRow(i).getCell(0).getStringCellValue().equals(fieldName)){
				val=sh.getRow(i).getCell(1).getStringCellValue();
				break;
			}
		}
		return val;
	}

	public static void main(String[] args) throws Exception {

		System.out.println(getInputsFromExcel("country"));

		/*
		 * FileInputStream fis=new FileInputStream("E:\\API_Inputs.xlsx");
		 * Workbook wb =WorkbookFactory.create(fis); Sheet sh=wb.getSheetAt(0);
		 * 
		 * String controllerName = "Country"; int keyColumn=0,valueColumn=0;
		 * 
		 * for (int i=0;i<sh.getRow(0).getLastCellNum();i++){
		 * if(sh.getRow(0).getCell(i).getStringCellValue().equalsIgnoreCase(
		 * "FieldPath")){ keyColumn = i; break; } } for (int
		 * i=0;i<sh.getRow(0).getLastCellNum();i++){
		 * if(sh.getRow(0).getCell(i).getStringCellValue().equalsIgnoreCase(
		 * "Value")){ valueColumn = i; break; } }
		 * 
		 * Map<String,String> map=new HashMap<String,String>();
		 * 
		 * for(int i=1;i<=sh.getLastRowNum();i++){
		 * if(sh.getRow(i).getCell(0).getStringCellValue().equalsIgnoreCase(
		 * controllerName)){ String val;
		 * if(sh.getRow(i).getCell(valueColumn).getCellType() ==
		 * Cell.CELL_TYPE_NUMERIC) val =
		 * Long.toString((long)sh.getRow(i).getCell(valueColumn).
		 * getNumericCellValue()); else val =
		 * sh.getRow(i).getCell(valueColumn).getStringCellValue();
		 * map.put(sh.getRow(i).getCell(keyColumn).getStringCellValue(), val);
		 * 
		 * } } System.out.println(map);
		 */
	}
}
