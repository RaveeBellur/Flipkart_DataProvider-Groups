package com.davinta.admin.mastersetup;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.spi.json.JacksonJsonNodeJsonProvider;
import com.jayway.jsonpath.spi.mapper.JacksonMappingProvider;

import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;

public class JsonUpdator {

	public static Map<String, Object> updateJson(String apiName, String fileName) throws Exception {
		JSONParser parser = new JSONParser();
		JSONObject jsonObject = new JSONObject();

		FileReader reader = null;
		try {
			URL resource = JsonUpdator.class.getResource(fileName + ".json");
			File jsonFile = new File(resource.toURI());
			reader = new FileReader(jsonFile);
			jsonObject = (JSONObject) parser.parse(reader);

		} catch (Exception ex) {
			System.out.println(ex);
		}

		Map<String, Object> userData = null;
		try {
			userData = new ObjectMapper().readValue(jsonObject.toJSONString(), Map.class);
		} catch (IOException e) {
			System.out.println(e);
		}

		MutableJson json = new MutableJson(userData);

		System.out.println("Before:\t" + json.map());
		Map<String, String> excelMap = ExcelReader.getInputsFromExcel(apiName);
		System.out.println("excelMap : " + excelMap);

		for (Map.Entry<String, String> val : excelMap.entrySet()) {
			if (val.getValue().contains("Get From Response:")) {
				String api = val.getValue().substring(val.getValue().indexOf(':') + 1, val.getValue().length());
				switch (api.toLowerCase()) {
				case "enterprise":
					json.update("$." + val.getKey(), DataStorage.enterpriseId);
					break;
				case "terminalanddevice":
					json.update("$." + val.getKey(), DataStorage.terminalId);
					break;
				case "enterprisetenant":
					json.update("$." + val.getKey(), DataStorage.tenantId);
					break;
				case "agent":
					json.update("$." + val.getKey(), DataStorage.userId);
					break;
				}
			} else
				json.update("$." + val.getKey(), val.getValue());
		}
		System.out.println("After:\t" + json.map().toString());
		return json.map();
	}

	public static void getResponse(Map<String, Object> jsonResponseMap, String apiName) throws Exception {
		System.out.println("getresponse() invoked");
		Map<String, Object> message = ((Map) jsonResponseMap.get("message"));
		switch (apiName.toLowerCase()) {
		case "enterprisetenant":
			DataStorage.tenantId = message.get("tenantId").toString();
			ExcelReader.writeToExcel(DataStorage.tenantId, 0, 1);
			break;
		case "enterprise":
			DataStorage.enterpriseId = message.get("enterpriseCode").toString();
			ExcelReader.writeToExcel(DataStorage.enterpriseId, 1, 1);
			break;
		case "terminalanddevice":
			DataStorage.terminalId = message.get("terminalId").toString();
			ExcelReader.writeToExcel(DataStorage.terminalId, 2, 1);
			break;
		case "agent":
			DataStorage.agentId = message.get("userId").toString();
			ExcelReader.writeToExcel(DataStorage.agentId, 3, 1);
			break;
		case "user":
			DataStorage.userId = message.get("userId").toString();
			ExcelReader.writeToExcel(DataStorage.userId, 4, 1);
			break;
		}
	}
}