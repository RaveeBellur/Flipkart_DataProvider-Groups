package com.davinta.base;

import com.intuit.karate.junit4.Karate;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

@RunWith(Karate.class)
public abstract class TestBase {
    
    
    @BeforeClass
    public static void beforeClass() throws Exception {
    	javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier((hostname, sslSession) -> true);
    	System.setProperty("javax.net.ssl.keyStore", "./certificates/aeusapp-keystore.jks");
        System.setProperty("javax.net.ssl.keyStorePassword", "aeusapp@321");
        System.setProperty("javax.net.ssl.trustStore", "./certificates/aeusapp-truststore.jks");
        System.setProperty("javax.net.ssl.trustStorePassword", "aeusapp@321");
        System.setProperty("api.gateway.enabled", "false");
        System.setProperty("db.check", "false");
    }
    
    @AfterClass
    public static void afterClass() {

    }
    
}
