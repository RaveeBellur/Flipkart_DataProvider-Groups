function() { 
	  karate.configure('connectTimeout', 500000);
	  karate.configure('readTimeout', 500000);
	  
	  var scripts = 'classpath:com/davinta/common/scripts/';
	  var expectedJson = 'classpath:com/davinta/admin/expectedjson/';

	  karate.set('jsBaseUrl', scripts+'urldetector.js');
	  karate.set('jsAuthorization', scripts+'headers.js');
	  karate.set('jsJwtHeaderAdmin', scripts+'jwtheadersadmin.js');
	  karate.set('jsRandomNumGenerator', scripts+'randomnumgenarator.js');	
	  karate.set('jsStrGenerator', scripts+'stringgenarator.js');
	  karate.set('jsTimeKeeper', scripts+'timekeeper.js');
	  karate.set('jsIsoformatDate', scripts+'isoformatdate.js');
	  karate.set('jsonEmpty', scripts+'empty.json');
	  } 