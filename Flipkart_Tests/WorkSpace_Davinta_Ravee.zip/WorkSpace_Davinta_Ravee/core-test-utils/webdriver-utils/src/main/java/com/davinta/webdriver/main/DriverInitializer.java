package com.davinta.webdriver.main;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Cookie;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.webdriver.utils.EnvTaskManager;
import com.davinta.webdriver.utils.TimeManager;

/**
 * @author rbellur
 * @throws   
 * @category
 * 
 */

public class DriverInitializer {
	final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private static DriverInitializer driverInitializerInstance = null;

    private DriverInitializer() {}

	/** The WebDriver object */
	protected WebDriver driver;

	public WebDriver getDriver() {
		return driver;
	}

    public static DriverInitializer getDriverInitializerInstance(){
    	if(driverInitializerInstance==null){
    		driverInitializerInstance = new DriverInitializer();
        }
        return driverInitializerInstance;
    }
	
	public WebDriver getAppropriateDriver(String browsertype, String location) throws Exception {
		// WebDriver driver = null;
		if (browsertype.equalsIgnoreCase("firefox")) {
			EnvTaskManager.killProcess("geckodriver.exe");
			EnvTaskManager.killProcess("firefox.exe");
			TimeManager.waitInSeconds(5);
			System.setProperty("webdriver.gecko.driver", location + "/geckodriver.exe");
			
			DesiredCapabilities caps=new DesiredCapabilities();
			caps.setCapability("acceptInsecureCerts", true);
			driver = new FirefoxDriver(caps);
		} else if (browsertype.equalsIgnoreCase("Chrome")) {
			EnvTaskManager.killProcess("chromedriver.exe");
			EnvTaskManager.killProcess("chrome.exe");
			TimeManager.waitInSeconds(5);
			System.setProperty("webdriver.chrome.driver", location + "/chromedriver.exe");
			driver = new ChromeDriver();
		} else if (browsertype.equalsIgnoreCase("IE")) {
			EnvTaskManager.killProcess("iexplore.exe", "mshta.exe", "IEDriverServer.exe");
			TimeManager.waitInSeconds(5);
		}

		if (! browsertype.equalsIgnoreCase("firefox")) {
			driver.manage().window().maximize();
		}
		driver.manage().deleteAllCookies();

		logger.debug("is the browser session id null " + ((RemoteWebDriver) driver).getSessionId().toString());
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(120, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(60, TimeUnit.SECONDS);

		return driver;
	}

	public void triggerURL(String URL) {
		if (driver != null) {
			try {
				driver.get(URL);
				System.out.println("Trigger URL: URL is loaded successfully");
				logger.debug("Trigger URL: URL is loaded successfully");
			} catch (Exception e) {
				System.out.println("Trigger URL: URL load failed");
				logger.debug("Trigger URL: URL load failed");
				e.printStackTrace();
			}

		} else {

		}
	}

	public void closeAllBrowsers() {
		try {
			if (driver != null) {
				driver.quit();
				logger.debug("Close Browser : Closing the browser");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deleteCookie(Cookie cookie) {
		if (driver != null) {
			driver.manage().deleteCookie(cookie);
		} else {

		}
	}

	public void deleteAllCookies() {

		if (driver != null) {
			driver.manage().deleteAllCookies();
		} else {

		}
	}

}
