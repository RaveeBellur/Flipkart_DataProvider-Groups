package com.davinta.apigatewaylayer.utils;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.bouncycastle.jcajce.provider.asymmetric.rsa.DigestSignatureSpi.SHA512;
import org.bouncycastle.util.encoders.Base64;
import org.springframework.security.authentication.encoding.ShaPasswordEncoder;

public class RsaActionAssist {
	private static ShaPasswordEncoder encoder = new ShaPasswordEncoder(512); 


	/**
	 * Encrypt message byte type.
	 * 
	 * @param message
	 *            message
	 * @param keys
	 *            keys
	 * @return byte
	 */

	public byte[] encrypt(byte[] message, List<String> keys) {
		BigInteger n = new BigInteger(keys.get(0));
		BigInteger e = new BigInteger(keys.get(1));
		return (new BigInteger(message)).modPow(e, n).toByteArray();
	}

	public BigInteger decrypt(BigInteger message, List<String> keys) {
		BigInteger n;
		BigInteger d;
		n = new BigInteger(keys.get(0));
		d = new BigInteger(keys.get(2));

		return message.modPow(d, n);
	}

	/** Encrypt the given plaintext message. */
	public BigInteger encrypt(BigInteger message, List<String> pubKeys) {
		BigInteger n, e;
		n = new BigInteger(pubKeys.get(0));
		e = new BigInteger(pubKeys.get(1));
		return message.modPow(e, n);
	}

	/**
	 * Decrypt message byte type.
	 * 
	 * @param message
	 *            message
	 * @param keys
	 *            keys
	 * @return byte
	 */
	public byte[] decrypt(byte[] message, List<String> keys) {
		BigInteger n = new BigInteger(keys.get(0));
		BigInteger d = new BigInteger(keys.get(2));
		return (new BigInteger(message)).modPow(d, n).toByteArray();
	}

	public static String desKeyGeneration(String n, String e, String secretKey) throws Exception {
		RsaActionAssist object = new RsaActionAssist();
		List<String> keys = new ArrayList<String>();
		keys.add(n);
		keys.add(e);
		BigInteger key = new BigInteger(secretKey);
		BigInteger arr = object.encrypt(key, keys);
		String enc = new String(Base64.encode(arr.toString().getBytes()));
		return enc;
	}
	
	public static String hashPasswordGeneration(String pwd) {
		return encoder.encodePassword(pwd, null);
				
	}

	public static void main(String[] args) throws Exception {
		RsaActionAssist object = new RsaActionAssist();

		List<String> keys = new ArrayList<String>();
		keys.add(
				"145676738710181588344090038201049062993082448800504656346148259998539574617953048775198172412305642974352018958012983199966482510378755967326402572658217208628393779439164313279669847566429650347840851338958561568696803883890940682745867431643636448979804649235786412139874477424710699222579443651599273525701");
		keys.add("65537");
		keys.add(
				"3867117167133903060263549317485902911149035467515671412048383891134641478570069313409549352760375341947175680356704061466302039025895807867127437736840183628064728299586460475344565234664156701985448434175812253804173772292411611091779316612988063425729246143742571831151700983990126687434003375750327142625");
		// ensure key length must be 16.
		BigInteger key = new BigInteger("1234123412341234");
		BigInteger arr = object.encrypt(key, keys);
		System.out.println(arr);
		String enc = new String(Base64.encode(arr.toString().getBytes()));
		System.out.println(enc);
		System.out.println(new String(Base64.decode(enc)));
		String value = new String(Base64.decode(enc));
		BigInteger dec = object.decrypt(new BigInteger(value), keys);
		System.out.println(dec);

	}
}