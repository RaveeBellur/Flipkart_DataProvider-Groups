package com.davinta.apigatewaylayer.utils;

/**
 * Copyright (C) Davinta Technologies 2017. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Davinta Technologies. You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and conditions
 * entered into with Davinta Technologies.
 */

import java.io.DataInputStream;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.Objects;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.bouncycastle.util.encoders.Base64;

/**
 * HmacUtility class.
 * @author Lalchand Mali
 *
 */
public final class HmacUtility {

	
	private static String algorithm = "HmacSHA512";

	/**
	 * default constructor.
	 */
	private HmacUtility() {

	}

	/**
	 * This method is used for generating hmac.
	 * @param apiSecret apiSecret
	 * @param payload payload
	 * @return byte
	 */
	public static byte[] generateHmac(byte[] apiSecret, byte[] payload) {
		Objects.requireNonNull(algorithm, "algorithm");
		Objects.requireNonNull(apiSecret, "apiSecret");
		Objects.requireNonNull(payload, "payload");

		Mac digest;
		byte[] encryptedByteArray = null;
		try {
			digest = Mac.getInstance(algorithm);
			SecretKeySpec secretKey = new SecretKeySpec(apiSecret, algorithm);
			digest.init(secretKey);
			digest.update(payload);
			//System.out.println(new String(apiSecret));
			//System.out.println(new String(payload));
			final byte[] signatureBytes = digest.doFinal();
			encryptedByteArray = Base64.encode(signatureBytes);
			digest.reset();
			return encryptedByteArray;
		}
		catch (Exception e) {
			return new byte[0];
		}

	}

	public static String authKeyGenerator(String payload, String apiSecret) {
		return new String(HmacUtility.generateHmac(apiSecret.getBytes(), payload.getBytes()));
	}

	
	public static void main(String[] args) throws IOException {
		DataInputStream in = new DataInputStream(System.in);
		String payload = "";
		System.out.println("Please Enter text");
		payload=in.readLine();
		String apiSecret = "1234123412341234";
		System.out.println(new String(HmacUtility.generateHmac(apiSecret.getBytes(), payload.getBytes())));
	}
}
