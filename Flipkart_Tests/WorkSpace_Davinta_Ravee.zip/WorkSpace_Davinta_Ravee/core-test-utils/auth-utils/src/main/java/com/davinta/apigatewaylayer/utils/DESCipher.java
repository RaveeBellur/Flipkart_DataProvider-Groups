package com.davinta.apigatewaylayer.utils;

/**
 * Copyright © Synova 2012. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Synova. You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and conditions
 * entered into with Synova.
 *
 * Id: DESCipher.java,v 1.1 
 *
 * Date Author Changes
 * May 25, 2012,10:30 AM Nachiketa Rout
 */
/*
 * 
 */

import org.bouncycastle.crypto.BufferedBlockCipher;
import org.bouncycastle.crypto.KeyGenerationParameters;
import org.bouncycastle.crypto.engines.DESedeEngine;
import org.bouncycastle.crypto.generators.DESedeKeyGenerator;
import org.bouncycastle.crypto.modes.CBCBlockCipher;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.encoders.Base64;

import java.security.SecureRandom;
import java.util.Scanner;

/**
 * The Class DESCipher.
 */
public class DESCipher {

	/** The cipher. */
	private BufferedBlockCipher cipher;

	/** The key. */
	private KeyParameter key;

	/** The key length. */
	private int keyLength;

	/**
	 * This method helps to instantiates a new dES cipher.
	 *
	 * @param keyLength
	 *            the key length
	 */
	public DESCipher(int keyLength) {

		this.keyLength = keyLength;
		cipher = new BufferedBlockCipher(new CBCBlockCipher(new DESedeEngine()));
	}

	/**
	 * This method helps to sets the key.
	 *
	 * @param keyData
	 *            the new key
	 */
	public void setKey(byte[] keyData) {

		key = new KeyParameter(keyData);
	}

	/**
	 * This method helps to encrypt.
	 *
	 * @param data
	 *            the data
	 * @return the byte[]
	 * @throws Exception
	 *             the exception
	 */
	public byte[] encrypt(byte[] data,String secKey) throws Exception {
		setKey(secKey.getBytes());
		cipher.init(true, key);
		byte[] output = new byte[cipher.getOutputSize(data.length)];
		int outLen = cipher.processBytes(data, 0, data.length, output, 0);
		cipher.doFinal(output, outLen);

		return output;
	}

	/**
	 * This method helps to decrypt.
	 *
	 * @param encryptedData
	 *            the encrypted data
	 * @return the byte[]
	 * @throws Exception
	 *             the exception
	 */
	public byte[] decrypt(byte[] encryptedData) throws Exception {

		cipher.init(false, key);
		byte[] output = new byte[cipher.getOutputSize(encryptedData.length)];
		int outLen = cipher.processBytes(encryptedData, 0, encryptedData.length, output, 0);
		cipher.doFinal(output, outLen);

		return output;
	}

	/**
	 * This method helps to generate key.
	 *
	 * @return the byte[]
	 * @throws Exception
	 *             the exception
	 */
	public byte[] generateKey() throws Exception {

		SecureRandom sr = new SecureRandom();
		sr.setSeed(System.currentTimeMillis());
		DESedeKeyGenerator kg = new DESedeKeyGenerator();
		kg.init(new KeyGenerationParameters(sr, keyLength * 8));

		return kg.generateKey();
	}

	/**
	 * The main method.
	 *
	 * @param args
	 *            the arguments
	 * @throws Exception
	 *             the exception
	 *//*
	public static void main(String[] args) throws Exception {

		byte[] tranEncKey;
		Scanner input = new Scanner(System.in);
		DESCipher object = new DESCipher(16);
		String key = HexString.bufferToHex(object.generateKey());
		System.out.println(key);
		System.out.println("Please Enter the data");
		String str = input.nextLine();

		String encrypted = new String(Base64.encode(object.encrypt(str.getBytes())));
		System.out.println(encrypted);
		String data = new String(object.decrypt(Base64.decode(encrypted)));
		System.out.println(data);
	}*/
}
