package com.davinta.databaseaccesslayer.common;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author rbellur
 * @throws   
 * @category
 * 
 */

@SuppressWarnings("unchecked")
public class Base {

    private static final Logger logger = LoggerFactory.getLogger(Base.class);

	// One time Load values should not reset.
	public static Map<String, String> DB_QueriesMap =null;
	
	static{
	    // Loading Global Properties File 
		Properties properties = new Properties();
		try {
			
			properties.load(new FileInputStream("./config/DB_Queries.properties"));
			Base.DB_QueriesMap = new HashMap<String, String>((Map)properties);
		}  catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		logger.info("Configuration files Loading Completed.");
     }
	
}
