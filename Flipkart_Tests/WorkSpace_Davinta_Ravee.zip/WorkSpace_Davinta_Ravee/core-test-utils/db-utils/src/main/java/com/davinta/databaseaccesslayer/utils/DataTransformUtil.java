package com.davinta.databaseaccesslayer.utils;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.databaseaccesslayer.exception.JsonDatabaseCompareException;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.jayway.jsonpath.JsonPath;

/**
 * @author rbellur
 * 
 */

public class DataTransformUtil {
    private static final Logger logger = LoggerFactory.getLogger(DataTransformUtil.class);

	public static boolean compareApiResponseToDbRecords(Map<String, Object> jsonResponseMap, List<Map<String, Object>> dbResult, JsonReader mappingRules, String arrayName) throws JsonDatabaseCompareException{
		String jsonBody;
		
		if (dbResult == null || dbResult.size() < 0) {
			logger.error("compareApiResponseToDbRecords() : No records found in DB");
			return false;
		}

		jsonBody = JsonUtil.toJson(jsonResponseMap);
		logger.debug("Json to be verified: {}", jsonBody );

		List<JsonToDbMapping> jsonToDbMapping = getJsonToDbMapping(mappingRules, arrayName);
		
		for (int i=0;i<jsonToDbMapping.size();i++) {
			int j=0; //get the first row

			String jsonFieldMapping = jsonToDbMapping.get(i).getJsonPath().trim();
			String dbFieldMapping = jsonToDbMapping.get(i).getDatabaseField().trim();
			String dataType = jsonToDbMapping.get(i).getDataType().trim();
			String format = jsonToDbMapping.get(i).getFormat().trim();

			String jsonVal = JsonPath.read(jsonBody, jsonFieldMapping).toString();
			if(jsonVal != null)
				jsonVal = jsonVal.trim();
			logger.debug("jsonPath: {} , jsonVal: {}", jsonFieldMapping,jsonVal);

			String dbVal =   dbResult.get(j).get(dbFieldMapping).toString();
			if(dbVal != null)
				dbVal = dbVal.trim();
			logger.debug("dbcol: {} , dbVal: {}", dbFieldMapping,dbVal);
			
			if (StringUtils.containsIgnoreCase(dataType, "String")) {
				if (!checkStringEqual(jsonVal, dbVal)) {
					logger.debug("compareApiResponseToDbRecords() -  jsonFieldMapping: {}	jsonValue: {}",	jsonFieldMapping, jsonVal);
					logger.debug("compareApiResponseToDbRecords() -  dbFieldMapping: {}	databaseValue: {}",	dbFieldMapping, dbVal);
					throw new JsonDatabaseCompareException("API response values didn't match Database Value : " + dbVal + " JSON Value : " + jsonVal);
				}
			
			} else if (StringUtils.containsIgnoreCase(dataType, "Date")) {
				
			} else if (StringUtils.equalsIgnoreCase(dataType, "Decimal")) {
				
			} else if (StringUtils.equalsIgnoreCase(dataType, "Integer")) {
				
			}
		}
		return true;
	}

	public static boolean compareApiResponseToNeoDbRecords(Map<String, Object> jsonResponseMap, List<Map<String,Map<String, Object>>> dbResult, JsonReader mappingRules, String arrayName) throws JsonDatabaseCompareException{
		String jsonBody;
		
		if (dbResult == null || dbResult.size() < 0) {
			logger.error("compareApiResponseToDbRecords() : No records found in DB");
			return false;
		}
		
		jsonBody = JsonUtil.toJson(jsonResponseMap);
		logger.debug("Json to be verified: {}", jsonBody );
		
		List<JsonToDbMapping> jsonToDbMapping = getJsonToDbMapping(mappingRules, arrayName);
		
		for (int i=0;i<jsonToDbMapping.size();i++) {
			int j=0; //get the first row

			String jsonFieldMapping = jsonToDbMapping.get(i).getJsonPath().trim();
			String dbFieldMapping = StringUtils.substringAfter(jsonToDbMapping.get(i).getDatabaseField().trim(),".");
			String node = StringUtils.substringBefore(jsonToDbMapping.get(i).getDatabaseField().trim(),".");
			String dataType = jsonToDbMapping.get(i).getDataType().trim();
			String format = jsonToDbMapping.get(i).getFormat().trim();

			String jsonVal = JsonPath.read(jsonBody, jsonFieldMapping).toString();
			if(jsonVal != null)
				jsonVal = jsonVal.trim();
			logger.debug("jsonPath: {} , jsonVal: {}", jsonFieldMapping,jsonVal);

			Object res1 = dbResult.get(j).get(node).get(dbFieldMapping);

			
			String dbVal = dbResult.get(j).get(node).get(dbFieldMapping).toString();
			if(dbVal != null)
				dbVal = dbVal.trim();
			logger.debug("dbcol: {} , dbVal: {}", dbFieldMapping,dbVal);
			
			if (StringUtils.equalsIgnoreCase(dataType, "String")) {
				if (!checkStringEqual(jsonVal, dbVal)) {
					logger.debug("compareApiResponseToDbRecords() -  jsonFieldMapping: {}	jsonValue: {}",	jsonFieldMapping, jsonVal);
					logger.debug("compareApiResponseToDbRecords() -  dbFieldMapping: {}	databaseValue: {}",	dbFieldMapping, dbVal);
					throw new JsonDatabaseCompareException("API response values didn't match Database Value : " + dbVal + " JSON Value : " + jsonVal);
				}
			}else if (StringUtils.equalsIgnoreCase(dataType, "String[]")) {
				jsonVal = jsonVal.replaceAll("\"", "");
				if (!checkStringEqual(jsonVal, dbVal)) {
					logger.debug("compareApiResponseToDbRecords() -  jsonFieldMapping: {}	jsonValue: {}",	jsonFieldMapping, jsonVal);
					logger.debug("compareApiResponseToDbRecords() -  dbFieldMapping: {}	databaseValue: {}",	dbFieldMapping, dbVal);
					throw new JsonDatabaseCompareException("API response values didn't match Database Value : " + dbVal + " JSON Value : " + jsonVal);
				}
			} else if (StringUtils.containsIgnoreCase(dataType, "Date")) {
				
			} else if (StringUtils.equalsIgnoreCase(dataType, "Decimal")) {
				
			} else if (StringUtils.equalsIgnoreCase(dataType, "Integer")) {
				//float tmp = Float.parseFloat(dbVal);
				double tmp = Double.parseDouble(dbVal);
				//if (Integer.parseInt(jsonVal)!=Integer.parseInt(String.valueOf(tmp))) {
				if (Integer.parseInt(jsonVal)!=(int)tmp) {
					logger.debug("compareApiResponseToDbRecords() -  jsonFieldMapping: {}	jsonValue: {}",	jsonFieldMapping, jsonVal);
					logger.debug("compareApiResponseToDbRecords() -  dbFieldMapping: {}	databaseValue: {}",	dbFieldMapping, dbVal);
					throw new JsonDatabaseCompareException("API response values didn't match Database Value : " + dbVal + " JSON Value : " + jsonVal);
				}
				
			}else if (StringUtils.equalsIgnoreCase(dataType, "Boolean")) {
				if (jsonVal!=dbVal) {
					logger.debug("compareApiResponseToDbRecords() -  jsonFieldMapping: {}	jsonValue: {}",	jsonFieldMapping, jsonVal);
					logger.debug("compareApiResponseToDbRecords() -  dbFieldMapping: {}	databaseValue: {}",	dbFieldMapping, dbVal);
					throw new JsonDatabaseCompareException("API response values didn't match Database Value : " + dbVal + " JSON Value : " + jsonVal);
				}
				
			}
				
			//comparisionResult = comparator(jsonVal,dbVal,dataType,format);
			//comparisionResultMap.put(jsonVal, comparisionResult);
		}
		
/*		Set<Entry<String, Boolean>> se = comparisionResultMap.entrySet();
		logger.debug("comparision result map :: {}", comparisionResultMap);
		Iterator<Entry<String, Boolean>> it = se.iterator();
		while (it.hasNext()) {
			Entry<String, Boolean> me = it.next();
			if(me.getValue().equals(false)){
				logger.debug("API response and DB value not matching for field: {}",me.getKey()); 
				return false;
			}
		}*/
		//jsonToDbRecordMatching = true;
		return true;
	}

	static boolean checkStringEqual(String str1, String str2) {
		boolean isEqual = false;
		if ((StringUtils.isEmpty(str1) && (StringUtils.isEmpty(str2)))) {
			isEqual = true;
		} else if (StringUtils.equalsIgnoreCase(str1, str2)) {
			System.out.println(str1   + " :  " + str2) ;
			isEqual = true;
		}
		return isEqual;
	}
	
	private static List<JsonToDbMapping> getJsonToDbMapping(JsonReader mappingRules, String arrayName){
		JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject)jsonParser.parse(mappingRules);
        JsonArray jsonArr = jo.getAsJsonObject().getAsJsonArray(arrayName);
		Type listType = new TypeToken<List<JsonToDbMapping>>() {}.getType();
		List<JsonToDbMapping> jsonToDbMapping = new Gson().fromJson(jsonArr, listType);
		
		return jsonToDbMapping;
	}
	
	
}
