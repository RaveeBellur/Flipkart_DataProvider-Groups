package com.davinta.databaseaccesslayer.executor;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * @author rbellur
 */

public interface CypherExecutor {
	Iterator<Map<String, Object>> executeQuery(String dbName, String statement, Map<String,Object> params);
    void closeQuitely();
    Boolean runQuery(String dbName,String query, Map<String, Object> params);
}
