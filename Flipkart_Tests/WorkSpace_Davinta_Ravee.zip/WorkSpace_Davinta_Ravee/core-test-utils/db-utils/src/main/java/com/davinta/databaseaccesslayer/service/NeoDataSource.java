package com.davinta.databaseaccesslayer.service;

//import static org.neo4j.helpers.collection.MapUtil.map;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.databaseaccesslayer.common.Base;
import com.davinta.databaseaccesslayer.dao.DB;
import com.davinta.databaseaccesslayer.executor.BoltCypherExecutor;
import com.davinta.databaseaccesslayer.executor.CypherExecutor;

/**
 * @author rbellur
 * @throws   
 * @category
 * 
 */

public class NeoDataSource {
    private static final Logger logger = LoggerFactory.getLogger(NeoDataSource.class);
    
	public static List<Map<String,Map<String, Object>>> getData(String queryConstant, Map<String, Object> param,String dbName) {
    	List<Map<String,Map<String, Object>>> dbResult = null;
    	if (param==null) return Collections.emptyList(); 
    	String query = Base.DB_QueriesMap.get(queryConstant);
    	dbResult  = DB.getNeoDBValueInMap(query,param,dbName);
        return dbResult;
    }
	
	public static Boolean executeQuery(String queryConstant, Map<String, Object> param,String dbName) {
    	String query = Base.DB_QueriesMap.get(queryConstant);
    	return DB.executecypherQuery(query,param,dbName);
    }
	
	
	
    
    static void printMapofMap(List<Map<String,Map<String, Object>>> neoDbResult){
    	for (Map<String, Map<String, Object>> map : neoDbResult) {
			Iterator<Map.Entry<String, Map<String, Object>>> parent = map.entrySet().iterator();
			
			while (parent.hasNext()) {
			    Map.Entry<String, Map<String, Object>> parentPair = parent.next();
			    System.out.println("parentPair.getKey() :   " + parentPair.getKey() + " parentPair.getValue()  :  " + parentPair.getValue());
	
			    Iterator<Map.Entry<String, Object>> child = (parentPair.getValue()).entrySet().iterator();
			    while (child.hasNext()) {
			        Map.Entry childPair = child.next();
			        System.out.println("childPair.getKey() :   " + childPair.getKey() + " childPair.getValue()  :  " + childPair.getValue());
	
			        child.remove(); // avoids a ConcurrentModificationException
			    }
	
			}
			
	    }		
    }
}
