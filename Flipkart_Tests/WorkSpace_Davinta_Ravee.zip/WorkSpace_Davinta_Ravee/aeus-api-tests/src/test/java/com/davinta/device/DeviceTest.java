package com.davinta.device;

import cucumber.api.CucumberOptions;


@CucumberOptions(monochrome = true,
	tags = {"~@ignore","~@apigateway"},
	plugin = {"pretty", "html:target/cucumber","json:target/cucumber/test-report.json","junit:target/surefire-reports/cucumber-junit.xml"})
public class DeviceTest extends TestBase {
    // this class will automatically pick up all *.feature files
    // in src/test/java/demo and even recurse sub-directories
}


