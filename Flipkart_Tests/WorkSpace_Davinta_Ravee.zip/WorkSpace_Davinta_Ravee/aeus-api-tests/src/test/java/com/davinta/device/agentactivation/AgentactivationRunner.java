package com.davinta.device.agentactivation;

import org.junit.runner.RunWith;

import com.davinta.device.TestBase;
import com.intuit.karate.junit4.Karate;

import cucumber.api.CucumberOptions;

@RunWith(Karate.class)
@CucumberOptions(monochrome = true)
public class AgentactivationRunner extends TestBase {
}
