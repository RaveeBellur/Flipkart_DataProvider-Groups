package com.davinta.device.apigateway;

import org.junit.runner.RunWith;

import com.davinta.device.TestBase;
import com.intuit.karate.junit4.Karate;
import cucumber.api.CucumberOptions;

@RunWith(Karate.class)
@CucumberOptions(monochrome = true)
public class ApiGatewayAuthRunner extends TestBase {

}
