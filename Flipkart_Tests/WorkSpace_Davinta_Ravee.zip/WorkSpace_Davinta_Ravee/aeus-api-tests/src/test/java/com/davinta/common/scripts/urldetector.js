function(port,path){
	var apiGatewayEnabled = karate.properties['api.gateway.enabled'];
	
	if(karate.properties['env'] == 'dev'){
		if (apiGatewayEnabled == 'true' && path!='prelogin') {
			karate.log('Invoking services through API Gateway layer...')
			if(path==null){
				return 'http://172.19.225.123/api-gateway/';
			}
			return 'http://172.19.225.123/api-gateway/' + path;
		  } else {
			  karate.log('Bypassing API Gateway layer...')
			  return 'https://172.19.225.123:' + port;
		  }
	} else if(karate.properties['env'] == 'test'){
		if (apiGatewayEnabled == 'true' && path!='prelogin') {
			karate.log('Invoking services through API Gateway layer...')
			if(path==null){
				return 'http://172.19.225.214/api-gateway/';
			}
			return 'http://172.19.225.214/api-gateway/' + path;
		  } else {
			  karate.log('Bypassing API Gateway layer...')
			  return 'https://172.19.225.214:' + port;
		  }
	}
}