package com.davinta.device.transaction;

import java.util.ArrayList;

//import static org.neo4j.helpers.collection.MapUtil.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.davinta.databaseaccesslayer.service.DataSource;
import com.davinta.databaseaccesslayer.service.NeoDataSource;
//import com.davinta.databaseaccesslayer.utils.Constants;
import com.davinta.common.utils.Constants;
import com.davinta.databaseaccesslayer.utils.DataTransformUtil;
import com.davinta.databaseaccesslayer.utils.JsonUtil;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.google.gson.stream.JsonReader;

//import static org.neo4j.helpers.collection.MapUtil.map;

public class TransactionChecker {
	private static final Logger logger = LoggerFactory.getLogger(TransactionChecker.class);

	public static Boolean getTxnDetails(Map<String, Object> jsonResponseMap) throws Throwable {
		if(Constants.DB_CHECK){
			List<Map<String, Object>> dbResult = null;
			List<Map<String,Map<String, Object>>> neoDbResult = null; 
			boolean dbCompare,neoDbCompare;
			String arrayName;
	
			//1. Read mapping rules
			JsonReader mappingRules = JsonUtil.jsonReader("src/test/java/com/davinta/device/transaction/transactionfieldmapper.json");
	
			//2. Get MySQL DB records 
			arrayName = "transactionVerification";
			String transactionId = jsonResponseMap.get("transactionId").toString();
			logger.debug("txn Id: {}",jsonResponseMap.get("transactionId").toString());
			
			dbResult = DataSource.getData(Constants.FETCH_TRANSACTION_DETAILS,new Object[] {transactionId},Constants.TRANSACTION);
			logger.debug("DB result: {}",dbResult);
	
			//3. Compare API response with DB 
			dbCompare =  DataTransformUtil.compareApiResponseToDbRecords(jsonResponseMap, dbResult, mappingRules,arrayName);
			
			if(!dbCompare)
				logger.error("API response values didn't match MySQL Database Value");
	
			//1. Read mapping rules
			mappingRules = JsonUtil.jsonReader("src/test/java/com/davinta/device/transaction/transactionfieldmapper.json");
	
			//2. Get Neo DB records 
			arrayName = "neoTransactionVerification";
	        String bankTerminalCode = jsonResponseMap.get("bankTerminalId").toString();
	        
	        Map<String, Object> param  = new HashMap<String, Object>();
	        param.put("bankTerminalCode",bankTerminalCode);
	        
	        //neoDbResult = NeoDataSource.getData(Constants.FETCH_TERMINAL,param,Constants.NEO4J);
	        neoDbResult = NeoDataSource.getData(Constants.FETCH_TXN_ADMIN_DETAILS,param,Constants.NEO4J);
			logger.debug("Neo DB result: {}",neoDbResult);
			
			//3. Compare API response with DB 
			neoDbCompare =  DataTransformUtil.compareApiResponseToNeoDbRecords(jsonResponseMap, neoDbResult, mappingRules,arrayName);
	
			if(!neoDbCompare)
				logger.error("API response values didn't match Neo4j Database Value");
			
			if(dbCompare && neoDbCompare) 
				return true;
			else 
				return false;
		}
		else
			return true;
	}
}
