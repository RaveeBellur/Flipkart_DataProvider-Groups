package com.davinta.device.e2e;

import com.davinta.device.TestBase;
import com.intuit.karate.junit4.Karate;

import cucumber.api.CucumberOptions;

import org.junit.runner.RunWith;

@RunWith(Karate.class)
@CucumberOptions(monochrome = true)
public class E2ERunner extends TestBase{

}

