package com.davinta.device;

import com.intuit.karate.junit4.Karate;

import ch.qos.logback.core.net.SyslogOutputStream;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

@RunWith(Karate.class)
public abstract class TestBase {
    
    
    @BeforeClass
    public static void beforeClass() throws Exception {
    	javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier((hostname, sslSession) -> true);
    	System.setProperty("javax.net.ssl.keyStore", "./certificates/aeusapp-keystore.jks");
        System.setProperty("javax.net.ssl.keyStorePassword", "aeusapp@321");
        System.setProperty("javax.net.ssl.trustStore", "./certificates/aeusapp-truststore.jks");
        System.setProperty("javax.net.ssl.trustStorePassword", "aeusapp@321");
        System.setProperty("api.gateway.enabled", "false");

        if(System.getProperty("jenkins") == null) {
            System.setProperty("env", "dev");
        	System.setProperty("varAgentID","AG000002");
        	System.setProperty("varTerminalID","TE000001");
        	System.setProperty("varTenantID","EN000001");
        	System.setProperty("varCardNumber","B4377486575701410");
        	System.setProperty("varMobileNumber2","5321511111");
        	System.setProperty("varMobileNumber","5321522222");   
        }
    }
    
    @AfterClass
    public static void afterClass() {

    }
    
}
