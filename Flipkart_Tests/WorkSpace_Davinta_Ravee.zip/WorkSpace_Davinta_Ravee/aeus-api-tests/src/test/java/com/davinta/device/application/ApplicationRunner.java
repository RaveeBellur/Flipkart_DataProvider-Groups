package com.davinta.device.application;

import com.davinta.device.TestBase;
import com.intuit.karate.junit4.Karate;

import cucumber.api.CucumberOptions;

import org.junit.runner.RunWith;

@RunWith(Karate.class)
@CucumberOptions(monochrome = true)
public class ApplicationRunner extends TestBase{

}

