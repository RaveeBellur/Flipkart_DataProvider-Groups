package mebank.cukes.steps;

import mebank.dataobjects.Project;
import mebank.pageobjects.PageObject;
import mebank.pageobjects.admin.ProjectListPage;
import mebank.resources.SharedDriver;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ProjectMaintenanceSteps extends BaseSteps {

	Project project = new Project();
	Project updatedProject = new Project();

	private final WebDriver driver;

	public ProjectMaintenanceSteps(SharedDriver webDriver) {
		this.driver = webDriver;
	}

	private void openProjectListPage() {
		projectMaintenancePage = getProjectMaintenancePage(driver);
		projectMaintenancePage.viewProjectList();
		projectListPage = (ProjectListPage) new ProjectListPage(driver).get();
	}

	private void openProjectAddPage() {
		openProjectListPage();
		projectListPage.appendNewProject();
		projectAddPage = getProjectAddPage(driver);
	}

	@When("^I am on the project add page$")
	public void i_am_on_the_project_add_page() throws Throwable {
		// assumption. I have logged in ( as admin or the approver )
		openProjectAddPage();
	}

	@And("^I click save on the project add page$")
	public void i_click_save_on_the_project_add_page() throws Throwable {
		projectAddPage.save();
	}

	@When("^I have a new project$")
	public void i_have_a_new_project() throws Throwable {
		project.setProjectCode(RandomStringUtils.randomAlphanumeric(4));
		project.setProjectName(RandomStringUtils.randomAlphanumeric(50));
		// 250 characters causes horizontal scroll bar so use 25
		// TODO devs should implement wrapping / trunction
		project.setProjectManagerName(RandomStringUtils.randomAlphanumeric(25)); 
		project.setProjectManagerMeID(RandomStringUtils.randomAlphanumeric(8));
		project.setProjectManagerEmail("foo@foo.com");
		project.setCostCenter(RandomStringUtils.randomNumeric(6));
		project.setProgramme("Transformation"); //TODO create enum for these and pick one at random
	}

	@When("^I fill in the project details$")
	public void i_fill_in_the_project_details() throws Throwable {
		projectAddPage.set(project);
	}

	@When("^I add the project$")
	public void i_add_the_project() throws Throwable {
		openProjectAddPage();
		projectAddPage.setAndSubmit(project);
		// TODO some sort of assertion that it saved
		projectAddPage.goBackToProjectListPage();
	}

	@Then("^the project is displayed in the project list$")
	public void the_project_is_displayed_in_the_project_list() throws Throwable {
		projectListPage.searchByProjectCode(project.getProjectCode());
		// assert on project code as the project name can be updated ( see
		// update scenario )
		Assert.assertTrue(PageObject.isAvailable(
				driver,
				By.xpath("//td[contains(text(), '" + project.getProjectCode()
						+ "')]")));
	}

	@Then("^the project information is displayed$")
	public void the_project_information_is_displayed() throws Throwable {
		projectReviewPage = getProjectReviewPage(driver);
	}

	@When("^I enter \"(.*?)\" in the project code field$")
	public void i_enter_in_the_project_code_field(String arg1) throws Throwable {
		project.setProjectCode(parseArg(arg1));
		projectAddPage.setProjectCode(project.getProjectCode());
	}

	@When("^I select \"(.*?)\" in the programme field$")
	public void i_select_in_the_programme_field(String arg1) throws Throwable {
		project.setProgramme(arg1);
		projectAddPage.setProgramme(project.getProgramme());	    
	}
	
	@When("^I enter \"(.*?)\" in the project manager email field$")
	public void i_enter_in_the_project_manager_email_field(String arg1)
			throws Throwable {
		project.setProjectManagerEmail(arg1);
		projectAddPage.setProjectManagerEmail(project.getProjectManagerEmail());
	}

	@When("^I enter \"(.*?)\" in the project name field$")
	public void i_enter_in_the_project_name_field(String arg1) throws Throwable {
		project.setProjectName(parseArg(arg1));
		projectAddPage.setProjectName(project.getProjectName());
	}

	@When("^I enter \"(.*?)\" in the project manager field$")
	public void i_enter_in_the_project_manager_field(String arg1)
			throws Throwable {
		project.setProjectManagerName(parseArg(arg1));
		projectAddPage.setProjectManagerName(project.getProjectManagerName());
	}

	@When("^I enter (\\d+) random alphanumeric characters in the project manager field$")
	public void i_enter_random_alphanumeric_characters_in_the_project_manager_field(
			int arg1) throws Throwable {
		//TODO why no code here?
	}

	@When("^I enter \"(.*?)\" in the project manager MeID field$")
	public void i_enter_in_the_project_manager_MeID_field(String arg1)
			throws Throwable {
		project.setProjectManagerMeID(parseArg(arg1));
		projectAddPage.setProjectManagerMeID(project.getProjectManagerID());
	}

	@When("^I enter \"(.*?)\" in the cost centre field$")
	public void i_enter_in_the_cost_centre_field(String arg1) throws Throwable {
		project.setCostCenter(parseArg(arg1));
		projectAddPage.setCostCenter(project.getCostCenter());
	}

	@When("^I enter (\\d+) random numeric characters in the cost centre field$")
	public void i_enter_random_numeric_characters_in_the_cost_centre_field(
			int arg1) throws Throwable {

	}

	@Then("^the project code field has (\\d+) characters$")
	public void the_project_code_field_has_characters(int arg1)
			throws Throwable {
		Assert.assertTrue(projectReviewPage.getProjectCode().getText().length() == arg1);
	}

	@Then("^the project name field has (\\d+) characters$")
	public void the_project_name_field_has_characters(int arg1)
			throws Throwable {
		Assert.assertTrue(projectReviewPage.getProjectName().getText().length() == arg1);
	}

	@Then("^the project manager name field has (\\d+) characters$")
	public void the_project_manager_name_field_has_characters(int arg1)
			throws Throwable {
		Assert.assertTrue(projectReviewPage.getProjectManagerName().getText()
				.length() == arg1);
	}

	@Then("^the project manager MeID field has (\\d+) characters$")
	public void the_project_manager_MeID_field_has_characters(int arg1)
			throws Throwable {
		Assert.assertTrue(projectReviewPage.getProjectManagerMeID().getText()
				.length() == arg1);
	}

	@Then("^the cost center field has (\\d+) characters$")
	public void the_cost_center_field_has_characters(int arg1) throws Throwable {
		Assert.assertTrue(projectReviewPage.getCostCenter().getText().length() == arg1);
	}

	
	@When("^I try to add the project with same project code as an existing project$")
	public void i_try_to_add_the_project_with_same_project_code_as_an_existing_project() throws Throwable  {
		openProjectListPage();
		project.setProjectCode(projectListPage
				.findProjectCodeByManagerEmail("foo@foo.com"));
		projectListPage.appendNewProject();
		projectAddPage = getProjectAddPage(driver);
		projectAddPage.set(project);
		projectAddPage.save();
	}
	
	@When("^I update a project$")
	public void i_update_a_project() throws Throwable {
		openProjectListPage();
		project.setProjectCode(projectListPage
				.findProjectCodeByManagerEmail("foo@foo.com"));
		// pick a project that has foo@foo.com as the project manager email
		projectListPage.searchByProjectCode(project.getProjectCode());
		PageObject.sleep(5000);
		// this needs some sort of retry to make it work reliably
		String xpath = "//table[@id='ViewTable']//button[@title='Open this item']";

		// WebElement e = driver.findElement(By.xpath(xpath));
		// new Actions(driver).moveToElement(e).click().build().perform();
		driver.findElement(By.xpath(xpath)).click();

		// open update project page and scrape the project details from the page
		// and set on project object
		projectUpdatePage = getProjectUpdatePage(driver);
		project = projectUpdatePage.getProject(project);

		// update values and save
		project.setProjectName(RandomStringUtils.randomAlphanumeric(50));
		project.setProjectManagerName(RandomStringUtils.randomAlphanumeric(50));
		project.setProjectManagerMeID(RandomStringUtils.randomAlphanumeric(8));
		project.setProjectManagerEmail("foo@foo.com");
		project.setCostCenter(RandomStringUtils.randomNumeric(6));
		projectUpdatePage.setAndSubmit(project);

		projectUpdatePage.goBackToProjectListPage();
	}

	@Then("^the project has been updated$")
	public void the_project_has_been_updated() throws Throwable {
		// assumption project has been searched for
		projectListPage = getProjectListPage(driver);
		projectListPage.openProject();
		projectUpdatePage = getProjectUpdatePage(driver);
		updatedProject = projectUpdatePage.getProject(updatedProject);
		// now compare to update project
		Assert.assertTrue(project.equals(updatedProject));
		projectUpdatePage.cancel(); // close page otherwise this causes lock if
									// it stays open

	}

}
