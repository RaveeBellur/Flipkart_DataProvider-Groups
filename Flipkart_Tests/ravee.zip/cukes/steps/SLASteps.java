package mebank.cukes.steps;

import mebank.resources.SharedDriver;
import mebank.resources.Tabs;

import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.Then;

public class SLASteps extends BaseSteps {

	private final WebDriver driver;

	public SLASteps(SharedDriver webDriver) {
		this.driver = webDriver;
	}

	@Then("^I should see the \"(.*?)\" tab$")
	public void i_should_see_the_tab(String arg1) throws Throwable {		
		//driver.switchTo().defaultContent();//this is now handled in each of the tab page is loaded files
		switch (Tabs.fromPropertyName(arg1)) {		
		case CREATE_TIMESHEET:
			createTimesheetTabPage = getCreateTimesheetTabPage(driver);			
			break;
		case DATA_MAINTENANCE:
			projectMaintenancePage = getProjectMaintenancePage(driver);			
			break;
		case FOR_APPROVAL:
			// PROBLEM. the tab index is 1 if you're internal and 2 if you're
			// external
			// THIS is handled in the approveTimeSheetTabPage isLoaded
			approveTimeSheetTabPage = getApproveTimeSheetTabPage(driver);			
			break;
		case REPORTS:
			reportTabPage = getReportTabPage(driver);			
			break;
		case SEARCH:
			searchTabPage = getSearchTabPage(driver);			
			break;	
		case PENDING_SUBMISSION:
			pendingSubmissionTabPage = getPendingSubmissionTabPage(driver);			
			break;		
		case MARK_TO_BE_PAID:
			markToBePaidPage = getMarkTobePaidPage(driver);			
			break;		
		}				
	}
	
	@Then("^I click the \"(.*?)\" tab$")
	public void i_click_the_tab(String arg1) throws Throwable {
		switch (Tabs.fromPropertyName(arg1)) {		
		case CREATE_TIMESHEET:
			getTabsTable(driver).clickCreateTimeSheetTab();			
			break;
		case DATA_MAINTENANCE:
			getTabsTable(driver).clickDataMaintenanceTab();			
			break;
		case FOR_APPROVAL:
			getTabsTable(driver).clickApproveTab();			
			break;
		case REPORTS:
			getTabsTable(driver).clickReportsTab();
			break;
		case SEARCH:
			getTabsTable(driver).clickSearchTab();
			break;	
		case PENDING_SUBMISSION:
			getTabsTable(driver).clickPendingSubmissionsTab();
			break;
		case MARK_TO_BE_PAID:
			getTabsTable(driver).clickMarkToBePaidTab();
			break;		
		}
	}
}
