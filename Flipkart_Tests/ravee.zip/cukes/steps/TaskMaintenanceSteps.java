package mebank.cukes.steps;

import mebank.dataobjects.Task;
import mebank.pageobjects.PageObject;
import mebank.resources.SharedDriver;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TaskMaintenanceSteps extends BaseSteps {

	Task task = new Task();
	Task updatedTask = new Task();

	private final WebDriver driver;

	public TaskMaintenanceSteps(SharedDriver webDriver) {
		this.driver = webDriver;
	}

	private void openTaskListPage() {
		projectMaintenancePage = getProjectMaintenancePage(driver);
		projectMaintenancePage.viewTaskList();
		taskListPage = getTaskListPage(driver);
	}

	private void openTaskAddPage() {
		openTaskListPage();
		taskListPage.appendNewTask();
		taskAddPage = getTaskAddPage(driver);
	}

	@When("^I am on the task add page$")
	public void i_am_on_the_task_add_page() throws Throwable {
		// assumption. I have logged in ( as admin or the approver )
		openTaskAddPage();
	}

	@And("^I click save on the task add page$")
	public void i_click_save_on_the_task_add_page() throws Throwable {
		taskAddPage.save();
	}

	@When("^I have a new task$")
	public void i_have_a_new_task() throws Throwable {
		task.setTaskCode(RandomStringUtils.randomAlphanumeric(4));
		task.setDescription(RandomStringUtils.randomAlphanumeric(4));
		task.setTaskName("mojojojo"); // hardcoded as search for this in the
										// update scenario
	}

	@When("^I add the task$")
	public void i_add_the_task() throws Throwable {
		openTaskAddPage();
		taskAddPage.setAndSubmit(task);
		// TODO some sort of assertion that it saved
		taskAddPage.goBackToTaskListPage();
	}

	@Then("^the task is displayed in the task list$")
	public void the_task_is_displayed_in_the_task_list() throws Throwable {
		taskListPage.searchByTaskCode(task.getTaskCode());
		// assert on task code as the task name can be updated ( see update
		// scenario )
		Assert.assertTrue(PageObject.isAvailable(driver, By
				.xpath("//td[contains(text(), '" + task.getTaskCode() + "')]")));
	}

	@Then("^the task information is displayed$")
	public void the_task_information_is_displayed() throws Throwable {
		taskReviewPage = getTaskReviewPage(driver);
	}

	@Then("^the task name field has (\\d+) characters$")
	public void the_task_name_field_has_characters(int arg1) throws Throwable {
		Assert.assertTrue(projectReviewPage.getProjectName().getText().length() == arg1);
	}

	@When("^I update a task$")
	public void i_update_a_task() throws Throwable {
		openTaskListPage();
		task.setTaskCode(taskListPage.findTaskCodeByName("mojojojo"));

		taskListPage.searchByTaskCode(task.getTaskCode());

		String xpath = "//table[@id='ViewTable']//button[@title='Open this item']";

		// WebElement e = driver.findElement(By.xpath(xpath));
		// new Actions(driver).moveToElement(e).click().build().perform();
		driver.findElement(By.xpath(xpath)).click();

		// open update task page and scrape the task details from the page and
		// set on task object
		taskUpdatePage = getTaskUpdatePage(driver);
		task = taskUpdatePage.getTask(task);

		// update values and save
		task.setDescription(RandomStringUtils.randomAlphanumeric(8));
		task.setTaskName("mojojojo"); // needs to stay as moojo jojo
		taskUpdatePage.setAndSubmit(task);
		taskUpdatePage.goBackToTaskListPage();
	}

	@Then("^the task has been updated$")
	public void the_task_has_been_updated() throws Throwable {
		// assumption task has been searched for
		taskListPage = getTaskListPage(driver);
		taskListPage.openTask();
		taskUpdatePage = getTaskUpdatePage(driver);
		updatedTask = taskUpdatePage.getTask(updatedTask);
		// now compare to update project
		Assert.assertTrue(task.equals(updatedTask));
		taskUpdatePage.cancel(); // close page otherwise this causes lock if it
									// stays open

	}

	@Then("^I should see the task details table$")
	public void i_should_see_the_task_details_table() throws Throwable {		
		// text for build&test task
		String taskDesc = "Creating a pilot";
		Assert.assertTrue(PageObject.isAvailable(driver,
				By.xpath("//td[@contains(text(), '"+taskDesc+"')]")));
	}
	
	@Then("^I enter \"(.*?)\" in the task code field$")
	public void i_enter_in_the_task_code_field(String arg1) throws Throwable {
		taskAddPage.setTaskCode(arg1);
	}
	
	@When("^I try to add the task with same task code as an existing project$")
	public void i_try_to_add_the_task_with_same_task_code_as_an_existing_project() throws Throwable {
		openTaskListPage();
		task.setTaskCode(taskListPage.findTaskCodeByName("Solution Design"));
		taskListPage.appendNewTask();
		taskAddPage = getTaskAddPage(driver);
		taskAddPage.set(task);
		taskAddPage.save();
	}


}
