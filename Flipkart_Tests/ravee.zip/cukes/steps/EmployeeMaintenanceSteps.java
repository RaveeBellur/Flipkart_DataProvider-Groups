package mebank.cukes.steps;

import java.util.List;

import mebank.dataobjects.Employee;
import mebank.pageobjects.PageObject;
import mebank.resources.SharedDriver;
import mebank.resources.Utilities;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EmployeeMaintenanceSteps extends BaseSteps {

	Employee employee = new Employee();
	Employee updatedEmployee = new Employee();

	private final WebDriver driver;

	public EmployeeMaintenanceSteps(SharedDriver webDriver) {
		this.driver = webDriver;
	}

	@When("^I enter \"(.*?)\" in the email field$")
	public void i_enter_in_the_email_field(String arg1) throws Throwable {
		employee.setEmail(arg1);
		contractorAddPage.setEmail(employee.getEmail());
	}

	private void openEmployeeAddPage() {
		openEmployeeListPage();
		contractorListPage.appendNewContractor();
		contractorAddPage = getContractorAddPage(driver);
	}

	private void openEmployeeListPage() {
		projectMaintenancePage = getProjectMaintenancePage(driver);
		projectMaintenancePage.viewEmployeeList();
		contractorListPage = getContractorListPage(driver);
	}

	@When("^I am on the employee add page$")
	public void i_am_on_the_employee_add_page() throws Throwable {
		// assumption. I have logged in ( as admin or the approver )
		openEmployeeAddPage();
	}

	@When("^I enter \"(.*?)\" in the MeID field$")
	public void i_enter_in_the_MeID_field(String arg1) throws Throwable {
		employee.setMeID(parseArg(arg1));
		contractorAddPage.setMeID(employee.getMeID());
	}

	@When("^I enter \"(.*?)\" in the first name field$")
	public void i_enter_in_the_first_name_field(String arg1) throws Throwable {
		employee.setFirstName(parseArg(arg1));
		contractorAddPage.setFirstName(employee.getFirstName());
	}

	@When("^I enter \"(.*?)\" in the last name field$")
	public void i_enter_in_the_last_name_field(String arg1) throws Throwable {
		employee.setLastName(parseArg(arg1));
		contractorAddPage.setLastName(employee.getLastName());
	}

	@When("^I enter \"(.*?)\" in the full name field$")
	public void i_enter_in_the_full_name_field(String arg1) throws Throwable {
		employee.setFullName(parseArg(arg1));
		contractorAddPage.setFullName(employee.getFullName());
	}

	@When("^I enter \"(.*?)\" in the line manager MeID field$")
	public void i_enter_in_the_line_manager_MeID_field(String arg1)
			throws Throwable {
		employee.setLineManagerID(parseArg(arg1));
		contractorAddPage.setLineManagerID(employee.getLineManagerMeID());
	}

	@And("^I click save$")
	public void i_click_save() throws Throwable {
		contractorAddPage.save();
	}

	@When("^I have a new \"(.*?)\" employee$")
	public void i_have_a_new_employee(String arg1) throws Throwable {
		if (arg1.equalsIgnoreCase(Employee.CONTRACTOR)) {
			employee.setEmpType(Employee.CONTRACTOR);
			employee.setVendor("Paxus"); // default
		} else {
			employee.setEmpType(Employee.PERMANENT);
		}
		employee.setMeID(Utilities.randomMeID());
		employee.setFirstName(RandomStringUtils.randomAlphanumeric(8));
		employee.setLastName(RandomStringUtils.randomAlphanumeric(8));
		employee.setFullName(RandomStringUtils.randomAlphanumeric(8));
		employee.setEmail("dfd@daf.com");
		employee.setLineManagerID(Utilities.randomMeID());
		employee.setLineManagerName(RandomStringUtils.randomAlphanumeric(8));
		employee.setLineManagerEmail("where@ismytshirt.com");
		employee.setFillTimesheet(true);
	}

	@When("^the employee type is \"(.*?)\"$")
	public void the_employee_type_is(String arg1) throws Throwable {
		employee.setEmpType(arg1);
	}

	@When("^the vendor is \"(.*?)\"$")
	public void the_vendor_is(String arg1) throws Throwable {
		employee.setVendor(arg1);

	}

	@When("^I fill in the employee details$")
	public void i_fill_in_the_employee_details() throws Throwable {
		contractorAddPage.set(employee);
	}

	@When("^I add the employee$")
	public void i_add_the_employee() throws Throwable {
		openEmployeeAddPage();
		contractorAddPage.setAndSubmit(employee);
		contractorAddPage.goBackToEmployeeListPage();
	}

	@Then("^the employee is displayed in the employee list$")
	public void the_employee_is_displayed_in_the_employee_list()
			throws Throwable {
		contractorListPage.searchByMeID(employee.getMeID());
		// now search by MeID to assert record is in the list
		// ( otherwise need to find last page of pagination ? )
		Assert.assertEquals(
				PageObject.isAvailable(
						driver,
						By.xpath(".//td[contains(text(), '"
								+ employee.getFirstName() + "')]")), true);
	}

	@Then("^the employee information is displayed$")
	public void the_employee_information_is_displayed() throws Throwable {
		contractorReviewPage = getContractorReviewPage(driver);
	}

	@Then("^the first name field has (\\d+) characters$")
	public void the_first_name_field_has_characters(int arg1) throws Throwable {
		Assert.assertTrue(contractorReviewPage.getFirstName().getText()
				.length() == arg1);
	}

	@Then("^the last name field has (\\d+) characters$")
	public void the_last_name_field_has_characters(int arg1) throws Throwable {
		Assert.assertTrue(contractorReviewPage.getLastName().getText().length() == arg1);
	}

	@Then("^the full name field has (\\d+) characters$")
	public void the_full_name_field_has_characters(int arg1) throws Throwable {
		Assert.assertTrue(contractorReviewPage.getFullName().getText().length() == arg1);
	}

	@Then("^I should see the validation message \"(.*?)\"$")
	public void i_should_see_the_validation_message(String arg1)
			throws Throwable {
		// TODO consider using isAvailable as sometimes isElementPresent fails
		Assert.assertEquals(
				PageObject.isElementPresent(driver,
						By.xpath(".//*[contains(text(), '" + arg1 + "')]")),
				true);
	}

	@When("^I try to add the employee with same MeID as an existing employee$")
	public void i_try_to_add_the_employee_with_same_MeID_as_an_existing_employee()
			throws Throwable {
		openEmployeeListPage();
		employee.setMeID(contractorListPage
				.findEmployeeMeIDEmail("dfd@daf.com"));
		contractorListPage.appendNewContractor();
		contractorAddPage = getContractorAddPage(driver);
		contractorAddPage.set(employee);
		contractorAddPage.save();
	}

	@When("^I update an employee$")
	public void i_update_an_employee() throws Throwable {

		openEmployeeListPage();
		employee.setMeID(contractorListPage
				.findEmployeeMeIDEmail("dfd@daf.com"));
		// pick an employee that has dfa@daf.com as the email
		contractorListPage.searchByMeID(employee.getMeID());

		// TODO will need to expose the waitAndGetElement or push the click of
		// it onto the page
		// if push onto page its bad news because the page shouldn't encapsulate
		// test logic
		String xpath = "//table[@id='ViewTable']//button[@title='Open this item']";

		driver.findElement(By.xpath(xpath)).click();

		// open update project page and scrape the project details from the page
		// and set on project object
		contractorUpdatePage = getContractorUpdatePage(driver);
		employee = contractorUpdatePage.getEmployee(employee);

		
		// update values and save
		employee.setFirstName(RandomStringUtils.randomAlphanumeric(8));
		employee.setLastName(RandomStringUtils.randomAlphanumeric(8));
		employee.setFullName(RandomStringUtils.randomAlphanumeric(8));
		employee.setEmail("dfd@daf.com");
		employee.setFillTimesheet(true);
		contractorUpdatePage.setAndSubmit(employee);
		System.out.println(employee.toString());
		contractorUpdatePage.goBackToEmployeeListPage();
	}

	@Then("^the employee has been updated$")
	public void the_employee_has_been_updated() throws Throwable {
		// assumption employee has been searched for
		String xpath = "//table[@id='ViewTable']//button[@title='Open this item']";
		driver.findElement(By.xpath(xpath)).click();
		PageObject.sleep(5000);

		updatedEmployee = contractorUpdatePage.getEmployee(updatedEmployee);
		Assert.assertTrue(employee.equals(updatedEmployee));
		contractorUpdatePage.cancel();

	}

	@When("^I enter the employee details$")
	public void i_enter_the_employee_details(List<Employee> employees)
			throws Throwable {
		Employee e = employees.get(0);
		System.out.println(e.toString());
		contractorAddPage.set(e);
	}

	// because the long strings cause page to display with horizontal scroll bar
	// and this seems to
	// cause selenium an issue when clicking the open link
	// re-open the employee and edit strings
	// remove this when or if the devs implement wrapping
	@Then("^now cleanup the long strings$")
	public void now_cleanup_the_long_strings() throws Throwable {
		contractorAddPage.goBackToEmployeeListPage();		
		contractorListPage.searchByMeID(employee.getMeID());

		// TODO will need to expose the waitAndGetElement or push the click of
		// it onto the page
		// if push onto page its bad news because the page shouldn't encapsulate
		// test logic
		PageObject.sleep(5000);
		String xpath = "//table[@id='ViewTable']//button[@title='Open this item']";

		driver.findElement(By.xpath(xpath)).click();
		// open update project page and scrape the project details from the page
		// and set on project object
		contractorUpdatePage = getContractorUpdatePage(driver);
		employee = contractorUpdatePage.getEmployee(employee);

		// update values and save
		employee.setFirstName(RandomStringUtils.randomAlphanumeric(8));
		employee.setLastName(RandomStringUtils.randomAlphanumeric(8));
		employee.setFullName(RandomStringUtils.randomAlphanumeric(8));
		employee.setEmail("dfd@daf.com");
		employee.setFillTimesheet(true);
		contractorUpdatePage.setAndSubmit(employee);
		contractorUpdatePage.goBackToEmployeeListPage();

	}

}
