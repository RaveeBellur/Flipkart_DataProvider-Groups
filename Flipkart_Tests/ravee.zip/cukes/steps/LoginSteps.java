package mebank.cukes.steps;

import mebank.pageobjects.TopPage;
import mebank.resources.SharedDriver;
import mebank.resources.User;

import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class LoginSteps extends BaseSteps {

	String testName; // TODO move this to a superclass ?

	private final WebDriver driver;

	public LoginSteps(SharedDriver webDriver) {
		this.driver = webDriver;
	}

	/*
	 * @Before public void setUp(Scenario scenario) {
	 * System.out.println(this.getClass().getName() +"["+scenario.getName() +
	 * "] before!!!!!!!!!!!!!!!!!!!!"); driver =
	 * MySharedDriver.getDriverInstance(scenario); //super.setUp(); }
	 */

	/*
	 * //TODO move this to a superclass ?
	 * 
	 * @After public void tearDown(Scenario scenario) {
	 * 
	 * System.out.println("["+scenario.getName() +
	 * " ]after!!!!!!!!!!!!!!!!!!!!"); //super.tearDown(); if
	 * (TestConfig.flagSet("screenshots") && scenario.isFailed())
	 * Utilities.takeScreenShot(driver, scenario);
	 * if(TestConfig.flagSet("closeBrowserAfterTest")) { driver.quit();
	 * driver.close(); } }
	 */

	@Given("^I am on the ts app login page$")
	public void I_am_on_the_ts_app_login_page() throws Throwable {
		loginPage = getLoginPage(driver); 
				
	}

	@Then("^I logoff$")
	public void i_logoff() throws Throwable {
		logOffPage = (TopPage) new TopPage(driver).get();
		logOffPage.logoff();
	}

	@Given("^I login as \"(.*?)\"$")
	public void i_login_as(String arg1) throws Throwable {
		loginPage = getLoginPage(driver);		
		loginPage.login(User.getUser(arg1));				
	}

}
