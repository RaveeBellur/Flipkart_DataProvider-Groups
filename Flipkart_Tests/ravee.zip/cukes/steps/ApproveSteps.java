package mebank.cukes.steps;

import mebank.dataobjects.TimeSheet;
import mebank.dataobjects.TimeSheetRow;
import mebank.resources.SharedDriver;
import mebank.resources.User;
import mebank.resources.Utilities;

import org.openqa.selenium.WebDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ApproveSteps extends BaseSteps {

	private final WebDriver driver;

	public ApproveSteps(SharedDriver webDriver) {
		this.driver = webDriver;
	}

	
	@Given("^\"(.*?)\" has submitted a timesheet for \"(.*?)\"  to approve$")
	public void has_submitted_a_timesheet_for_to_approve(String arg1, String arg2) throws Throwable {
		loginPage = getLoginPage(driver);		
		loginPage.login(User.getUser(arg1));
		TimeSheet ts = new TimeSheet();
		
		String weekEndingDate = Utilities.getDate("current week");	
		ts.setWeekEnding(weekEndingDate);
		TimeSheetRow tsRow = new TimeSheetRow();
		tsRow.setMonday("1");
		tsRow.setProjectName(User.getUser(arg2).getManagesProject()); 
		ts.addTimeSheetRow(tsRow);
		createTimesheetTabPage = getCreateTimesheetTabPage(driver, ts);
		createTimesheetTabPage.selectWeekEnding();
		
		createTimesheetTabPage.clickCreateTimeSheetButton(driver);				
		createTimesheetFillPage = getCreateTimesheetFillPage(driver, ts);
		
		
		
		
		
		
		
		// create new ts 
		// click submit
		// logout
		// Write code here that turns the phrase above into concrete actions
	
	}

	@When("^\"(.*?)\" approves the timesheet$")
	public void approves_the_timesheet(String arg1) throws Throwable {
		loginPage = getLoginPage(driver);		
		loginPage.login(User.getUser(arg1));
		// Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^the timesheet status is pending full payment$")
	public void the_timesheet_status_is_pending_full_payment() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	

}
