package mebank.cukes.steps;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.WebDriver;

import mebank.dataobjects.TimeSheet;
import mebank.pageobjects.ApproveTimeSheetTabPage;
import mebank.pageobjects.BulkActionsTabPage;
import mebank.pageobjects.CreateTimesheetFillPage;
import mebank.pageobjects.CreateTimesheetSubmitConfirmPage;
import mebank.pageobjects.CreateTimesheetTabPage;
import mebank.pageobjects.PendingSubmissionTabPage;
import mebank.pageobjects.TopPage;
import mebank.pageobjects.LoginPage;
import mebank.pageobjects.ReportTabPage;
import mebank.pageobjects.SearchTabPage;
import mebank.pageobjects.TabsTable;
import mebank.pageobjects.TransferWorkItemTabPage;
import mebank.pageobjects.admin.ContractorAddPage;
import mebank.pageobjects.admin.ContractorListPage;
import mebank.pageobjects.admin.ContractorReviewPage;
import mebank.pageobjects.admin.ContractorUpdatePage;
import mebank.pageobjects.admin.MarkToBePaidPage;
import mebank.pageobjects.admin.ProjectAddPage;
import mebank.pageobjects.admin.ProjectListPage;
import mebank.pageobjects.admin.ProjectMaintenancePage;
import mebank.pageobjects.admin.ProjectReviewPage;
import mebank.pageobjects.admin.ProjectUpdatePage;
import mebank.pageobjects.admin.TaskAddPage;
import mebank.pageobjects.admin.TaskListPage;
import mebank.pageobjects.admin.TaskReviewPage;
import mebank.pageobjects.admin.TaskUpdatePage;

public class BaseSteps {

	public LoginPage loginPage;
	public TopPage logOffPage;
	public CreateTimesheetTabPage createTimesheetTabPage;
	public ApproveTimeSheetTabPage approveTimeSheetTabPage;
	public ProjectMaintenancePage projectMaintenancePage;
	public ProjectListPage projectListPage;
	public ProjectAddPage projectAddPage;
	public ProjectUpdatePage projectUpdatePage;
	public ContractorListPage contractorListPage;
	public ContractorAddPage contractorAddPage;
	public ContractorReviewPage contractorReviewPage;
	public ContractorUpdatePage contractorUpdatePage;
	public CreateTimesheetSubmitConfirmPage createTimesheetSubmitConfirmPage;
	public CreateTimesheetFillPage createTimesheetFillPage;
	public ProjectReviewPage projectReviewPage;
	public MarkToBePaidPage markToBePaidPage;
	public ReportTabPage reportTabPage;
	public SearchTabPage searchTabPage;
	public TabsTable tabs;
	public BulkActionsTabPage bulkActionsTabPage;
	public TransferWorkItemTabPage transferWorkItemTabPage;
	public PendingSubmissionTabPage pendingSubmissionTabPage;
 	
	
	public TaskListPage taskListPage;
	public TaskAddPage taskAddPage;
	public TaskReviewPage taskReviewPage;
	public TaskUpdatePage taskUpdatePage;

	 
	public PendingSubmissionTabPage getPendingSubmissionTabPage(WebDriver driver) {
		return (PendingSubmissionTabPage) new PendingSubmissionTabPage(driver).get();
	}
			
	public ReportTabPage getReportTabPage(WebDriver driver) {
		return (ReportTabPage) new ReportTabPage(driver).get();
	}
	
	public SearchTabPage getSearchTabPage(WebDriver driver) {
		return (SearchTabPage) new SearchTabPage(driver).get();
	}

	
	public BulkActionsTabPage getBulkActionsTabPage(WebDriver driver) {
		return (BulkActionsTabPage) new BulkActionsTabPage(driver).get();
	}

	public TransferWorkItemTabPage getTransferWorkItemTabPage(WebDriver driver) {
		return (TransferWorkItemTabPage) new TransferWorkItemTabPage(driver)
				.get();
	}

	public ProjectListPage getProjectListPage(WebDriver driver) {
		return (ProjectListPage) new ProjectListPage(driver).get();
	}

	public LoginPage getLoginPage(WebDriver driver) {
		return (LoginPage) new LoginPage(driver).get();
	}

	public TopPage getLogOffPage(WebDriver driver) {
		return (TopPage) new TopPage(driver).get();
	}

	//TODO see if can remove this and not pass in t/s through c/tor	
	public CreateTimesheetTabPage getCreateTimesheetTabPage(WebDriver driver,
			TimeSheet timeSheet) {
		return (CreateTimesheetTabPage) new CreateTimesheetTabPage(driver,
				timeSheet).get();
	}
	
	
	public CreateTimesheetTabPage getCreateTimesheetTabPage(WebDriver driver) {
		return (CreateTimesheetTabPage) new CreateTimesheetTabPage(driver).get();
	}

	
	public ApproveTimeSheetTabPage getApproveTimeSheetTabPage(WebDriver driver) {
		return (ApproveTimeSheetTabPage) new ApproveTimeSheetTabPage(driver).get();		
	}

	public ProjectMaintenancePage getProjectMaintenancePage(WebDriver driver) {
		return (ProjectMaintenancePage) new ProjectMaintenancePage(driver)
				.get();
	}

	public ProjectListPage getProjectListPage() {
		return projectListPage;
	}

	public ProjectAddPage getProjectAddPage(WebDriver driver) {
		return (ProjectAddPage) new ProjectAddPage(driver).get();
	}

	public ProjectUpdatePage getProjectUpdatePage(WebDriver driver) {
		return (ProjectUpdatePage) new ProjectUpdatePage(driver).get();
	}

	public ContractorListPage getContractorListPage(WebDriver driver) {
		return (ContractorListPage) new ContractorListPage(driver).get();
	}

	public ContractorAddPage getContractorAddPage(WebDriver driver) {
		return (ContractorAddPage) new ContractorAddPage(driver).get();
	}

	public ContractorReviewPage getContractorReviewPage(WebDriver driver) {
		return (ContractorReviewPage) new ContractorReviewPage(driver).get();
	}

	public ContractorUpdatePage getContractorUpdatePage(WebDriver driver) {
		return (ContractorUpdatePage) new ContractorUpdatePage(driver).get();
	}

	public CreateTimesheetSubmitConfirmPage getCreateTimesheetSubmitConfirmPage() {
		return createTimesheetSubmitConfirmPage;
	}

	public CreateTimesheetFillPage getCreateTimesheetFillPage(WebDriver driver,
			TimeSheet timeSheet) {
		return (CreateTimesheetFillPage) new CreateTimesheetFillPage(driver,
				timeSheet).get();
	}

	public ProjectReviewPage getProjectReviewPage(WebDriver driver) {
		return (ProjectReviewPage) new ProjectReviewPage(driver).get();
	}

	public MarkToBePaidPage getMarkTobePaidPage(WebDriver driver) {
		return (MarkToBePaidPage) new MarkToBePaidPage(driver).get();
	}

	public TaskListPage getTaskListPage(WebDriver driver) {
		return (TaskListPage) new TaskListPage(driver).get();
	}

	public TaskAddPage getTaskAddPage(WebDriver driver) {
		return (TaskAddPage) new TaskAddPage(driver).get();
	}

	public TaskReviewPage getTaskReviewPage(WebDriver driver) {
		return (TaskReviewPage) new TaskReviewPage(driver).get();
	}

	public TaskUpdatePage getTaskUpdatePage(WebDriver driver) {
		return (TaskUpdatePage) new TaskUpdatePage(driver).get();
	}

	public TabsTable getTabsTable(WebDriver driver) {
		return (TabsTable) new TabsTable(driver).get();
	}

	public SearchTabPage getSearchTabPage(WebDriver driver, TimeSheet timeSheet) {
		return (SearchTabPage) new SearchTabPage(driver, timeSheet).get();
	}

	// TODO consider moving this to Utilities
	public String parseArg(String arg) {
		// assumption.
		// format is X random type e.g. 7 random numeric
		String delims = " ";
		String[] tokens = arg.split(delims);
		System.out.println(tokens.length);
		if (tokens.length < 2)
			return arg;
		else if (tokens.length == 4) {
			if (tokens[1].equalsIgnoreCase("random")
					&& tokens[2].equalsIgnoreCase("alphanumeric"))
				arg = RandomStringUtils.randomAlphanumeric(Integer
						.parseInt(tokens[0]));
			else if ((tokens[1].equalsIgnoreCase("random") && tokens[2]
					.equalsIgnoreCase("numeric")))
				arg = RandomStringUtils.randomNumeric(Integer
						.parseInt(tokens[0]));
			else if ((tokens[1].equalsIgnoreCase("random") && tokens[2]
					.equalsIgnoreCase("special")))
				arg = RandomStringUtils.random(Integer.parseInt(tokens[0]),
						"!@#$%^&*()~".toCharArray());
		}
		return arg;
	}
}
