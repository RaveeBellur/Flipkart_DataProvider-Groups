package mebank.cukes.steps;

import mebank.dataobjects.TimeSheet;
import mebank.pageobjects.PageObject;
import mebank.resources.SharedDriver;
import mebank.resources.User;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TransferAssignmentSteps extends BaseSteps {

	private final WebDriver driver;

	TimeSheet ts;

	public TransferAssignmentSteps(SharedDriver webDriver) {
		this.driver = webDriver;
	}

	@Given("^click the options link$")
	public void click_the_options_link() throws Throwable {
		logOffPage = getLogOffPage(driver);
		logOffPage.clickOptions();
	}

	@Given("^click bulk actions$")
	public void click_bulk_actions() throws Throwable {
		logOffPage.clickBulkActions();
	}

	@Given("^select \"(.*?)\" from the transfer from dropdown$")
	public void select_from_the_transfer_from_dropdown(String arg1)
			throws Throwable {
		bulkActionsTabPage = getBulkActionsTabPage(driver);
		bulkActionsTabPage.selectTransferFrom(User.getUser(arg1));
	}

	@When("^the transfer page is displayed$")
	public void the_transfer_page_is_disaplyed() throws Throwable {
		transferWorkItemTabPage = getTransferWorkItemTabPage(driver);
	}

	@When("^timesheet is selected$")
	public void timesheet_is_selected_extract_out_the_ts_id() throws Throwable {
		// select the 1st checkbox and extract the case id at the same time
		// TODO validate there are items to transfer
		// FOR now assume there is always at least one
		ts = transferWorkItemTabPage.selectAssignmentFirst();
		System.out.println(ts.getCaseID());
	}

	@When("^select \"(.*?)\" from the transfer to dropdown$")
	public void select_from_the_transfer_to_dropdown(String arg1)
			throws Throwable {
		transferWorkItemTabPage.selectTransferTo(User.getUser(arg1));
	}

	@When("^click submit$")
	public void click_submit() throws Throwable {
		transferWorkItemTabPage.clickProcessSelectedAssignments();
	}

	@Then("^the ts is assigned to \"(.*?)\"$")
	public void the_ts_is_assigned_to(String arg1) throws Throwable {
		// search for ts from search tab
		// extract field assignedTo
		searchTabPage = getSearchTabPage(driver);
		searchTabPage.searchByCaseID(ts);				
		searchTabPage.openTimeSheet(ts);
	}
	
	
	@Given("^searches for a \"(.*?)\" timesheet$")
	public void searches_for_a_timesheet(String arg1) throws Throwable {
		searchTabPage = getSearchTabPage(driver);		
		if(arg1.equals("Resolved-Completed"))
			ts = searchTabPage.getResolvedCompletedTimeSheetFromTable();
		else if(arg1.equals("Pending-FullPayment"))
			ts = searchTabPage.getPendingFullPaymentTimeSheetFromTable();
		else if(arg1.equals("Pending-Submission"))
			ts = searchTabPage.getPendingSubmissionTimeSheetFromTable();
		else if(arg1.equals("Resolved-Withdrawn"))
			ts = searchTabPage.getResolvedWithdrawnTimeSheetFromTable();
		System.out.println(ts.getCaseID());
		searchTabPage.searchByCaseID(ts);		    
	}
	
	
	@Given("^clicks on the timesheet$")
	public void clicks_on_the_timesheet() throws Throwable {
		ts.toString();
		searchTabPage.openTimeSheet(ts);	
		//caseContentsTabPage = getCaseContentsTabPage(driver, ts);
	}

	@When("^the actions button is clicked$")
	public void the_actions_button_is_clicked() throws Throwable {
		//caseContentsTabPage.clickActions();
	}

	@Then("^there are no options$")
	public void there_are_no_options() throws Throwable {		
		String xpath = "//td[contains(text(), 'No actions')]";
		Assert.assertTrue(PageObject.isAvailable(driver, By.xpath(xpath)));			   
	}
	
	@Then("^the options menu has \"(.*?)\" as an option$")
	public void the_options_menu_has_as_an_option(String arg1) throws Throwable {
		String xpath = "//td[contains(text(), '"+arg1+"')]";
		Assert.assertTrue(PageObject.isAvailable(driver, By.xpath(xpath)));
	}

}
