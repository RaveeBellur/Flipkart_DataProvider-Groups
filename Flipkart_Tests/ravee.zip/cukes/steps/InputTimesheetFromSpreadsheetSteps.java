package mebank.cukes.steps;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Vector;

import mebank.dataobjects.TimeSheet;
import mebank.dataobjects.TimeSheetRow;
import mebank.pageobjects.CreateTimesheetSubmitConfirmPage;
import mebank.pageobjects.PageObject;
import mebank.resources.SharedDriver;
import mebank.resources.Utilities;
import mebank.resources.CopyRow;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Row;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class InputTimesheetFromSpreadsheetSteps extends BaseSteps {

	private final WebDriver driver;
	private boolean recordsToProcess = true;
	
	
	public InputTimesheetFromSpreadsheetSteps(SharedDriver webDriver) {
		this.driver = webDriver;
	}

	
	private void AdminOpenCreateTimesheetTab()
	{		
		logOffPage = getLogOffPage(driver);
		logOffPage.clickNew();
		logOffPage.clickCreateTimesheet();		
	}
	
	
	
	@When("^I create timehseets from spreadsheet$")
	public void i_create_timehseets_from_spreadsheet() throws Throwable {
	    // pseudo code
						
		String fileNameO = Utilities.resources("ts.xls");
		FileInputStream myInputO = new FileInputStream(fileNameO);        
		POIFSFileSystem myFileSystemO = new POIFSFileSystem(myInputO);
		HSSFWorkbook myWorkBookO = new HSSFWorkbook(myFileSystemO);
		HSSFSheet mySheetO = myWorkBookO.getSheetAt(0);
		int totalRowsO = mySheetO.getPhysicalNumberOfRows();
		System.out.println("totalRows0" + Integer.toString(totalRowsO));
		myInputO.close();
		
		
		// 1 through to totalRowsO-1 ( -1 for the header row )
		// using for loop won't work as 1 iteration of loop may consume more than 1 row
		//for(int i = 1; i < totalRowsO-1; i++) {			
		do {
			TimeSheet timsheet = readRowbyRowAndAddRowsToTimeSheet();//uncomment this when ready
		
			//TODO check timesheet object has > 0 ts rows before attempt to create ts. 
		
			// dummy this up for now 
			//TimeSheet ts = new TimeSheet();
			//ts.setEmployeeMeID("me714053");
			//String weekEndingDate = Utilities.getDate("current week - 2");	
			//ts.setWeekEnding(weekEndingDate);
										
		}while(recordsToProcess);
	    
	}

	@Then("^there are no errors$")
	public void there_are_no_errors() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	}
	
	
	// open the timesheet. 
	// read in the row and add a TimeSheetRow to the TimeSheet
	// peek ahead to next row
	// if next row is for same name and W/E add another TimeSheetRow
	// stop adding when not the same name and not the same W/E			
	public TimeSheet readRowbyRowAndAddRowsToTimeSheet() throws Exception
	{

		int totalRows = 0;
		int iteration = 1;
		//TODO we can move this out to above code
		TimeSheet timesheet = null; 
		
		
		// be sure to delete excess blank rows should only have one header row
		//for(int i = 0; i < totalRowsO-1; i++)
		//{
			timesheet = new TimeSheet();
			// re-open the sheet on each iteration
			String fileName = Utilities.resources("ts.xls");
			FileInputStream myInput = new FileInputStream(fileName);        
			POIFSFileSystem myFileSystem = new POIFSFileSystem(myInput);
			HSSFWorkbook myWorkBook = new HSSFWorkbook(myFileSystem);
			HSSFSheet mySheet = myWorkBook.getSheetAt(0);
			totalRows = mySheet.getPhysicalNumberOfRows();
			System.out.println("removeRow does not delete physical rows. TODO");
			System.out.println("was the row row deleted the physical num of rows should've decreased" + mySheet.getPhysicalNumberOfRows());

			// read the 1st row extract the ts row data and set it on the timesheet
			
			
			Vector<Vector<String>> dataHolder = readOnly1stRowOfSpreadsheet(fileName);// reads only 1st rows into the vector
			int totalRowsInDataHolder = dataHolder.size(); // should always be 1 or 0 if nothing added
			System.out.println("totalRowsInDataHolder "+totalRowsInDataHolder +" of " +totalRowsInDataHolder );
			System.out.println("line "+iteration +" of " +totalRows );
			// ok 1 line from sheet read in
			// should we close the file input stream here ?			
			myInput.close(); // do we need to close input stream before writing to output stream of same file ? 

			// only read if rows left to read
			Vector<?> cellStoreVector = (Vector<?>) dataHolder.elementAt(0);// gets the row
			System.out.println("cellStoreVector.size()" + cellStoreVector.size());
			if(cellStoreVector.size() < 1) {
				recordsToProcess = false;
			}
			else { // there's records to process
			
				timesheet = addTimeSheetRowFromDataHolderToTimesSheet(dataHolder, timesheet);

				readOtherRowsOfSpreadsheet(fileName, timesheet); // now check next rows to see if we have to add additional ts rows
				// at this point here we should have our timesheet object


				//timeSheet.setWeekEnding(weekEndingDate);// weekending date will come from spreadhseet

				AdminOpenCreateTimesheetTab();			
				// fill in the timesheet			
				createTimesheetTabPage = getCreateTimesheetTabPage(driver, timesheet);
				PageObject.savePageSource(driver, "are we on create tab");

				// for some reason set the date and then meid works better than meid then date
				createTimesheetTabPage.setMeIdTxt(timesheet.getEmployeeMeID());

				PageObject.sleep(2500);
				createTimesheetTabPage.selectWeekEnding();
				//PageObject.sleep(10000);
				//createTimesheetTabPage.setMeIdTxt(timesheet.getEmployeeMeID());

				createTimesheetTabPage.clickCreateTimeSheetButton(driver);
				// now at this point we're either on error or the fill timesheet screen
				boolean skipTsCreation = false;

				String txt = "Timesheet for the selected week already exists. Please select a different week.";
				//TODO we could also capture that meid is not valid and write this ?
				String xpath = "//span[@id='ERRORMESSAGES_ALL']//li[contains(text(), '"+txt+"')]";
				if(PageObject.isElementPresent(driver, By.xpath(xpath)))
					skipTsCreation = true;

				if(!skipTsCreation) {
					createTimesheetFillPage = getCreateTimesheetFillPage(driver, timesheet);
					createTimesheetFillPage.fillTimeSheet(timesheet);

					createTimesheetFillPage.submitTimeSheet();
					//TODO create getter same as other page objects
					createTimesheetSubmitConfirmPage 
					= (CreateTimesheetSubmitConfirmPage) new CreateTimesheetSubmitConfirmPage(
							driver).get();


					createTimesheetSubmitConfirmPage.submissionConfirmationAndCaptureTsID(timesheet);
					createTimesheetSubmitConfirmPage.closeTab();
				}
				else {
					//TODO still need to close the tab. tab label is new
					createTimesheetTabPage.closeTab();
					timesheet.setCaseID("timesheet already exists");// this will write to spreadsheet
				}

				//TODO to count num of rows to remove query the ts for how many timesheet rows have been added
				int numOfRowsToRemove = timesheet.getTimeSheetRows().size();

				removeRows(myWorkBook, mySheet, numOfRowsToRemove, timesheet);



				// write the spreadsheet to same file ? ( possible? yes only if file is not open by another process )

				// TODO write output to a new file
				// and append the case id

				FileOutputStream fileOut = new FileOutputStream(new File(fileName));
				myWorkBook.write(fileOut);	// if this crashed then next time you run it would attempt upload same file?		
				fileOut.flush();
				fileOut.close(); // ready for next iteration
			
			
		}	
		return timesheet;
	}
	
	 	
	private void readOtherRowsOfSpreadsheet(String fileName, TimeSheet timesheet)
	{
		// check if there are any more rows ? assumption here is the spreadsheet is sorted by W/E date  
		// start index here is 2... up until name changes. 		
		// i.e. won't have same name line up with a diff week ending ( otherwise we're in trouble )
		// check both name and w/e date are the same on subsequent rows if so add tsRow to ts
										
		int rowIndex = 2; // dangerous assumption that breaks down if only 1 row left..
		boolean employeeNameSame = true;// assume true until confirm false
		boolean weekEndingSame = true;// assume true until confirm false
		do {
						
			System.out.println("READING OTHER ROWS OF SPREADSHEET"+ rowIndex);
			Vector<Vector<String>> dataHolder = readRowOfSpreadsheet(fileName, rowIndex);
			
			Vector<?> cellStoreVector = (Vector<?>) dataHolder.elementAt(0);// gets the row
			
			System.out.println("cellStoreVector is Empty" + cellStoreVector.isEmpty());
			if(cellStoreVector.isEmpty()) {
				System.out.println("NO MORE ADDITIONAL ROWS TO READ");
				break;
			}
				
			String employeeName = (String) cellStoreVector.elementAt(2);
			String weekEnding = (String) cellStoreVector.elementAt(16);//NB
								
			employeeNameSame = employeeName.toLowerCase().trim().equals(timesheet.getEmployeeName().trim());			
			weekEndingSame = parseWeekEndingFromSpreadSheet(weekEnding).equals(timesheet.getWeekEnding());
			
			System.out.println(employeeName + "from ts " + timesheet.getEmployeeName().toLowerCase().trim());
			System.out.println(weekEnding + " from ts " + timesheet.getWeekEnding());
			System.out.println("employeeNameSame" + Boolean.toString(employeeNameSame) + " weekEndingSame " + Boolean.toString(weekEndingSame));
			
			if(employeeNameSame && weekEndingSame) {
				timesheet = addTimeSheetRowFromDataHolderToTimesSheet(dataHolder, timesheet);				
				rowIndex++;
				System.out.println("ADDING OTHER ROWS OF SPREADSHEET TO TS"+ rowIndex);
			}					
		}while(employeeNameSame && weekEndingSame);
		System.out.println("END READING OTHER ROWS OF SPREADSHEET"+ rowIndex);
	}
	
	private Vector<Vector<String>> readOnly1stRowOfSpreadsheet(String fileName)	{
		return readRowOfSpreadsheet(fileName, 1);
	}
		
	
	private Vector<Vector<String>> readRowOfSpreadsheet(String fileName, int rowIndex)		 
	{
		Vector<Vector<String>> cellVectorHolder = new Vector<Vector<String>>();

		try {
			System.out.println("*************** BEGIN READING ROW *********************");
			FileInputStream myInput = new FileInputStream(fileName);
			POIFSFileSystem myFileSystem = new POIFSFileSystem(myInput);
			HSSFWorkbook myWorkBook = new HSSFWorkbook(myFileSystem);
			HSSFSheet mySheet = myWorkBook.getSheetAt(0);

			Iterator<Row> rowIter = mySheet.rowIterator();
			
			if (rowIter.hasNext()) 
			{                        											
				for(int i=0; i < rowIndex; i++)	{
					rowIter.next(); // i.e. if row index is 1 skip the header row
				}
				
				HSSFRow myRow = (HSSFRow) rowIter.next(); // throws NoSuchElementException

				System.out.println("physical cell count " + Integer.toString(myRow.getPhysicalNumberOfCells()));
				System.out.println("myRow.getLastCellNum " + Integer.toString(myRow.getLastCellNum()));
				//Iterator<Cell> cellIter = myRow.cellIterator();

				Vector<String> cellStoreVector = new Vector<String>();

				printRowCells(myRow);
				
				for(int i = 0; i < myRow.getLastCellNum(); i++)
				{
					HSSFCell myCell = myRow.getCell(i);
					if(isEmptyCell(myCell))	{
						//System.out.println("Blank cell");                              	 
						cellStoreVector.addElement(new String());
					}   
					else {                        		
						//System.out.print("FnA [" + myCell.toString()+"]\t");
						cellStoreVector.addElement(myCell.toString());
					}
				}
				cellVectorHolder.addElement(cellStoreVector);                                                                                                                  
			}						
			System.out.println("\n");
			System.out.println("*************** END READING ROW *********************");
		} 
		catch(NoSuchElementException e) {
			recordsToProcess = false;
		}
		catch (IOException e) {
			e.printStackTrace();
		}	        
		return cellVectorHolder;
	}
	
		
	private TimeSheet addTimeSheetRowFromDataHolderToTimesSheet(Vector<Vector<String>> dataHolder, TimeSheet ts)
	{
		Vector<?> cellStoreVector = (Vector<?>) dataHolder.elementAt(0);// gets the row
		System.out.println("cellStoreVector.size()" + cellStoreVector.size());
				
		//TODO if no data means we ran out of rows to read so short cut. return
		
		// note hard coded indexes refer to spreadsheet supplied by finance
		String caseId = (String) cellStoreVector.elementAt(0);
		String meId = (String) cellStoreVector.elementAt(1);
		String employeeName = (String) cellStoreVector.elementAt(2);
		String project = (String) cellStoreVector.elementAt(3); 
		String task = (String) cellStoreVector.elementAt(5);			 
		String monHours= (String) cellStoreVector.elementAt(6);			         	 
		String tueHours = (String)  cellStoreVector.elementAt(7);        	         	 
		String wedHours = (String)  cellStoreVector.elementAt(8);        	         	 
		String thuHours = (String) cellStoreVector.elementAt(9);        	         	 
		String friHours = (String) cellStoreVector.elementAt(10);
		String satHours = (String) cellStoreVector.elementAt(11);
		String sunHours = (String) cellStoreVector.elementAt(12);			
		String weekEnding = (String) cellStoreVector.elementAt(16);
		String comments = (String) cellStoreVector.elementAt(18);

		System.out.println("caseId ["+ caseId +"]");
		System.out.println("meId ["+ meId +"]");
		System.out.println("employeeName [" + employeeName+"]");
		System.out.println("project ["+ project+"]");
		System.out.println("task [" + task+"]");
		System.out.println("monHours [" + monHours+"]");
		System.out.println("tueHours [" + tueHours+"]");
		System.out.println("wedHours [" + wedHours+"]");
		System.out.println("thuHours [" + thuHours+"]");
		System.out.println("friHours [" + friHours+"]");
		System.out.println("satHours [" + satHours+"]");
		System.out.println("sunHours [" + sunHours+"]");
		System.out.println("weekEnding [" + weekEnding+"]");
		System.out.println("comments [" + comments+"]");
		
		TimeSheetRow tsRow = new TimeSheetRow();
		// in some instances in spreadsheet there is trailing white space so trim
		tsRow.setProjectName(project.trim());		
		tsRow.setProjectTask(task.trim());
		tsRow.setMonday(monHours.trim());
		tsRow.setTuesday(tueHours.trim());
		tsRow.setWednesday(wedHours.trim());
		tsRow.setThursday(thuHours.trim());
		tsRow.setFriday(friHours.trim());
		tsRow.setSaturday(satHours.trim());
		tsRow.setSunday(sunHours.trim());								
		tsRow.setSubmitterComments(comments.trim());
		ts.addTimeSheetRow(tsRow);
		
		ts.setEmployeeMeID(meId.trim());
		ts.setEmployeeName(employeeName.trim());
		System.out.println("weekending from s/s" + weekEnding); //10-Aug-2014
		System.out.println("week ending after parse through get date" + Utilities.getDate(weekEnding));		
		// parse 10-Aug-2014 to dd/mm/yyyy
							
		ts.setWeekEnding(parseWeekEndingFromSpreadSheet(weekEnding));
				
		return ts;									
	}
	
	private String parseWeekEndingFromSpreadSheet(String unParsedWeekEnding) {
		String parsedWeekEnding = "";
		try {
			Calendar cal = Calendar.getInstance(); 
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MMM-yyyy");
			System.out.println("PARSE WEEKENDING" + sdf1.parse(unParsedWeekEnding));
			//cal.setTime(new SimpleDateFormat("dd-MMM-yyyy").parse(weekEnding));
			cal.setTime(sdf1.parse(unParsedWeekEnding));
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd"); // why does yyyyddmm not work ?
			parsedWeekEnding = sdf.format(cal.getTime());
			System.out.println("FOOO MAN CHOO" + parsedWeekEnding);												
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.assertTrue(e.getMessage(),false);
		}
		return parsedWeekEnding;
	}
	
	
	
	private  void removeRows(HSSFWorkbook workbook, HSSFSheet sheet, int numOfRowsToRemove, TimeSheet timesheet)  {
		System.out.println("numOfRowsToRemove" + Integer.toString(numOfRowsToRemove));
		
		int rowIndex = 1; // always remove the 1st row as previous remove has already shifted the rows
				
		for(int i = 0; i < numOfRowsToRemove; i++)
		{				
						
			try {
				System.out.println("WRITING TO PROCESSED.XLS");
				String fileNameO = Utilities.resources("processed.xls");
				
				// check if file exists if not create it
				File f = new File(fileNameO);
				if(!f.exists() && !f.isDirectory()) {
					HSSFWorkbook wb = new HSSFWorkbook();
				    FileOutputStream fileOut = new FileOutputStream(fileNameO);
				    HSSFSheet sheet1 = wb.createSheet("processed");
				    wb.write(fileOut);
				    fileOut.close();
				}

				// open file 
				FileInputStream myInputO = new FileInputStream(fileNameO);        
				POIFSFileSystem myFileSystemO = new POIFSFileSystem(myInputO);
				HSSFWorkbook destBook = new HSSFWorkbook(myFileSystemO);
				HSSFSheet destSheet = destBook.getSheetAt(0);
									
				int lastRowOfProcessedTimeSheets=destSheet.getLastRowNum();
				System.out.println("processed.xls last row num["+lastRowOfProcessedTimeSheets+"]");
				int lastRowOfSrcTimeSheets=sheet.getLastRowNum();
				System.out.println("ts.xls last row num["+lastRowOfSrcTimeSheets+"]");
				//mySheetO.createRow(rownum)
				
				HSSFRow removingRow = sheet.getRow(rowIndex);
				// add caseid to the cell0 on the row before we copy and then finally the delete
				
				printRowCells(removingRow);
						
				
				HSSFCell cell0 = removingRow.getCell(0);//wtf ? why does this not seem to start at 0
				
				cell0.setCellValue(timesheet.getCaseID());				
				printRowCells(removingRow);
				
				//so last row is always one you want to add to ?
				// may need to do a +1 on this lastRowOfProcessedTimeSheets
				destSheet = CopyRow.copyRow(workbook, sheet, destSheet, rowIndex, lastRowOfProcessedTimeSheets+1);

				//Row row = sheet.createRow((short)0);
				//TODO whilst we're remove Row append a cell to the row and append to a new TS.		

				FileOutputStream fileOut = new FileOutputStream(new File(fileNameO));
				destBook.write(fileOut);			
				fileOut.flush();
				fileOut.close(); // ready for next iteration
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
				e.printStackTrace();
			} catch (IOException e) {
				System.out.println(e.getMessage());
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			// need to get row write it to other sheet then delete it from sheet we read data from
			int lastRowNum=sheet.getLastRowNum();
			if(rowIndex>=0&&rowIndex<lastRowNum){
				System.out.println("shift rows in ts.xls");
				sheet.shiftRows(rowIndex+1,lastRowNum, -1);
			}
			if(rowIndex==lastRowNum){
				System.out.println("if it is last row you cannot shift so remove ts.xls");
				HSSFRow removingRow=sheet.getRow(rowIndex);
				if(removingRow!=null){
					sheet.removeRow(removingRow);										
				}
			}
		}
	}
	
	private Boolean isEmptyCell (HSSFCell cell) {
		if(cell == null) {  
			System.out.println("cell is null");			
			return true;
		}
		if(cell.getCellType() == HSSFCell.CELL_TYPE_BLANK)
			return true;
		// ... add extra checks
		return false;
	}
	
	private void printRowCells(HSSFRow row)
	{
		// for purposes of testing this works we're only interested in first 20 columns
		//int maxCell = row.getLastCellNum();
		int maxCell = 20;
		for(int i = 0; i < maxCell; i++)
		{
			HSSFCell myCell = row.getCell(i);
			if(myCell == null) {
				System.out.println(i+ " null");							
			}
			if(isEmptyCell(myCell))	{
				System.out.println(i + " Blank cell");                              	 				
			}   
			else {                        		
				System.out.print(i + "cell [" + myCell.toString()+"]\t");				
			}
		}
	}
	
	
			
}
