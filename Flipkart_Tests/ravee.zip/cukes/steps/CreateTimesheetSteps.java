package mebank.cukes.steps;

import java.util.List;

import mebank.dataobjects.TimeSheet;
import mebank.dataobjects.TimeSheetRow;
import mebank.pageobjects.ApproveTimeSheetTabPage;
import mebank.pageobjects.CreateTimesheetSubmitConfirmPage;
import mebank.resources.SharedDriver;
import mebank.resources.Utilities;

import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CreateTimesheetSteps extends BaseSteps {

	TimeSheet timeSheet;
	private final WebDriver driver;

	public CreateTimesheetSteps(SharedDriver webDriver) {
		this.driver = webDriver;
	}

	/*
	 * @Given("^the following users exist:$") public void
	 * the_following_users_exist(DataTable arg1) throws Throwable {
	 * List<Employee> mylist = arg1.asList(Employee.class); for (Employee e :
	 * mylist) { System.out.println(e.getFirstName());
	 * System.out.println(e.getEmail()); System.out.println(e.getRate()); }
	 * 
	 * }
	 */


	@Given("^I create a timesheet for \"(.*?)\"$")
	public void i_create_a_timesheet_for_the_week(String timeSheetWeek) throws Throwable {
		timeSheet = new TimeSheet();
		
		String weekEndingDate = Utilities.getDate(timeSheetWeek);	
		timeSheet.setWeekEnding(weekEndingDate);
		
		createTimesheetTabPage = getCreateTimesheetTabPage(driver, timeSheet);
		createTimesheetTabPage.selectWeekEnding();
		
		createTimesheetTabPage.clickCreateTimeSheetButton(driver);				
		createTimesheetFillPage = getCreateTimesheetFillPage(driver, timeSheet);
		
	}

	@Given("^I enter the timesheet rows$")
	public void i_input_the_timesheet_data(List<TimeSheetRow> timeSheetRows)
			throws Throwable {
		//Map<String, TimeSheetRow> tsRowList = new HashMap<String, TimeSheetRow>();

		for (TimeSheetRow row : timeSheetRows) {
			// System.out.println(row.toString());
			timeSheet.addTimeSheetRow(row);
		}
		createTimesheetFillPage.fillTimeSheet(timeSheet);
	}

	@When("^I save the timesheet$")
	public void i_save_the_timesheet() throws Throwable {
		createTimesheetFillPage.saveDraft();	   
	}
	

	/*
	@And("^I enter hours as \"(.*?)\"$")
	public void i_enter_the_hours(String arg1) throws Throwable {
		timeSheet.setTimeSheetRow().setMonday(arg1);
		createTimesheetFillPage.fillHours();
	}*/

	@And("^I submit the timesheet$")
	public void i_submit_a_timesheet() throws Throwable {
		createTimesheetFillPage.submitTimeSheet();
	}

	@Then("^I should see the submission confirmation page$")
	public void i_should_see_the_submission_confirmation_page()
			throws Throwable {
		createTimesheetSubmitConfirmPage = (CreateTimesheetSubmitConfirmPage) new CreateTimesheetSubmitConfirmPage(
				driver).get();
		createTimesheetSubmitConfirmPage.submissionConfirmationAndCaptureTsID(timeSheet);
	}

	// TODO this needs to be moved
	@When("^I approve the timesheets$")
	public void i_approve_a_timesheet() throws Throwable {
		approveTimeSheetTabPage = (ApproveTimeSheetTabPage) new ApproveTimeSheetTabPage(
				driver).get();
		approveTimeSheetTabPage.approveAllTimeSheets();
	}

	@Then("^I should not see any pending timesheets for approval$")
	public void i_should_not_see_any_pending_timesheets_for_approval()
			throws Throwable {
		// TO DO - Write code here that turns the phrase above into concretes
		// actions
	}

	@When("^I click the project task details link$")
	public void i_click_the_project_task_details_link() throws Throwable {		
		createTimesheetFillPage.expandProjectTaskDetailsInfo();	    
	}

}
