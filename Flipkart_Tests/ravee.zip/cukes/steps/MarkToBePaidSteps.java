package mebank.cukes.steps;

import mebank.dataobjects.TimeSheet;
import mebank.resources.SharedDriver;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MarkToBePaidSteps extends BaseSteps{
	
	TimeSheet timeSheet;
	private final WebDriver driver;

	public MarkToBePaidSteps(SharedDriver webDriver) {
		this.driver = webDriver;
	}

	
	@Given("^I have a timesheet in \"(.*?)\" status$")
	public void i_have_a_timesheet_in_status(String arg1) throws Throwable {
		searchTabPage = getSearchTabPage(driver);
	    //TODO put in a switch to select full or partial
		timeSheet = searchTabPage.getPendingFullPaymentTimeSheetFromTable();
	}
	
	

	@When("^I mark the timesheet for payment in full$")
	public void i_mark_the_timesheet_for_payment_in_full() throws Throwable {
		markToBePaidPage = getMarkTobePaidPage(driver);
		markToBePaidPage.markToBePaidInFull(timeSheet);		
	}

	@And("^I click submit$")
	public void i_click_submit() throws Throwable {
		markToBePaidPage.submit();
	}

	@Then("^the timesheet is no longer displayed$")
	public void the_timesheet_is_no_longer_displayed() throws Throwable {
		String errorMsg = " << Timesheet payment failed >> ";						
		Assert.assertFalse(errorMsg, markToBePaidPage.isTimeSheetInListOfMarkToBePaid(timeSheet));
	}

	@And("^I search for the timesheet$")
	public void i_search_for_the_timesheet() throws Throwable {
		searchTabPage = getSearchTabPage(driver);
		searchTabPage.searchByCaseID(timeSheet);
	}
	
	@And("^the status of the timesheet is \"(.*?)\"$")
	public void the_status_of_the_timesheet_is_resolved_completed(String status) throws Throwable {
		String errorMsg = "<< Timesheet is not in Resolved-Complete status after payment >> ";
		Assert.assertTrue(errorMsg, status.equalsIgnoreCase(searchTabPage.getTimeSheetStatus(timeSheet)));		 				
	}
}
