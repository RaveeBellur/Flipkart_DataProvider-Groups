package mebank.cukes;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.*;

import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(features = { "src/test/resources/task_maintenance.feature" }, 
//name = { "^validation on the add task page$" },
//name= {"^Admin adds a new task$"},
// name= {"^Admin updates an existing task$"},
//name= {"^cannot create duplicate$"},

format = { "pretty", "html:target/cucumber" })
public class TaskMaintenanceFeatureRunner {
}