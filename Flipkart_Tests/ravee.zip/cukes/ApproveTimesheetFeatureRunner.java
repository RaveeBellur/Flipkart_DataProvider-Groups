package mebank.cukes;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.*;

import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(		        
		features= {"src/test/resources/approve_timesheet.feature"}, 		
        format = {"pretty", "html:target/cucumber"} 
)
public class ApproveTimesheetFeatureRunner {}
