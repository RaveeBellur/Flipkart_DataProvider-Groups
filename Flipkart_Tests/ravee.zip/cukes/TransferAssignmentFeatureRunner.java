package mebank.cukes;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.*;

import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(features = { "src/test/resources/transfer_assignment.feature" }, 
name= {"^transfer a pending approval timesheet to the administrator$"}, 

format = { "pretty", "html:target/cucumber" })
public class TransferAssignmentFeatureRunner {
}