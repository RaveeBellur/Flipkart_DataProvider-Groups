package mebank.cukes;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.*;

import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(features = { "src/test/resources/create_timesheet.feature" },
// name= {"^submit", "^approve","mark"},
// name= {"^submit", "^approve"},
 name= {"^submit"},
// name= {"^approve"},
// name= {"^mark the timesheets to be paid"},
//name = { "^click task details link" }, 
 format = { "pretty",	"html:target/cucumber" })

public class CreateTimesheetFeatureRunner {}
//name = { "^click task details link" }, 
