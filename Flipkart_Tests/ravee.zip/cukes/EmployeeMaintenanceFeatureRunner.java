package mebank.cukes;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.*;

import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(features = { "src/test/resources/employee_maintenance.feature" }, 
//name = { "^Email validation on the add employee page$" },
//name= {"^Max character validation on the add employee page$"},
//name= {"^Admin updates an existing employee$"},
name= {"^Admin adds a new employee$"},
//name= {"^MeID is alphanumeic$"},
//name= {"^meid should be alphanumeric and contain no spaces$"},
//name= {"^cannot create duplicate$"},

format = { "pretty", "html:target/cucumber" })
public class EmployeeMaintenanceFeatureRunner {
}
