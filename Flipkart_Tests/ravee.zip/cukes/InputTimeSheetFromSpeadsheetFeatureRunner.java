package mebank.cukes;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.*;

import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(features = { "src/test/resources/input_ts_from_spreadsheet.feature" }, 
format = { "pretty", "html:target/cucumber" })
public class InputTimeSheetFromSpeadsheetFeatureRunner {
}