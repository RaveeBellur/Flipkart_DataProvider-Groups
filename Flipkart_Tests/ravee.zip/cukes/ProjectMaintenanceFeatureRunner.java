package mebank.cukes;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.*;

import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(features = { "src/test/resources/project_maintenance.feature" },
//name= {"^Max character validation on the add project page$"},
//name= {"^Email validation on the add project page$"},
//name= {"^Admin adds a new project$"},
name = { "^Admin updates an existing project$" },
//name = { "^project manager meid should be alphanumeric and contain no spaces$" },
//name = { "^cannot create duplicate$" }, 
		 
format = { "pretty", "html:target/cucumber" })
public class ProjectMaintenanceFeatureRunner {
}