package mebank.cukes;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.*;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(		        
		features= {"src/test/resources/mark_to_be_paid.feature"},
				  // name= {"^full pay"},
				   //  name= {"^partial pay"},
				
        format = {"pretty", "html:target/cucumber"} 
)

public class MarkToBePaidFeatureRunner {}
