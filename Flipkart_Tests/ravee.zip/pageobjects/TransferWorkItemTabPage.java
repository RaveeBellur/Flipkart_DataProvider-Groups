package mebank.pageobjects;

import mebank.dataobjects.Employee;
import mebank.dataobjects.TimeSheet;
import mebank.resources.Iframes;
import mebank.resources.Utilities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class TransferWorkItemTabPage extends PageObject {

	// TODO implement

	@FindBy(id = "sub")
	private WebElement sub;

	@FindBy(xpath = "//select[@id='objOperatorSelect']")
	private WebElement transferWorkToSelect;
	
	// TODO find checkbox

	@FindBy(xpath = "//button[@id='bulkSubmitButtonEnabled']")
	private WebElement processSelectedAssignmentsBtn;

	private final WebDriver driver;

	public TransferWorkItemTabPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@Override
	protected void load() {
		System.out.println(this.getClass().toString() + " load()");
	}

	@Override
	protected void isLoaded() throws Error {
		System.out.println(this.getClass().toString() + " isLoaded()");
		
		//click the tab if on the the tab by default or not ( i.e. simplify the code )
		TabsTable t = (TabsTable) new TabsTable(driver).get();
		t.clickWorkItemTab();
		
		String frameName = Iframes.TRANSFER_WORK_ITEM_FRAME_NAME.getFrameName();
		boolean FrameLoaded = isAvailable(driver,
				By.xpath("//iframe[@id='" + frameName + "']"));
		// TODO a better check page is loaded other than the frame
		if (FrameLoaded) {
			// IFRAME / FRAME NESTED CLUSTER-F
			//waitForFrameAndSwitchToIt(driver, frameName);												
			//switchIntoBulkProcessingFrame();																			
			//switchIntoResultsView();
			switchIntoActionsView(); // this has the process selected assignments button																										
		}
	}

	private void switchIntoBulkProcessingFrame() {
		System.out.println("is frame present? "+ isAvailable(driver, By.xpath("//iframe[@id='BulkProcessing']")));		
		waitForFrameAndSwitchToIt(driver, By.xpath("//iframe[@id='BulkProcessing']")); // top frame with refresh button
		Utilities.listFrames(driver);
		//savePageSource(driver, "bulkProcessingFrame ( nested in PwGadget7");																									
		//System.out.println("is frame present? "+ isAvailable(driver, By.xpath("//frameset")));
		System.out.println("is frame present? "+ isAvailable(driver, By.xpath("//frameset[@id='fsid']")));
	}
	
	
	private void switchIntoResultsView() {	
		driver.switchTo().defaultContent();
		waitForFrameAndSwitchToIt(driver, Iframes.TRANSFER_WORK_ITEM_FRAME_NAME.getFrameName());
		switchIntoBulkProcessingFrame();
		System.out.println("is frame present? "+ isAvailable(driver, By.xpath("//frame[@title='Results View']")));		
		waitForFrameAndSwitchToIt(driver, By.xpath("//frame[@title='Results View']"));			
		Utilities.listFrames(driver);
		//savePageSource(driver, "results view");
		//ok we should be on the top frame that has check boxes to select		
		System.out.println("is frame present? "+ isAvailable(driver, By.xpath("//input[@title='Select this item']")));		
	}
	
	private void switchIntoActionsView() {			
		driver.switchTo().defaultContent();
		waitForFrameAndSwitchToIt(driver, Iframes.TRANSFER_WORK_ITEM_FRAME_NAME.getFrameName());
		switchIntoBulkProcessingFrame();
		System.out.println("is frame present? "+ isAvailable(driver, By.xpath("//frame[@title='Detailed View']")));
		waitForFrameAndSwitchToIt(driver, By.xpath("//frame[@title='Detailed View']"));			
		Utilities.listFrames(driver);		
		//savePageSource(driver, "detailed view");
		System.out.println("is frame present? "+ isAvailable(driver, By.xpath("//div[@id='actionContainer']")));
		// this frame contains an iframe .. 		
		waitForFrameAndSwitchToIt(driver, By.xpath("//iframe[@name='actionIFrame']"));
		System.out.println("is process selected assignment buttons present ? "+ isAvailable(driver, getBy("processSelectedAssignmentsBtn")));
	}
	
			
	public void submit() {
		sub.click();
	}

	public TimeSheet selectAssignmentFirst() {
		switchIntoResultsView();		
		driver.findElement(By.xpath("//input[@title='Select this item']"))
				.click();
		String xpath = "//input[@title='Select this item']/parent::td/parent::tr/td[3]";
		String caseId = driver.findElement(By.xpath(xpath)).getText();
		TimeSheet ts = new TimeSheet();
		ts.setCaseID(caseId);
		return ts;
	}
	
	public void selectTransferTo(Employee e) {
		switchIntoActionsView();
		System.out.println("select transfer to " + e.getFullName());
		Select transferWorkToSelect = new Select(this.transferWorkToSelect);
		transferWorkToSelect.selectByValue(e.getMeID());// note the select displays names but the values are meid		 					
	}
	
	public void clickProcessSelectedAssignments() {
		switchIntoActionsView();
		processSelectedAssignmentsBtn.click();
	}
	

}
