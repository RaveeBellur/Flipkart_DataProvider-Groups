package mebank.pageobjects;

import java.util.ArrayList;
import java.util.List;

import mebank.dataobjects.TimeSheet;
import mebank.dataobjects.TimeSheetRow;
import mebank.resources.Iframes;
import mebank.resources.TestConfig;
import mebank.resources.User.LoggedInUser;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;



public class CreateTimesheetFillPage extends PageObject {

	@FindBy(id = "ProjectName")
	private WebElement projectName;

	@FindBy(id = "TaskDesc")
	private WebElement projectTask;

	@FindBy(id = "submitButton")
	private WebElement btnSubmit;

	@FindBy(xpath = "//button[contains(text(), 'Save Draft')]")
	private WebElement btnSave;

	
	
	//@FindBy(xpath = "//div[@id='CT' and @style='display:block']//a")
	@FindBy(xpath = "//div[@id='CT']//td[@class='dataValueRead']//a[contains(@style, 'collapsed')]")
	private WebElement lnkProjectTaskDetails;

	
	private final WebDriver driver;
	private TimeSheet timeSheet;

	// PROBLEM with passing it in and storing it is if it changes? ? ?
	public CreateTimesheetFillPage(WebDriver driver, TimeSheet timeSheet) {
		this.driver = driver;
		this.timeSheet = timeSheet;
		PageFactory.initElements(driver, this);
	}

	@Override
	protected void load() {
		System.out.println("start" + this.getClass().getName() + "load()");
	}

	@Override
	protected void isLoaded() throws Error {
		System.out.println(this.getClass().toString() + " isLoaded()");
		//PageObject.listAllElementsOnPage(driver, By.xpath("//iframe"));		
		TabsTable t = (TabsTable) new TabsTable(driver).get();
		
		String frameName = "noFrameName";
		if (LoggedInUser.getInstance().getLoggedInUser().getUserType()
				.equals("ADMINISTRATOR")) {
			frameName = Iframes.ADMIN_FILL_TIMESHEET_ROWS_TAB_FRAME_NAME
					.getFrameName();	
		} else 
			frameName = Iframes.FILL_TIMESHEET_ROWS_TAB_FRAME_NAME
					.getFrameName();
								
		boolean frameLoaded = isAvailable(driver, 30000, 
				By.xpath("//iframe[@id='" + frameName + "']"));		
		if (frameLoaded) {			
			waitForFrameAndSwitchToIt(driver, frameName);
			//waitUntilLoaded(driver, this.getBy("projectName")); // or use an isAvailable
			isAvailable(driver, 30000, this.getBy("btnSave"));
			//waitUntilLoaded(driver, this.getBy("projectName"));
			//waitUntilLoaded(driver, this.getBy("projectTask"));			
		}
	}

	// use this to track filled rows
	List<TimeSheetRow> timesheetRowsFilled = new ArrayList<TimeSheetRow>(); 

	public void fillTimeSheet(TimeSheet timesheet) {
		List<TimeSheetRow> tsRowList = timesheet.getTimeSheetRows();
		// TODO if you're going to add a new row to an existing timesheet check
		// how many rows currently populated. do this as part of loaded.
		// FOr now assume we start with a blank page
						
		// 2 rows by default. add additional rows if required before filling the t/s
		int numOfTsRowsToFill = timesheet.getTimeSheetRows().size();
		System.out.println("number of timesheet rows to fill " + numOfTsRowsToFill);
		if(numOfTsRowsToFill > 2) {
			 for(int i = 0; i < numOfTsRowsToFill -2; i++) {
				 driver.findElement(By.xpath("//a[contains(text(), 'Add another Project')]")).click();
				 sleep(2500);
				 //TODO verify ts row on screen
			 }
		}
		
		// fill t/s row by row
		for (TimeSheetRow row : tsRowList) {			
			int rowIndex = tsRowList.indexOf(row); 
			selectProjectName(rowIndex);
			selectProjectTask(rowIndex);
			setHours(rowIndex);
			setSubmitterComments(rowIndex);
			timesheetRowsFilled.add(row); 
		}
	}

	public void selectProjectName(int rowIndex) {		
		waitUntilLoaded(driver, this.getBy("projectName"));

		List<WebElement> projectDropDowns = driver.findElements(By
				.id("ProjectName"));
		Select projSelect = new Select(projectDropDowns.get(rowIndex));
		
		if(TestConfig.flagSet("verbose")) {			
			for (WebElement o : projSelect.getOptions()) {
				 System.out.println(o.getText()); 
			}			
		}
		

		projSelect.selectByValue(timeSheet.getTimeSheetRow(rowIndex)
				.getProjectName());
	}

	 
	public void selectProjectTask(int rowIndex) {
		// because the task drop is disabled until the project drop down is selected
		// i suspect the waitUntiLoaded is going to have to be doen for the specific
		// task drop down corresponding to row index.
		
		
		int rowIndexToFindTaskList = rowIndex;
		rowIndexToFindTaskList = ++rowIndexToFindTaskList;
		System.out.println("row index" + rowIndex );
		System.out.println("rowIndexToFindTaskList" + rowIndexToFindTaskList );
		String xpath = "//tr[@pl_index='"+rowIndexToFindTaskList+"']//select[@id='TaskDesc']";
		
		//waitUntilLoaded(driver, this.getBy("projectTask"));
		waitUntilLoaded(driver, By.xpath(xpath));
		
		List<WebElement> tasksDropDowns = driver
				.findElements(By.id("TaskDesc"));
		/*
		if(TestConfig.flagSet("verbose")) {			
			for (WebElement o : tasksDropDowns) {
				 System.out.println(o.getAttribute("name")); 
			}			
		}*/
		
		
		
		//TODO address stale element exceptions
		WebElement e = waitAndGetElement(By.xpath(xpath), driver);		
		Select taskSelect = new Select(e);
		//Select taskSelect = new Select(tasksDropDowns.get(rowIndex));
		
		if(TestConfig.flagSet("verbose")) {			
			for (WebElement o : taskSelect.getOptions()) {
				 System.out.println(o.getText()); 
			}			
		}
		
		taskSelect.selectByValue(timeSheet.getTimeSheetRow(rowIndex)
				.getProjectTask());
	}

	
	public void setMonHours(int rowIndex, String hours) {
		WebElement e = getWeekDayTables().get(rowIndex).findElement(By.xpath(".//input[@id='Hours1']"));
		setText(e, hours);
	}
	
	public void setTueHours(int rowIndex, String hours) {
		WebElement e = getWeekDayTables().get(rowIndex).findElement(By.xpath(".//input[@id='Hours2']"));
		setText(e, hours);
	}

	public void setWedHours(int rowIndex, String hours) {
		WebElement e = getWeekDayTables().get(rowIndex).findElement(By.xpath(".//input[@id='Hours3']"));
		setText(e, hours);
	}
	
	public void setThuHours(int rowIndex, String hours) {
		WebElement e = getWeekDayTables().get(rowIndex).findElement(By.xpath(".//input[@id='Hours4']"));
		setText(e, hours);
	}
	
	public void setFriHours(int rowIndex, String hours) {
		WebElement e = getWeekDayTables().get(rowIndex).findElement(By.xpath(".//input[@id='Hours5']"));
		setText(e, hours);
	}
	
	public void setSatHours(int rowIndex, String hours) {
		WebElement e = getWeekDayTables().get(rowIndex).findElement(By.xpath(".//input[@id='Hours6']"));
		setText(e, hours);
	}
	
	public void setSunHours(int rowIndex, String hours) {
		WebElement e = getWeekDayTables().get(rowIndex).findElement(By.xpath(".//input[@id='Hours7']"));
		setText(e, hours);
	}
	
	private List<WebElement> getWeekDayTables()	{
		List<WebElement> hoursTables = driver.findElements(By
				.xpath("//table[@summary='Weekday']"));
		return hoursTables;
	}
	
	public void setHours(int rowIndex) {
				
		setMonHours(rowIndex, timeSheet.getTimeSheetRow(rowIndex).getMonday());
		setTueHours(rowIndex, timeSheet.getTimeSheetRow(rowIndex).getTuesday());
		setWedHours(rowIndex, timeSheet.getTimeSheetRow(rowIndex).getWednesday());
		setThuHours(rowIndex, timeSheet.getTimeSheetRow(rowIndex).getThursday());
		setFriHours(rowIndex, timeSheet.getTimeSheetRow(rowIndex).getFriday());
		setSatHours(rowIndex, timeSheet.getTimeSheetRow(rowIndex).getSaturday());
		setSunHours(rowIndex, timeSheet.getTimeSheetRow(rowIndex).getSunday());				
	}

	public void setSubmitterComments(int rowIndex) {
		// N.B comments1 is 1st ( WELL DONE PEGA everything else starts at 0 !)
		int commentsIndex = rowIndex + 1;
		setText(driver.findElement(By.id("Comments" + commentsIndex)),
				timeSheet.getTimeSheetRow(rowIndex).getSubmitterComments());
	}

	private void switchToFillTimeSheetRowsTabFrame() {
		driver.switchTo().defaultContent();
		//TODO as asdmin will need to swith to a diff tab
		String frameName = "noFrameName";
		if (LoggedInUser.getInstance().getLoggedInUser().getUserType()
				.equals("ADMINISTRATOR")) {
			frameName = Iframes.ADMIN_FILL_TIMESHEET_ROWS_TAB_FRAME_NAME
					.getFrameName();	
		} else 
			frameName = Iframes.FILL_TIMESHEET_ROWS_TAB_FRAME_NAME
					.getFrameName();
								
		waitForFrameAndSwitchToIt(driver,
				frameName);
	}
	
	
	public void submitTimeSheet() {
		switchToFillTimeSheetRowsTabFrame();
		btnSubmit.click();
		driver.switchTo().defaultContent();//why ?
	}

	public void saveDraft() {
		switchToFillTimeSheetRowsTabFrame();
		btnSave.click();
		// TODO do you need to switch ?
	}
	
	public void expandProjectTaskDetailsInfo() {
		PageObject.savePageSource(driver, "WHAT FN PAGE ARE WE ON");	
		PageObject.highlightElement(driver, lnkProjectTaskDetails);
		
		// //div[@class='gridActionBottom']//a[@class='ActionLink']")).click();
		
		List<WebElement> fu =driver.findElements(getBy("lnkProjectTaskDetails"));
		for(WebElement e: fu)
		{			
			System.out.println(e.isEnabled());
		}
		
		//new Actions(driver).moveToElement(lnkProjectTaskDetails).click().build().perform();
		//waitUntilLoaded(driver, this.getBy("lnkProjectTaskDetails"));
		lnkProjectTaskDetails.click();
		
		
		
	}
	

}
