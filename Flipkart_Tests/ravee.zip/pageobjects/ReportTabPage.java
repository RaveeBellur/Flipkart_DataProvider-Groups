package mebank.pageobjects;

import mebank.resources.Iframes;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class ReportTabPage extends PageObject {
    
	// TODO implement
	
    @FindBy(id = "sub")
    private WebElement sub;
    
    private final WebDriver driver;

	
    public ReportTabPage(WebDriver driver){
    	this.driver = driver;
		PageFactory.initElements(driver, this);
    }
    
	@Override
	protected void load() {
		System.out.println(this.getClass().toString() + " load()");						
	}

	@Override
	protected void isLoaded() throws Error {
		System.out.println(this.getClass().toString() + " isLoaded()");					
		String frameName = Iframes.REPORTS_TAB_FRAME_NAME.getFrameName();
		boolean FrameLoaded = isAvailable(driver, By.xpath("//iframe[@id='"+frameName+"']"));
		// TODO a better check page is loaded other than the frame
		if(FrameLoaded) {
			waitForFrameAndSwitchToIt(driver, frameName);							
			String xpath = "//*[contains(text(), 'Report Browser')]";
			isAvailable(driver, By.xpath(xpath));
		}	
	}

   
	
}
