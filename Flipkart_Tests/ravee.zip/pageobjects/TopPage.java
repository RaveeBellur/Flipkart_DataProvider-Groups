package mebank.pageobjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class TopPage extends PageObject {
   
   
    @FindBy(xpath = "//a[@title='Log off']")
    private WebElement logOffLnk;
    
    @FindBy(xpath = "//a[contains(text(), 'Options')]")
    private WebElement optionsLnk;
    
    @FindBy(xpath = "//a[contains(text(), 'New')]")
    private WebElement newLnk;
    
    @FindBy(xpath = "//td[contains(text(), 'Create Timesheet')]")
    private WebElement createTimesheetLnk;
    
    @FindBy(xpath = "//td[contains(text(), 'Bulk Actions')]")
    private WebElement bulkActionsLnk;
    
    
    
    private final WebDriver driver;
	
    public TopPage(WebDriver driver){
    	this.driver = driver;
		PageFactory.initElements(driver, this);
    }
    
	@Override
	protected void load() {
		System.out.println(this.getClass().toString() + " load() and this where we do the driver.get");											
	}

	@Override
	protected void isLoaded() throws Error {
		System.out.println(this.getClass().toString() + " isLoaded()");						
		driver.switchTo().defaultContent();		
		isAvailable(driver, this.getBy("logOffLnk"));
		isAvailable(driver, this.getBy("optionsLnk"));
		isAvailable(driver, this.getBy("newLnk"));
	}
	
	//TODO create my own version of click method that has the wait and get built in
	public void clickOptions() {
		waitAndGetElement(this.getBy("optionsLnk"), driver).click();		
	}
	
	public void clickNew() {
		waitAndGetElement(this.getBy("newLnk"), driver).click();		
	}
	
	public void clickCreateTimesheet() {		
		waitAndGetElement(this.getBy("createTimesheetLnk"), driver).click();
	}
	
	public void clickBulkActions() {
		waitAndGetElement(this.getBy("bulkActionsLnk"), driver).click();		
	}
	
	
	public void logoff(){
		// TODO implement the autoit handle alert here
		// TRY CLOSE ALL TABS OR use autoit.
		
		
		List<WebElement> numberOfOpenTabs=driver.findElements(By.xpath("//tr[@id='tabs']/td/table/tbody/tr/td/span"));
		//List<WebElement> openTabs = driver.findElements(By.cssSelector("table tr > td.coverTabMiddle_on > span.iconCloseSmall"));
		System.out.println("Number of Tabs open: "  + numberOfOpenTabs.size());
		if(numberOfOpenTabs.size() > 0) {
			for (int i = (numberOfOpenTabs.size()-1); i > 0; i--) {
				if(numberOfOpenTabs.get(i).isDisplayed()) {
					numberOfOpenTabs.get(i).click();	
					}
			}				
		}
		logOffLnk.click();
		//driver.navigate().refresh();
	}
}
