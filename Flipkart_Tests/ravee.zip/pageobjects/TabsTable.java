package mebank.pageobjects;

import mebank.resources.User.LoggedInUser;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TabsTable extends PageObject {

	//TODO how will this tab class handle differing order tabs dependent on user role ?
	// TODO inject in the tab text by extracting it from tabs enum
	@FindBy(xpath = "//label[text()='For Approval']")
	private WebElement approveTab;

	@FindBy(xpath = "//label[text()='Create Timesheet']")
	private WebElement createTimeSheetTab;

	@FindBy(xpath = "//label[text()='Data Maintenance']")
	private WebElement dataMaintenanceTab;

	@FindBy(xpath = "//label[text()='Search Timesheet']")
	private WebElement searchTab;

	@FindBy(xpath = "//label[text()='Reports']")
	private WebElement reportsTab;

	@FindBy(xpath = "//label[contains(text(), 'Pending')]") //cos some tard has pending sub...
	private WebElement pendingSubmissionsTab;

	@FindBy(xpath = "//label[text()='Mark To Be Paid']")
	private WebElement markToBePaidTab;

	@FindBy(xpath = "//label[text()='Bulk Actions']")
	private WebElement bulkActionsTab;
	
	@FindBy(xpath = "//label[text()='Work Item']")
	private WebElement workItemTab;
	
	// problem for the administrator the create timesheet tab is the new tab
	// options. 1. request pega dev to set tab title
	// options. 2. think on it ..TODO
	@FindBy(xpath = "//label[text()='New']")
	private WebElement newTab;
	
	
	private final WebDriver driver;

	public TabsTable(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@Override
	protected void load() {
		System.out.println(this.getClass().toString() + " load()");
	}

	@Override
	protected void isLoaded() throws Error {
		System.out.println(this.getClass().toString() + " isLoaded()");
		driver.switchTo().defaultContent();
				
		// if one tab is available all tabs 'should be' available
		if (LoggedInUser.getInstance().getLoggedInUser().getUserType()
				.equals("ADMINISTRATOR")) {
			isAvailable(driver, getBy("approveTab"));
		} else {
			isAvailable(driver, getBy("createTimeSheetTab")); // for all users other than administrator			 
		}
		
		
	}

	public void clickWorkItemTab() {
		workItemTab.click();
	}
	
	public void clickbulkActionsTab() {
		bulkActionsTab.click();
	}
	
	public void clickPendingSubmissionsTab() {
		pendingSubmissionsTab.click();
	}

	public void clickMarkToBePaidTab() {
		markToBePaidTab.click();
	}

	public void clickApproveTab() {
		approveTab.click();
	}

	public void clickCreateTimeSheetTab() {
		createTimeSheetTab.click();
	}

	public void clickDataMaintenanceTab() {
		dataMaintenanceTab.click();		
	}

	public void clickSearchTab() {
		searchTab.click();
	}

	public void clickReportsTab() {
		reportsTab.click();
	}
	
	public void clickNewTab() {
		newTab.click();
	}

}
