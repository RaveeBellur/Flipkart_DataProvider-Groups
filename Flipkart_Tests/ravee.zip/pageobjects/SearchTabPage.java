package mebank.pageobjects;

import java.util.List;

import mebank.dataobjects.TimeSheet;
import mebank.resources.Iframes;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SearchTabPage extends PageObject {

	@FindBy(xpath = "//div[@class='pzbtn-mid']")
	private WebElement btnSearch;

	@FindBy(id = "sub")
	private WebElement sub;

	@FindBy(xpath = "//input[@id='EmployeeName']")
	private WebElement empNameTxtField;

	@FindBy(id = "CaseID")
	private WebElement caseID;

	private final WebDriver driver;
	
	public SearchTabPage(WebDriver driver, TimeSheet timeSheet) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public SearchTabPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@Override
	protected void load() {
		System.out.println(this.getClass().toString() + " load()");

	}

	protected void isLoaded() throws Error {
		System.out.println(this.getClass().toString() + " isLoaded()");

		TabsTable t = (TabsTable) new TabsTable(driver).get();
		t.clickSearchTab();

		String frameName = Iframes.SEARCH_TAB_FRAME_NAME.getFrameName();
		boolean FrameLoaded = isAvailable(driver,
				By.xpath("//iframe[@id='" + frameName + "']"));
		if (FrameLoaded) {
			waitForFrameAndSwitchToIt(driver, frameName);
			String xpath = "//*[contains(text(), 'Search Results')]";
			isAvailable(driver, By.xpath(xpath));
		}
	}

	public void clickSearch() {
		waitAndGetElement(this.getBy("btnSearch"), driver).click();		
	}
	
	
	public TimeSheet getPendingSubmissionTimeSheetFromTable() {
		return getPendingPaymentTimeSheetFromTable("Pending-Submission");
	}
	
	public TimeSheet getPendingFullPaymentTimeSheetFromTable() {
		return getPendingPaymentTimeSheetFromTable("Pending-FullPayment");
	}

	public TimeSheet getPendingPartialPaymentTimeSheetFromTable() {
		return getPendingPaymentTimeSheetFromTable("Pending-PartialPayment");
	}
	
	public TimeSheet getResolvedCompletedTimeSheetFromTable() {
		return getPendingPaymentTimeSheetFromTable("Resolved-Completed");
	}
	
	public TimeSheet getResolvedWithdrawnTimeSheetFromTable() {
		return getPendingPaymentTimeSheetFromTable("Resolved-Withdrawn");
	}

	private List<WebElement> getAllCaseIDsToBePaid() {
		List<WebElement> tsSearchTableRows = driver.findElements(By
				.xpath("//table[@id='bodyTbl_right']/tbody/tr"));
		return tsSearchTableRows;
	}

	private TimeSheet getPendingPaymentTimeSheetFromTable(String tsStatusToSearch) {
		btnSearch.click();
		TimeSheet ts = new TimeSheet();
		outer: do { // do-while traverses multiple search result pages to find
					// the record
			sleep(5000); // wait for the table data to load. using sleep as
							// could not find any other condition to wait for
			// TODO create a private function that getsAllRowsOnPage
			List<WebElement> tsSearchTableRows = getAllCaseIDsToBePaid();
			if (tsSearchTableRows.size() == 1) {
				System.out.println("There are no time sheets in the system ");
			} else if (tsSearchTableRows.size() > 1) {
				for (int i_RowNum = 1; i_RowNum < tsSearchTableRows.size(); i_RowNum++) {
					List<WebElement> tsSearchTableCol = tsSearchTableRows.get(i_RowNum).findElements(By.xpath("td"));
					if (tsSearchTableCol.get(6).getText().equals("No Task Pending")) { // hard coded index to avoid searching all columns. [6]- caseStatus
						ts.setEmployeeName(tsSearchTableCol.get(1).getText());
						ts.setWeekEnding(tsSearchTableCol.get(4).getText());
						ts.setCaseID(tsSearchTableCol.get(7).getText());
						break outer;
					}
				}
			}
		} while ((driver.findElements(By.xpath("//a[@title='Next Page']"))
				.size() > 0) && clickNextSearchResultPage());

		if (ts.getCaseID() == null) {
			// System.out.println(" << There are no time sheets in the system with pending full payment status >> ");
			Assert.assertTrue(
					" << There are no time sheets in the system with pending full payment status >> ",
					false);
		}
		return ts;
	}

	public boolean clickNextSearchResultPage() {
		// if the next page link is available AND enabled click it
		// TODO revisit this
		try {
			driver.findElement(By.xpath("//a[@title='Next Page']")).click();
			return true;
		} catch (Exception e) {
			e.toString();
			return false;
		}
	}

	public void searchByCaseID(TimeSheet ts) {
		waitAndGetElement(this.getBy("caseID"), driver)
				.sendKeys(ts.getCaseID());
		btnSearch.click();
	}

	public String getTimeSheetStatus(TimeSheet ts) {
		// assumption we have done a search and there is only 1 row so this
		// xpath matches only once
		sleep(3000); //TODO see if can get round this sleep
		List<WebElement> tsSearchTableRows = driver.findElements(By
				.xpath("//table[@id='bodyTbl_right']/tbody/tr"));
		List<WebElement> tsSearchTableCol = tsSearchTableRows.get(1)
				.findElements(By.xpath("td"));
		String status = tsSearchTableCol.get(6).getText().trim();
		System.out.println("timesheet status on search page " + status);
		return status;
	}
	
	public void openTimeSheet(TimeSheet ts) {
		// assumption we have done a search and there is only 1 row so this
		// xpath matches only once
		sleep(3000); //TODO see if can get round this sleep
		List<WebElement> tsSearchTableRows = driver.findElements(By
				.xpath("//table[@id='bodyTbl_right']/tbody/tr"));
		List<WebElement> tsSearchTableCol = tsSearchTableRows.get(1)
				.findElements(By.xpath("td"));
		tsSearchTableCol.get(6).click();
		// launches new window PEGA YOU POS
		
		
	}

}
