package mebank.pageobjects;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import mebank.resources.Utilities;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.pagefactory.Annotations;
//import org.openqa.selenium.internal.seleniumemulation.GetAlert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;

public abstract class PageObject extends LoadableComponent<PageObject> {

	

	

	public void waitForFrameAndSwitchToIt(WebDriver driver, String frameName) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions
				.frameToBeAvailableAndSwitchToIt(frameName));
		System.out.println("switched into frame "+frameName);
	}
	
	public void waitForFrameAndSwitchToIt(WebDriver driver, By selector) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions
				.frameToBeAvailableAndSwitchToIt(selector));
		System.out.println("switched into frame "+selector.toString());
	}



	// TODO need a configurable timeout as 30 seconds might be too slow
	public void waitForElement(final By locator, WebDriver driver) {
		new FluentWait<WebDriver>(driver).withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(3, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class)
				.until(new Function<WebDriver, WebElement>() {
					public WebElement apply(WebDriver driver) {
						return driver.findElement(locator);
					}
				});
	}

	public void waitUntilLoaded(WebDriver driver, By locator) {
		WebDriverWait wait = new WebDriverWait(driver, 30);

		try {
			wait.until(ExpectedConditions.elementToBeClickable(locator));
		} catch (TimeoutException toe) {
			System.out.println(locator.toString());
		}
	}

	public WebElement waitAndGetElement(final By locator, WebDriver driver) {
		waitForElement(locator, driver);
		return driver.findElement(locator);
	}

	public WebDriver switchToChildWindow(WebDriver driver) {
		String parentWindow = driver.getWindowHandle();// active or current
														// window
		Set<String> handles = driver.getWindowHandles(); // any other window
															// other than
															// active. this is
															// only seeing1
															// window in IE.

		/*
		 * for(int i=0; i < 3; i++) { Set<String>
		 * availableWindows=driver.getWindowHandles();
		 * System.out.println("how many windows?" +
		 * Integer.toString(availableWindows.size()));
		 * if(availableWindows.size()==2) break; System.out.println("sleeping");
		 * sleep(5000); }
		 */

		int i = 0;
		for (String windowHandle : handles) {
			i = i + 1;
			System.out.println("i" + Integer.toString(i));
			if (!windowHandle.equals(parentWindow)) {

				driver = driver.switchTo().window(windowHandle);
				System.out.println(driver.getTitle());

				// driver.close(); //closing child window
				// driver.switchTo().window(parentWindow); //cntrl to parent
				// window
			}
		}
		return driver;
	}

	public static boolean isElementPresent(WebDriver driver, By by) {
		if(by == null)
			System.out.println("by is null - null pointer exception coming ");
		try {
			driver.findElement(by);
			return true; // Success!
		} catch (NoSuchElementException ignored) {
			return false;
		}
		//catch (NullPointerException ignored) {
		//		return false;
		//}
	}

	public final static int FIFTEEN_SECONDS = 15000;

	// USE THIS to shorten the the isLoaded ( how long do those assertions take
	// ? )
	public static boolean isAvailable(WebDriver driver, By selector)
			throws Error {
		return isAvailable(driver, FIFTEEN_SECONDS, selector);
	}

	public static boolean isAvailable(WebDriver driver, int timeout, By selector)
			throws Error {
		System.out.println("isAvailable ");
		
		long startTime = System.currentTimeMillis();
		Long failAt = System.currentTimeMillis() + timeout;
		boolean available = false;
		Outer: do {
			if (isElementPresent(driver, selector)) {
				available = true;
				break Outer;
			}
		} while (System.currentTimeMillis() < failAt);

		if (available) {
			long stopTime = System.currentTimeMillis();
			long elapsedTime = stopTime - startTime;
			System.out.println("whenAvailable " + selector.toString()
					+ "time to run method" + elapsedTime);
			return available;
		}
		System.out.println("Could not find element " + selector + " after "
				+ timeout / 1000 + " seconds");
		throw new junit.framework.AssertionFailedError(
				"Could not find element " + selector + " after " + timeout
						/ 1000 + " seconds");
	}


	
	
	// for testing max character
	public void setTextAndDoNotValidateTextSetCorrectly(WebElement element, String text) {
		element.clear();			
		if (text != null && !text.isEmpty()) {
			if (text.length() > 50) {
				Utilities.setClipboard(text);
				element.sendKeys(Keys.CONTROL + "v");
			} else {
				element.sendKeys(text);
			}
		}
	}
	
	// for testing max character
	public void setTextUsingCopyPasteAndDoNotValidateTextSetCorrectly(WebElement element, String text) {
		element.clear();			
		if (text != null && !text.isEmpty()) {
			Utilities.setClipboard(text);
			element.sendKeys(Keys.CONTROL + "v");

			
		}
	}
	
	
	public void setText(WebElement element, String text) {
		Long failAt = System.currentTimeMillis() + Integer.parseInt("20000");
		int sleepTime = 500;
		if (text.length() > 25)
			sleepTime = sleepTime * 8;

		boolean textTypedOk;
		do {
			element.clear();
			if (text != null && !text.isEmpty()) {
				if (text.length() > 50) {
					Utilities.setClipboard(text);
					element.sendKeys(Keys.CONTROL + "v");
				} else {
					element.sendKeys(text);
				}
			}
			sleep(sleepTime);
			System.out.println("[" + text + "] ["
					+ element.getAttribute("value") + "]");
			textTypedOk = element.getAttribute("value").contains(text);			
			if (!textTypedOk)
				sleep(sleepTime);
			System.out.println("textTypedOk" + Boolean.toString(textTypedOk));
		} while (!textTypedOk && System.currentTimeMillis() < failAt);
	}

	public static void highlightElement(WebDriver driver, WebElement element) {
		for (int i = 0; i < 2; i++) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript(
					"arguments[0].setAttribute('style', arguments[1]);",
					element, "color: yellow; border: 2px solid yellow;");
			js.executeScript(
					"arguments[0].setAttribute('style', arguments[1]);",
					element, "");
		}
	}

	public static void sleep(int sleepTime) {
		try {
			Thread.sleep(sleepTime);
		} catch (InterruptedException exception) {
			exception.printStackTrace();
		}
	}

	// TODO. this is not working when switch into frame ?
	public static void savePageSource(WebDriver driver, String filename) {
		// TODO if file

		File file = new File("C:\\workspace\\timesheetapp\\" + filename
				+ ".html");
		FileWriter writer;
		PrintWriter printer = null;
		try {
			writer = new FileWriter(file, true);
			// writer = new FileWriter(file);
			printer = new PrintWriter(writer);
			printer.append(driver.getPageSource());
			printer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (printer != null)
				printer.close();
		}
	}

	public static void listAllElementsOnPage(WebDriver driver) {
		List<WebElement> e = driver.findElements(By.xpath("//*"));
		for (WebElement el : e) {
			System.out.println(el.getTagName());
		}

	}

	public static void listAllElementsOnPage(WebDriver driver, By locator) {
		List<WebElement> e = driver.findElements(locator);
		for (WebElement el : e) {
			System.out.println(el.getTagName());
			System.out.println(el.getAttribute("longdesc"));
		}

	}

	public void setCheckbox(WebElement checkBox, boolean checkRequired) {
		System.out.println("is the checkbox selected ? "
				+ Boolean.toString(checkBox.isSelected()));
		// if true and not selected then select ( check )
		// if false and selected then select ( i.e. uncheck )
		if ((checkRequired && !checkBox.isSelected())
				|| (!checkRequired && checkBox.isSelected())) {
			checkBox.click();
		}
	}

	public By getBy(String fieldName) {
		try {
			return new Annotations(this.getClass().getDeclaredField(fieldName))
					.buildBy();
		} catch (NoSuchFieldException e) {
			return null;
		}
	}
	
	
	//TODO move this to UTILITIES or PageObject
		public  void clickOkOnConfirm(WebDriver driver)
		{		
						
			Alert alert = switchToAlert(driver); // this should take care of checking for the null	
			if(alert == null)
				Assert.assertTrue("click on confirm alert was null", false);	
			if(alert.getText() == null)
				Assert.assertTrue("confirm alert was present but the dialog did not display any text", false);	
			System.out.println(alert.getText());		
			alert.accept();		
		}
		
		
		public  Alert switchToAlert(WebDriver driver)
		{
			Long failAt = System.currentTimeMillis() + Integer.parseInt("10000");
			do
		    {
				try
			    {
					sleep(1000);
					System.out.println("trying to switch to alert");
					return driver.switchTo().alert();	        
			    }
			    catch (org.openqa.selenium.NoAlertPresentException exception)
			    {
			    	System.out.println("no alert present exception?");
			    	System.out.println(exception.getMessage());
			    	// We ignore this execption, as it means there is no alert present...yet.
			        return null;
			    }
				// TODO do we need to catch a null ?
			    // Other exceptions will be ignored and up the stack
		    }while( System.currentTimeMillis() < failAt);
		}


}