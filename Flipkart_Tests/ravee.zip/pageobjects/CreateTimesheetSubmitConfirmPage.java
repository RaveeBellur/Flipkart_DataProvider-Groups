package mebank.pageobjects;

import mebank.dataobjects.TimeSheet;
import mebank.resources.Iframes;
import mebank.resources.User.LoggedInUser;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CreateTimesheetSubmitConfirmPage extends PageObject {
	
	@FindBy(id = "ProjectName")
	 private WebElement projectName;
	
	
	private final WebDriver driver;
	
	public CreateTimesheetSubmitConfirmPage(WebDriver driver){
    	this.driver = driver;
		PageFactory.initElements(driver, this);
    }

	@Override
	protected void load() {
		System.out.println("start" + this.getClass().getName() + "load()");		
		
	}

	@Override
	protected void isLoaded() throws Error {
		System.out.println(this.getClass().toString() + " isLoaded()");	
		
		TabsTable t = (TabsTable) new TabsTable(driver).get();
		
		// problem. as the admin the frame id of the create tab is not 0
		// also the title of the tab is new. 
		// so unless pega devs change tab title cannot use the tab title to find the tab index.
		// new might be another tab other than create
		// so for check if admin and if so assume frameName is 6.
		String frameName = "noFrameName";
		if (LoggedInUser.getInstance().getLoggedInUser().getUserType()
				.equals("ADMINISTRATOR")) {
			frameName = Iframes.ADMIN_FILL_TIMESHEET_CONFIRMATION_TAB_FRAME_NAME
					.getFrameName();	
		} else 
			frameName = Iframes.FILL_TIMESHEET_CONFIRMATION_TAB_FRAME_NAME
			.getFrameName();

		boolean frameLoaded = isAvailable(driver,
				By.xpath("//iframe[@id='" + frameName + "']"));
		if (frameLoaded) {
			waitForFrameAndSwitchToIt(driver, frameName);
			String xpath = "//span[contains(text(), 'Case Contents')]";
			isAvailable(driver, By.xpath(xpath));
			PageObject.savePageSource(driver, "confirmation page");
		}
	}
	
	
	public TimeSheet submissionConfirmationAndCaptureTsID(TimeSheet timesheet) {
		String xpath;
		xpath = "//td//label[contains(text(),'Case ID')]/..//following-sibling::td[1]";
		
		Assert.assertTrue(PageObject.isAvailable(driver, By.xpath("//td//label[contains(text(),'Case ID')]")));
		
		//String caseID=driver.findElement(By.xpath("//tr[@id='tabs']/td[1]")).findElement(By.xpath("//label[contains(text(),'T-')]")).getText();
		String caseID = driver.findElement(By.xpath(xpath)).getText();
		
		System.out.println("Timesheet ID is: [" +caseID + "]");
		timesheet.setCaseID(caseID);
		xpath = "//td[@class='custom_WorkConfirmNote']//label[contains(text(), 'Thank you for your input.')]";
				
		Assert.assertTrue(PageObject.isAvailable(driver, By.xpath(xpath)));
		
		// TODO:
		// if admin the timesheet is set to pending full payment ( if submitter is a contractor )
		
		
		// confirm status is pending approval
		// confirm based on ts info submitted there is a row for each project 
		return timesheet;
	}
	
	public void closeTab() { // this implicity switches to top most frame
		TabsTable t = (TabsTable) new TabsTable(driver).get();
		PageObject.savePageSource(driver, "closeTab");
		//String xpath = "//td[contains(text(), 'Timesheets')]//span[@id='close']";
		// tab5 in prod but tab6 in dev
		String xpath = "//td[@id='tab6']//span[@id='close']"; //TODO fix this up so not using hardcoded tab
		
		waitAndGetElement(By.xpath(xpath), driver).click();
	}
	
}
