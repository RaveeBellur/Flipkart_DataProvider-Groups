package mebank.pageobjects;

import mebank.dataobjects.TimeSheet;
import mebank.resources.Iframes;
import mebank.resources.User.LoggedInUser;

import org.openqa.selenium.By;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class CreateTimesheetTabPage extends PageObject {

	//@FindBy(name = "$PpyDisplayHarness$pEndDate")
	@FindBy(id = "EndDate")
	private WebElement dateDropdown;
	
	
	@FindBy(xpath = "//div[@class='pzbtn-mid']")
	private WebElement btnCreate;

	// TODO this is for admin only. consider splitting out a 2nd version of this pageobject for admin only.
	@FindBy(name = "$PpyWorkPage$pSubmitter$pMEID")
	private WebElement meIdTxt;
	
	
	private final WebDriver driver;
	TimeSheet timeSheet;

	public CreateTimesheetTabPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public CreateTimesheetTabPage(WebDriver driver, TimeSheet timeSheet) {
		this.driver = driver;
		this.timeSheet = timeSheet;
		PageFactory.initElements(driver, this);
	}

	@Override
	protected void load() {
		System.out.println(this.getClass().toString() + " load()");
	}

	@Override
	protected void isLoaded() throws Error {
		System.out.println(this.getClass().toString() + " isLoaded()");
		
		//click the tab if on the the tab by default or not ( i.e. simplify the code )
		TabsTable t = (TabsTable) new TabsTable(driver).get();
		
		
		// problem. as the admin the frame id of the create tab is not 0
		// also the title of the tab is new. 
		// so unless pega devs change tab title cannot use the tab title to find the tab index.
		// new might be another tab other than create
		// so for check if admin and if so assume frameName is 6.
		String frameName = "noFrameName";
		if (LoggedInUser.getInstance().getLoggedInUser().getUserType()
				.equals("ADMINISTRATOR")) {
			t.clickNewTab();
			frameName = Iframes.ADMIN_CREATE_TIMESHEET_TAB_WEEKENDING_DATE_SELECTOR_FRAME_NAME
					.getFrameName();	
		} else {
			t.clickCreateTimeSheetTab();
			frameName = Iframes.CREATE_TIMESHEET_TAB_WEEKENDING_DATE_SELECTOR_FRAME_NAME
					.getFrameName();
		}		
		
		boolean frameLoaded = isAvailable(driver,
				By.xpath("//iframe[@id='" + frameName + "']"));
		if (frameLoaded) {
			waitForFrameAndSwitchToIt(driver, frameName);
			String xpath = "//div[@class='pzbtn-mid']"; // check for create button
			isAvailable(driver, By.xpath(xpath));
		}

	}

	
	/*
	 * N.B week ending date must be set on t/s obj before calling selectWeekEnding() 
	 */		
	public void selectWeekEnding() {		
		boolean dateDropDown = isAvailable(driver, By.id("EndDate")); 
														
		/*												
		boolean dateDropDown = isAvailable(driver,
				By.name("$PpyDisplayHarness$pEndDate")); // check for date drop
															// down being
															// available*/
		// N.B select by value relies on date being in yyyymmdd format
		if (dateDropDown) {
			Select select = new Select(dateDropdown);			
			select.selectByValue(timeSheet.getWeekEnding());
		}
	}

	public void clickCreateTimeSheetButton(WebDriver driver) {
		sleep(5000); //TODO replace with wait until ready 
		btnCreate.click(); 		
	}
	
		
	public void setMeIdTxt(String meIdTxt) {
		setTextUsingCopyPasteAndDoNotValidateTextSetCorrectly(this.meIdTxt, meIdTxt);
		//setText(this.meIdTxt, meIdTxt);
		//this.meIdTxt.sendKeys(meIdTxt);
		// shift focus away from meIdTxt as the drop down auto complete list seems to get in front of the week ending drop down
		String xpath = "//td[@class='dataLabelWrite']";
		driver.findElement(By.xpath(xpath)).click(); // click some label 
	}
	
	public void closeTab() {
		TabsTable t = (TabsTable) new TabsTable(driver).get(); // this implicity switches to top most frame
		PageObject.savePageSource(driver, "closeTab");
		//String xpath = "//td[contains(text(), 'Timesheets')]//span[@id='close']";
		String xpath = "//td[@id='tab6']//span[@id='close']"; //TODO fix this up so not using hardcoded tab
		
		waitAndGetElement(By.xpath(xpath), driver).click();
		clickOkOnConfirm(driver); // this is on the ok cancel dialog
		sleep(1500);
		//TODO come up with a better solution to handle are you sure want to leave hotel california..
		try {
			driver.navigate().refresh();// will this clear that bs dialog ? no it won't due to unhandled alert..
		} catch (UnhandledAlertException e) {
			// TODO Auto-generated catch block // so lets just catch this schiesen for now
			e.printStackTrace();
		}				
	}
		
}
