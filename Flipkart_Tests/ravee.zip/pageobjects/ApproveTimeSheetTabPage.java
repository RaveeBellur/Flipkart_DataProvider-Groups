package mebank.pageobjects;

import mebank.resources.Iframes;
import mebank.resources.User.LoggedInUser;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ApproveTimeSheetTabPage extends PageObject {

	@FindBy(xpath = "//input[@id='ApproveAll']")
	private WebElement approveAll;
	@FindBy(id = "button1")
	private WebElement btnSubmit;

	private final WebDriver driver;

	public ApproveTimeSheetTabPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@Override
	protected void load() {
		System.out.println(this.getClass().toString() + " load()");
	}

	@Override
	protected void isLoaded() throws Error {
		System.out.println(this.getClass().toString() + " isLoaded()");
		// the frameName depends on if internal or external pm

		//click the tab if on the the tab by default or not ( i.e. simplify the code )
		TabsTable t = (TabsTable) new TabsTable(driver).get();
		t.clickApproveTab();
		
		String frameName = "noFrameName";
		if (LoggedInUser.getInstance().getLoggedInUser().getUserType()
				.equals("EXTERNAL_PROJECT_MANAGER")) {
			frameName = Iframes.SELECT_EXTERNAL_APPROVE_TAB_FRAME_NAME
					.getFrameName();	
		} else if (LoggedInUser.getInstance().getLoggedInUser().getUserType()
				.equals("INTERNAL_PROJECT_MANAGER"))
			frameName = Iframes.SELECT_INTERNAL_APPROVE_TAB_FRAME_NAME
					.getFrameName();
		// Check who is logged in and switch to the right frame
		boolean FrameLoaded = isAvailable(driver,
				By.xpath("//iframe[@id='" + frameName + "']"));
		// TODO a better check page is loaded other than the frame
		if (FrameLoaded) {
			waitForFrameAndSwitchToIt(driver, frameName);
			String xpath = "//*[contains(text(), 'Items awaiting your approval')]";
			isAvailable(driver, By.xpath(xpath));
		}

	}

	public void approveAllTimeSheets() {
		/*
		 * System.out.println(" AM empTyppeeee: "+
		 * LoggedInUser.getInstance().getLoggedInUser().getUserType());
		 * System.out.println("Am userTypeee : "+
		 * User.values().get(3).getUserType());
		 */
		approveAll.click();
		submitAndSwtichToDefaultFrame();
	}

	public void approveSpecificTimeSheets() {
		// TO DO - select and approve specific ts and submit

	}

	// RAVEE TODO can we start to get rid of these if we use tabs to switch to another page it will 
	// switch to default automatically
	public void submitAndSwtichToDefaultFrame() {
		btnSubmit.click();
		driver.switchTo().defaultContent();
	}
}
