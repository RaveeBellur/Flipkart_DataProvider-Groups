package mebank.pageobjects;

import mebank.dataobjects.Employee;
import mebank.resources.User.LoggedInUser;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class LoginPage extends PageObject {
    @FindBy(id = "txtUserID")
    private WebElement txtUserID;
    @FindBy(id = "txtPassword")
    private WebElement txtPassword;
    @FindBy(id = "sub")
    private WebElement sub;
          
    private final WebDriver driver;
    
	
    public LoginPage(WebDriver driver){
    	this.driver = driver;
		PageFactory.initElements(driver, this);
    }
    
	@Override
	protected void load() {		
		System.out.println("start" + this.getClass().getName() + "load()");													
	}

	@Override
	protected void isLoaded() throws Error {		
		System.out.println(this.getClass().toString() + " isLoaded()");		
		isAvailable(driver, By.id("txtUserID"));						
	}

		
	public void login(Employee e) {    
		System.out.println("LOGIN AS" + e.getFullName() + " " + e.getUserType());
    	txtUserID.sendKeys(e.getMeID());
    	txtPassword.sendKeys(e.getPassword());
    	sub.click();		
    	//TODO assert you have logged in correctly
    	LoggedInUser.getInstance().setLoggedInUser(e);
	}
	
   	
    public WebElement getTxtUserID() {
		return txtUserID;
	}

	public void setTxtUserID(WebElement txtUserID) {
		this.txtUserID = txtUserID;
	}
	
	

}
