package mebank.pageobjects.admin;

import mebank.dataobjects.Task;
import mebank.pageobjects.PageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TaskAddPage extends PageObject {

	@FindBy(id = "TaskCode")
	private WebElement taskCode;

	@FindBy(id = "TaskName")
	private WebElement taskName;

	@FindBy(id = "Description")
	private WebElement description;

	@FindBy(xpath = ".//button[contains(text(), 'Cancel')]")
	private WebElement btnCancel;

	@FindBy(xpath = ".//button[contains(text(), 'Save')]")
	private WebElement btnSave;

	@FindBy(xpath = ".//button[contains(text(), 'Back')]")
	private WebElement btnBack;

	private final WebDriver driver;
	

	@Override
	protected void load() {
		System.out.println("start" + this.getClass().getName() + "load()");		
	}

	@Override
	protected void isLoaded() throws Error {		
		isAvailable(driver, 30000, this.getBy("taskCode"));		
	}

	
	public void submit() {
		save();
		// this.submitAndWait(btnSave, driver);
	}

	public TaskAddPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	public void setAndSubmit(Task task) {
		this.set(task);
		this.submit();
	}

	public void set(Task task) {
		this.setTaskCode(task.getTaskCode());
		this.setTaskName(task.getTaskName());
		this.setDescription(task.getDescription());
	}

	public void save() {
		this.btnSave.click();
	}

	public void setTaskCode(String taskCode) {
		setText(this.taskCode, taskCode);
	}

	public void setTaskName(String taskName) {
		setText(this.taskName, taskName);
	}

	public void setDescription(String description) {
		setText(this.description, description);
	}

	public TaskListPage goBackToTaskListPage() {
		waitAndGetElement(this.getBy("btnBack"), driver).click();
		switchBackToTaskListPage();
		return new TaskListPage(driver);
	}

	private void switchBackToTaskListPage() {
		driver.switchTo().defaultContent(); 
	}

}
