package mebank.pageobjects.admin;

import mebank.pageobjects.PageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ContractorReviewPage extends PageObject {

	@FindBy(xpath = "//td[contains(text(), 'Employee First Name')]/following-sibling::td")
	private WebElement firstName;

	@FindBy(xpath = "//td[contains(text(), 'Employee Last Name')]/following-sibling::td")
	private WebElement lastName;

	@FindBy(xpath = "//td[contains(text(), 'Employee Full Name')]/following-sibling::td")
	private WebElement fullName;

	@FindBy(xpath = "//td[contains(text(), 'ID')]/following-sibling::td")
	private WebElement MeID;

	@FindBy(xpath = "//td[contains(text(), 'Employee Type')]/following-sibling::td")
	private WebElement empType;

	@FindBy(xpath = "//td[contains(text(), 'Vendor')]/following-sibling::td")
	private WebElement vendor;

	@FindBy(xpath = "//td[contains(text(), 'Email')]/following-sibling::td")
	private WebElement email;

	@FindBy(xpath = "//td[contains(text(), 'Line Manager ID')]/following-sibling::td")
	private WebElement lineManagerID;

	@FindBy(xpath = "//td[contains(text(), 'Line Manager Name')]/following-sibling::td")
	private WebElement lineManagerName;

	@FindBy(xpath = "//td[contains(text(), 'Line Manager Email')]/following-sibling::td")
	private WebElement lineManagerEmail;

	@FindBy(xpath = "//td[contains(text(), 'Fill Timesheet')]/following-sibling::td")
	private WebElement timeSheetRequired;

	@FindBy(xpath = ".//button[contains(text(), 'Back')]")
	private WebElement btnBack;

	private final WebDriver driver;

	// ok so ui.loadableComponent.get calls this ( i.e. selenium out of the box
	// )
	@Override
	protected void load() {
		System.out.println("start" + this.getClass().getName() + "load()");
	}

	@Override
	protected void isLoaded() throws Error {
		isAvailable(driver, this.getBy("btnBack"));
	}

	public ContractorListPage goBackToEmployeeListPage() {
		waitAndGetElement(this.getBy("btnBack"), driver).click();
		switchBackToConstractorListPage();
		return new ContractorListPage(driver);
	}

	public void switchBackToConstractorListPage() {
		driver.switchTo().defaultContent();
	}

	public ContractorReviewPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public WebElement getLastName() {
		return lastName;
	}

	public WebElement getFullName() {
		return fullName;
	}

	public WebElement getMeID() {
		return MeID;
	}

	public WebElement getEmpType() {
		return empType;
	}

	public WebElement getVendor() {
		return vendor;
	}

	public WebElement getEmail() {
		return email;
	}

	public WebElement getLineManagerID() {
		return lineManagerID;
	}

	public WebElement getLineManagerName() {
		return lineManagerName;
	}

	public WebElement getLineManagerEmail() {
		return lineManagerEmail;
	}

	public WebElement getTimeSheetRequired() {
		return timeSheetRequired;
	}

}
