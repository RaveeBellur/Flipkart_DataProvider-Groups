package mebank.pageobjects.admin;

import java.util.ArrayList;
import java.util.List;

import mebank.pageobjects.PageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TaskListPage extends PageObject {
	@FindBy(id = "AppendItemButton")
	private WebElement btnAppendNew;

	@FindBy(id = "OpenEditItemButton")
	private WebElement btnEdit;

	@FindBy(xpath = "//input[@type='text']")
	// input[@type='text']
	private WebElement txtSearchBy;

	@FindBy(xpath = "//button[@title='Run']")
	private WebElement btnRunSearch;

	private final WebDriver driver;

	@Override
	protected void load() {
		System.out.println(this.getClass().toString() + " load()");
		switchToChildWindow(driver);
	}

	@Override
	protected void isLoaded() throws Error {
		isAvailable(
				driver,
				By.xpath(".//*[contains(text(), '"
						+ ProjectMaintenancePage.getTASK_DETAILS() + "')]"));
		isAvailable(driver, By.id("AppendItemButton"));
		driver.manage().window().maximize();
	}

	public void submit() {
		// this.submitAndWait(submit, driver);
	}

	public TaskListPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	public void searchByTaskCode(String taskCode) {
		setSearchField(taskCode);
		btnRunSearch.click();
	}

	private void setSearchField(String searchFor) {
		txtSearchBy.clear();
		txtSearchBy.sendKeys(searchFor);
	}

	public void appendNewTask() {
		waitAndGetElement(getBy("btnAppendNew"), driver).click();
	}

	public List<String> getAllProjectCodesOnPage() {
		List<WebElement> projectCodeElements = this.driver.findElements(By
				.xpath(".//*[@id='ViewTable']/tbody//child::td[position()=1]"));
		List<String> projectCodeText = new ArrayList<String>();

		for (WebElement we : projectCodeElements) {
			System.out.println(we.getText());
			projectCodeText.add(we.getText());
		}
		return projectCodeText;
	}

	public String findTaskCodeByName(String name) {

		String xpath = "//td[contains(text(), 'mojojojo')]/..//following-sibling::td[1]//button[@title='Open this item']";
		System.out.println(driver.findElement(By.xpath(xpath)).getTagName());
		System.out.println(driver.findElement(By.xpath(xpath)).getAttribute(
				"title"));

		WebElement tableRow = driver.findElement(By
				.xpath("//td[contains(text(), '" + name + "')]/parent::tr"));
		List<WebElement> tableCells = tableRow.findElements(By.xpath("td"));
		String projectCode = tableCells.get(0).getText();
		System.out.println("project code" + projectCode);

		// FFFFFFF YOU - ok so with screen maximised the vertical scroll bar is
		// not right at the top
		// so webdriver locates the element on screen using xpath (x,y) and
		// attempt to click on (x,y)
		// and due to scroll position clicks on column header
		// right so to get round this scroll issue extract the project code and
		// search using this

		return projectCode;
	}

	// FOR now open using xpath the 1st item assuming have search and narrowed
	// it down to one
	public void openTask() {
		String xpath = "//table[@id='ViewTable']//button[@title='Open this item']";
		waitAndGetElement(By.xpath(xpath), driver).click();
	}

}
