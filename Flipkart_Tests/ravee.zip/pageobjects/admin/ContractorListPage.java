package mebank.pageobjects.admin;

import java.util.List;

import mebank.pageobjects.PageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ContractorListPage extends PageObject {
	@FindBy(id = "AppendItemButton")
	private WebElement btnAppendNew;

	@FindBy(id = "OpenEditItemButton")
	private WebElement btnEdit;

	@FindBy(xpath = "//input[@type='text']")
	// input[@type='text']
	private WebElement txtSearchBy;

	@FindBy(xpath = "//button[@title='Run']")
	private WebElement btnRunSearch;

	private final WebDriver driver;

	@Override
	protected void load() {
		System.out.println("start" + this.getClass().getName() + "load()");		
		switchToChildWindow(driver);
	}

	@Override
	protected void isLoaded() throws Error {
		// Assert.assertTrue(isElementPresent(driver, By.id("AppendItemTD")));
		isAvailable(
				driver,
				By.xpath(".//*[contains(text(), '"
						+ ProjectMaintenancePage.getEMPLOYEE_LIST() + "')]"));
		isAvailable(driver, By.id("AppendItemButton"));
		driver.manage().window().maximize();
	}

	
	public ContractorListPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	public void appendNewContractor() {
		btnAppendNew.click();
	}

	// TODO consider refactor this to a helper class ( or insert it before
	// pageobject in the inheritance heirarchy )
	/*
	public void searchFor(String searchByText) {
		setText(txtSearchBy, searchByText);		
		btnRunSearch.click();
	}*/

	

	public void searchByMeID(String MeID) {
		setText(txtSearchBy, MeID.substring(0, 7)); // legit MeID is 8 chars 
		btnRunSearch.click();
	}

	public String findEmployeeMeIDEmail(String email) {

		String xpath = "//td[contains(text(), '"+email+"')]/..//following-sibling::td[5]//button[@title='Open this item']";
		System.out.println(driver.findElement(By.xpath(xpath)).getTagName());
		System.out.println(driver.findElement(By.xpath(xpath)).getAttribute(
				"title"));

		WebElement tableRow = driver.findElement(By
				.xpath("//td[contains(text(), '"+email+"')]/parent::tr"));
		List<WebElement> tableCells = tableRow.findElements(By.xpath("td"));
		String MeID = tableCells.get(4).getText();
		System.out.println("employee MeID" + MeID);

		// FFFFFFF YOU - ok so with screen maximised the vertical scroll bar is
		// not right at the top
		// so webdriver locates the element on screen using xpath (x,y) and
		// attempt to click on (x,y)
		// and due to scroll position clicks on column header
		// right so to get round this scroll issue extract the project code and
		// search using this

		return MeID;
	}

}
