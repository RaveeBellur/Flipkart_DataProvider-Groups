package mebank.pageobjects.admin;

import mebank.dataobjects.Project;
import mebank.pageobjects.PageObject;
import mebank.resources.Utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;


public class ProjectReviewPage extends PageObject {
   
    @FindBy(xpath = "//td[contains(text(), 'Project Name')]/following-sibling::td")
    private WebElement projectName;
 	
	@FindBy(xpath = "//td[contains(text(), 'Project Code')]/following-sibling::td")
    private WebElement projectCode;
    
	@FindBy(xpath = "//td[contains(text(), 'Project Manager Name')]/following-sibling::td")
    private WebElement projectManagerName;
    
	@FindBy(xpath = "//td[contains(text(), 'Project Manager ID')]/following-sibling::td")
    private WebElement projectManagerMeID;
         
	@FindBy(xpath = "//td[contains(text(), 'Project Manager Email')]/following-sibling::td")
    private WebElement projectManagerEmail;
          
	@FindBy(xpath = "//td[contains(text(), 'Project Status')]/following-sibling::td")
    private WebElement projectStatus;
    
	@FindBy(xpath = "//td[contains(text(), 'Programme')]/following-sibling::td")    
    private WebElement programme;
        
	@FindBy(xpath = "//td[contains(text(), 'Capitalised')]/following-sibling::td")
    private WebElement capitalised;
            
	@FindBy(xpath = "//td[contains(text(), 'Cost Center')]/following-sibling::td")
    private WebElement costCenter;
                                
	@FindBy(xpath = ".//button[contains(text(), 'Back')]")
    private WebElement btnBack;
    
    private final WebDriver driver;
    
    // ok so ui.loadableComponent.get calls this ( i.e. selenium out of the box )
	@Override
	protected void load() {
		System.out.println("start" + this.getClass().getName() + "load()");				
	}

	
	@Override
	protected void isLoaded() throws Error {			
		isAvailable(driver, this.getBy("btnBack"));		
	}
	
	
	public ProjectListPage goBackToProjectListPage() {				 		
		waitAndGetElement(this.getBy("btnBack"), driver).click();		
		switchBackToProjectListPage();
		return new ProjectListPage(driver);
	}
	
	
	public void switchBackToProjectListPage() {
		driver.switchTo().defaultContent(); // are we switching to default content ?
	} 
    
	
	 public ProjectReviewPage(WebDriver driver){
    	this.driver = driver;
        PageFactory.initElements(this.driver, this);
    }
    
	 
	public WebElement getProjectName() {
		return projectName;
	}
	      
	public WebElement getProjectCode() {
		return projectCode;
	}
    
	public WebElement getProjectManagerName() {
		return projectManagerName;
	}
	
	public WebElement getProjectManagerMeID() {
		return projectManagerMeID;
	}
	
	public WebElement getProjectManagerEmail() {
		return projectManagerEmail;
	}
	 
	public Select getProjectStatus() {
		return (Select)projectStatus;
	}
	 
	public Select getProgramme() {
		return (Select)programme;
	}
	
	public Select getCapitalised() {
		return (Select)capitalised;
	}
	
	public WebElement getCostCenter() {
		return costCenter;
	}
	
	public Project getProjectDetails(Project project) {
		project.setProjectCode(getProjectCode().getText());
		project.setProjectName(getProjectName().getText());
		project.setProjectManagerName(getProjectManagerName().getText());
		project.setProjectManagerMeID(getProjectManagerMeID().getText());
		project.setProjectManagerEmail(getProjectManagerEmail().getText());		
		project.setProjectStatus(Utilities.getSelectedOption(driver, getProjectStatus()));
		project.setProgramme(Utilities.getSelectedOption(driver, getProgramme()));
		project.setCapitalised(Utilities.getSelectedOption(driver, getCapitalised()));
		project.setCostCenter(getCostCenter().getText());		
		return project;
	}
   
}
