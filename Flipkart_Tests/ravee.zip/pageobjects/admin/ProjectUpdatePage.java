package mebank.pageobjects.admin;

import mebank.dataobjects.Project;
import mebank.pageobjects.PageObject;
import mebank.resources.Utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ProjectUpdatePage extends PageObject {

	@FindBy(xpath = "//td[contains(text(), 'Project Code')]/following-sibling::td")
    private WebElement projectCode;
	
	@FindBy(xpath = "//input[@id='ProjectName']")
	private WebElement projectName;

	@FindBy(id = "CostCenter")
	private WebElement costCenter;

	@FindBy(id = "Cap")
	private WebElement capitalised;

	@FindBy(id = "ProjectManagerID")
	private WebElement projectManagerMeID;

	@FindBy(id = "ProjectManagerName")
	private WebElement projectManagerName;

	@FindBy(id = "ProjectManagerEmail")
	private WebElement projectManagerEmail;

	@FindBy(id = "ProjectStatus")
	private WebElement projectStatus;

	@FindBy(id = "Programme")
	private WebElement programme;

	@FindBy(xpath = "//button[contains(text(), 'Cancel')]")
	private WebElement btnCancel;

	@FindBy(xpath = "//button[contains(text(), 'Save')]")
	private WebElement btnSave;

	@FindBy(xpath = "//button[contains(text(), 'Back')]")
	private WebElement btnBack;

	private final WebDriver driver;

	@Override
	protected void load() {
		System.out.println("start" + this.getClass().getName() + "load()");
	}

	@Override
	protected void isLoaded() throws Error {		
		// use projectName as screen is used for both add and update								
		isAvailable(driver, 30000, this.getBy("projectName"));
		isAvailable(driver, 30000, this.getBy("projectStatus"));				
	}

	public ProjectUpdatePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	public void setAndSubmit(Project project) {
		this.set(project);
		this.save();
	}

	public void set(Project project) {
		System.out.println(project.getProjectName());
		this.setProjectName(project.getProjectName());
		this.setCostCenter(project.getCostCenter());
		this.setCap(project.getCapitalised());
		this.setProgramme(project.getProgramme());		
		this.setProjectManagerMeID(project.getProjectManagerID());
		this.setProjectManagerName(project.getProjectManagerName());
		this.setProjectManagerEmail(project.getProjectManagerEmail());
		this.setProjectStatus(project.getProjectStatus());
		this.setProgramme(project.getProgramme());
	}

	public Project getProject(Project project) {
		
		System.out.println("project update page get project");
		
		project.setProjectCode(getProjectCode().getText());
		project.setProjectName(getProjectName().getAttribute("value"));
		project.setProjectManagerName(getProjectManagerName().getAttribute("value"));
		project.setProjectManagerMeID(getProjectManagerMeID().getAttribute("value"));
		project.setProjectManagerEmail(getProjectManagerEmail().getAttribute("value"));
		project.setProjectStatus(Utilities.getSelectedOption(driver,
				getProjectStatus()));
		project.setProgramme(Utilities
				.getSelectedOption(driver, getProgramme()));
		project.setCapitalised(Utilities.getSelectedOption(driver,
				getCapitalised()));
		project.setCostCenter(getCostCenter().getAttribute("value"));
		//System.out.println(project.toString());
		return project;
	}

	public void save() {
		this.btnSave.click();
	}

	public void setProjectCode(String projectCode) {
		setText(this.projectCode, projectCode);
	}

	public void setProjectName(String projectName) {
		setText(this.projectName, projectName);
	}

	public void setProjectManagerMeID(String projectManagerID) {
		setText(this.projectManagerMeID, projectManagerID);
	}

	public void setProjectManagerName(String projectManagerName) {
		setText(this.projectManagerName, projectManagerName);
	}

	public void setProjectManagerEmail(String projectManagerEmail) {
		setText(this.projectManagerEmail, projectManagerEmail);
	}

	public void setCostCenter(String costCenter) {
		setText(this.costCenter, costCenter);
	}

	private void setCap(String cap) {
		Select capField = new Select(this.capitalised);
		capField.selectByValue(cap);
	}

	private void setProjectStatus(String projectStatus) {
		Select projectStatusField = new Select (this.projectStatus);
		projectStatusField.selectByValue(projectStatus);
	}

	public ProjectListPage cancel() {
		waitAndGetElement(this.getBy("btnCancel"), driver).click();		
		switchBackToProjectListPage();
		return new ProjectListPage(driver);
	}
	
	public ProjectListPage goBackToProjectListPage() {				 		
		waitAndGetElement(this.getBy("btnBack"), driver).click();		
		switchBackToProjectListPage();
		return new ProjectListPage(driver);
	}

	private void switchBackToProjectListPage() {
		driver.switchTo().defaultContent();
	}

	public WebElement getProjectCode() {
		return projectCode;
	}

	public WebElement getProjectName() {		
		return projectName;
	}

	public WebElement getCostCenter() {
		return costCenter;
	}

	public WebElement getProjectManagerMeID() {
		return projectManagerMeID;
	}

	public WebElement getProjectManagerName() {
		return projectManagerName;
	}

	public WebElement getProjectManagerEmail() {
		return projectManagerEmail;
	}

	public Select getProjectStatus() {		
		return new Select(this.projectStatus);
	}

	public Select getCapitalised() {
		return new Select(this.capitalised);
	}

	public Select getProgramme() {
		return new Select(this.programme);
	}

	public void setProgramme(String programme) {
		Select programmeField = new Select (this.programme);
		programmeField.selectByValue(programme);	
	}

	public void setCapitalised(WebElement capitalised) {
		this.capitalised = capitalised;
	}

}
