package mebank.pageobjects.admin;

import mebank.pageobjects.PageObject;
import mebank.resources.Iframes;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


public class ProjectMaintenancePage extends PageObject {
    private static final String PROJECT_DETAILS = "Project details";
	private static final String EMPLOYEE_LIST = "Employee details";   
	private static final String TASK_DETAILS = "Task Details";
	
    @FindBy(linkText = "New")
    private WebElement newLink;
                    
    private final WebDriver driver; 
               
    public ProjectMaintenancePage(WebDriver driver){
    	this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
	@Override
	protected void load() 
	{	
		System.out.println(this.getClass().toString() + " load()");
		// i.e. to get to this screen you need to login first
		//LoginPage loginPage = (LoginPage) new LoginPage(driver).get(); 
		//loginPage.submitDefaultData();
	}
		
	
	@Override
	protected void isLoaded() throws Error {
		boolean FrameLoaded = isAvailable(driver, By.xpath("//iframe[@id='PWGadget0Ifr']"));
		// TODO a better check page is loaded other than the frame
		if(FrameLoaded) {
			waitForFrameAndSwitchToIt(driver, Iframes.PROJECT_MAINTENANCE_TAB_FRAME_NAME.getFrameName());							
			String xpath = "//*[contains(text(), 'Data Maintainence Tables')]";
			isAvailable(driver, By.xpath(xpath));
		}
//Assert.assertTrue(isElementPresent(driver, By.xpath("//iframe[@id='PWGadget0Ifr']")));
		/*
		System.out.println(this.getClass().toString() + " start is loaded?");
		// well done for making this assumption.
		// check if it's and fill an authentication. 
		List<WebElement> anchorList = this.driver.findElements(By.tagName("a"));
		Boolean isPresent = false;
		// note this only waits for the page to load ( what about the contents of the 4 iframes / tabs ? )
		for(WebElement element : anchorList) {
			//System.out.println(element.getText());
			// what the F is this ? make a call using isElementPresent in PageObject
			isPresent = (element.getText().trim().equals("New")) ? true : isPresent;
			if(isPresent) {
				break;
			}
		}
		System.out.println("isPresent" + Boolean.toString(isPresent));
		try {
			Assert.assertTrue(isPresent);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new AssertionError();
		}// how the f does this assertion failing trigger  load ?
		System.out.println(this.getClass().toString() + " end is loaded?");
		*/
	}


	public void submit() {
//    	WebDriverWait wait = new WebDriverWait(driver, 3);
//        WebDriverWait wait = new WebDriverWait(driver, 3);
//    	WebElement contractorListIcon = wait2.until(new Function<WebDriver, WebElement> () {
//			public WebElement apply(WebDriver arg0) {
//				// TODO Auto-generated method stub
//				return driver.findElement(By.xpath(".//table[@title='Employee Information']/parent::node()/following-sibling::td[position()=2]/span"));
//			}
//    	});
    	waitAndGetElement(By.xpath(".//table[@title='Employee Information']/parent::node()/following-sibling::td[position()=2]/span"), driver).click();
    	//contractorListIcon.click();

        //** Get handles in iFrames **//
//        webdriver.switchTo().frame(pegaFraMeID);
//        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt("PWGadget2Ifr"));
//
//    	
//    	wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt("PWGadget2Ifr"));
	}

    
	public void submitDefaultData() {
    	/**
    	 * There is no data requirements to go to next page in this Page
    	 * and hence no data is being added and the page is submitted.
    	 */
    	submit();
    }
    
    
    public void viewEmployeeList(){
    	getListFor(EMPLOYEE_LIST).click();
    }
    
	public void viewProjectList() {
		getListFor(PROJECT_DETAILS).click();		
	}
	
	public void viewTaskList() {
		getListFor(TASK_DETAILS).click();		
	}
    
	
	public static String getEMPLOYEE_LIST() {
		return EMPLOYEE_LIST;
	}

	public static String getPROJECT_DETAILS() {
		return PROJECT_DETAILS;
	}
	
	public static String getTASK_DETAILS() {
		return TASK_DETAILS;
	}
	
	// TODO if you name this switch proj maintance tab then get it to click AND switch
    public ProjectMaintenancePage switchToProjectMaintenanceTab(){    	
    	// TODO: if we're already on the proj maintenance tab no need to click icon
    	String xpath;    	    	
    	//uh assert for something that is visible and ONLY visible on the project maintenance tab
    	xpath = ".//*[contains(@title,'Project Maintenance')]/img"; // not the icon which is visible regardless which tab you're on    	    	     	    
    	driver.findElement(By.xpath(xpath)).click(); 
    	// huh ? just clicking the icon is not going to shift to the iframe inside the tab
    	 
    	waitForFrameAndSwitchToIt(driver, Iframes.PROJECT_MAINTENANCE_TAB_FRAME_NAME.getFrameName());
    	// this fails because element is not ready or visible in time ?
    	WebDriverWait wait = new WebDriverWait(driver, 60);
    	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(), 'Data Maintainence Tables')]")));
    	Assert.assertTrue(isElementPresent(driver, By.xpath("//span[contains(text(), 'Data Maintainence Tables')]")));    	    	    	    	    	    	   
    	
    	// TODO put in a highlight here    	    	
    	//System.out.println(driver.getPageSource());    	
    	return this;
    }
    
    
    // todo
    // this is a really badly named method
    // get list for really means open the window for proj task or contractor add/edit
	private WebElement getListFor(String list){						
		String xpath;								
		// this wait and get element is a retarded way of saying search for an element we expect to be on the page we switch to
		// TODO ok here use a highlight element function
		xpath = "//table[contains(@title, '"+ list +"')]/parent::node()/following-sibling::td[position()=2]/span";
		return waitAndGetElement(By.xpath(xpath), driver);			
	}

}