package mebank.pageobjects.admin;

import mebank.dataobjects.Task;
import mebank.pageobjects.PageObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TaskReviewPage extends PageObject {

	@FindBy(xpath = "//td[contains(text(), 'Task Code')]/following-sibling::td")
	private WebElement taskCode;

	@FindBy(xpath = "//td[contains(text(), 'Task Name')]/following-sibling::td")
	private WebElement taskName;

	@FindBy(xpath = "//td[contains(text(), 'Description')]/following-sibling::td")
	private WebElement description;

	@FindBy(xpath = ".//button[contains(text(), 'Back')]")
	private WebElement btnBack;

	private final WebDriver driver;

	@Override
	protected void load() {
		System.out.println("start" + this.getClass().getName() + "load()");
	}

	@Override
	protected void isLoaded() throws Error {
		isAvailable(driver, this.getBy("btnBack"));
	}

	public TaskReviewPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	public WebElement getTaskCode() {
		return taskCode;
	}

	public WebElement getTaskName() {
		return taskName;
	}

	public WebElement getDescription() {
		return description;
	}

	public TaskListPage goBackToTaskListPage() {
		waitAndGetElement(this.getBy("btnBack"), driver).click();
		switchBackToTaskListPage();
		return new TaskListPage(driver);
	}

	private void switchBackToTaskListPage() {
		driver.switchTo().defaultContent();
	}

	public Task getTaskDetails(Task task) {
		task.setTaskCode(getTaskCode().getText());
		task.setTaskName(getTaskName().getText());
		task.setDescription(getDescription().getText());
		return task;
	}

}
