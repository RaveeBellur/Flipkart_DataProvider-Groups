package mebank.pageobjects.admin;

import mebank.dataobjects.Employee;
import mebank.pageobjects.PageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ContractorAddPage extends PageObject {

	@FindBy(xpath = "//*[@id='FirstName']")
	private WebElement firstName;

	@FindBy(id = "LastName")
	private WebElement lastName;

	@FindBy(id = "FullName")
	private WebElement fullName;

	@FindBy(id = "MEID")
	private WebElement MeID;

	@FindBy(id = "Role")
	private WebElement role;

	@FindBy(id = "EmpType")
	private WebElement empType;

	@FindBy(id = "Vendor")
	private WebElement vendor;

	@FindBy(id = "Rate")
	private WebElement rate;

	@FindBy(id = "Email")
	private WebElement email;

	@FindBy(id = "LineManagerID")
	private WebElement lineManagerID;

	@FindBy(id = "LineManager")
	// N.B
	private WebElement lineManagerName;

	@FindBy(id = "LineManagerEmail")
	private WebElement lineManagerEmail;

	@FindBy(id = "TimeSheetRequired")
	private WebElement timeSheetRequired;

	@FindBy(xpath = ".//button[contains(text(), 'Cancel')]")
	private WebElement btnCancel;

	@FindBy(xpath = ".//button[contains(text(), 'Save')]")
	private WebElement btnSave;

	@FindBy(xpath = ".//button[contains(text(), 'Back')]")
	private WebElement btnBack;

	private final WebDriver driver;

	// ok so ui.loadableComponent.get calls this ( i.e. selenium out of the box
	// )
	@Override
	protected void load() {
		System.out.println("start" + this.getClass().getName() + "load()");
	}

	@Override
	protected void isLoaded() throws Error {
		isAvailable(driver, this.getBy("firstName"));
	}

	
	public void save() {
		// savePageSource(this.driver, this.getClass().getName());
		PageObject.highlightElement(driver, this.firstName);
		this.btnSave.click();
		// if error validation fails need to stay on this page
		// for now assume no error

		// this.submitAndWait(btnSave, driver); // TODO we're going to have to
		// override the submitandwait
		// because we're in another frame here

		// also problem.if you're testing click save. you might want to check
		// error condition
		// if you click save and u expect it to
	}

	public ContractorListPage cancel() {
		waitAndGetElement(this.getBy("btnCancel"), driver).click();
		switchBackToConstractorListPage();
		return new ContractorListPage(driver);
	}

	public ContractorListPage goBackToEmployeeListPage() {
		waitAndGetElement(this.getBy("btnBack"), driver).click();
		switchBackToConstractorListPage();
		return new ContractorListPage(driver);
	}

	public void switchBackToConstractorListPage() {
		driver.switchTo().defaultContent();
	}

	public ContractorAddPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	public void submit() {
		save();
		// this.submitAndWait(submit, driver);
	}

	public void setAndSubmit(Employee employee) {
		this.set(employee);
		this.submit();
		// TODO some sort of assertion that it saved
	}

	public void set(Employee employee) {
		this.setFirstName(employee.getFirstName());
		this.setLastName(employee.getLastName());
		this.setFullName(employee.getFullName());
		this.setMeID(employee.getMeID());
		// this.setRole(employee.getRole());// has been dropped
		this.setEmployeeType(employee.getEmpType());
		// vendor only needs to be selected if employee type is contractor
		if (employee.getVendor() != null
				&& employee.getEmpType().equals(Employee.CONTRACTOR))
			this.setVendor(employee.getVendor());
		else
			this.setVendor("Select...");
		this.setEmail(employee.getEmail());
		this.setLineManagerID(employee.getLineManagerMeID());
		this.setLineManagerName(employee.getLineManagerEmail());
		this.setLineManagerEmail(employee.getLineManagerEmail());
		PageObject.highlightElement(driver, this.firstName);
		this.setFillTimeSheetRequired(employee.getFillTimesheet());
	}

	public void setFirstName(String firstName) {
		setText(this.firstName, firstName);
	}

	public void setLastName(String lastName) {
		setText(this.lastName, lastName);
	}

	public void setFullName(String fullName) {
		setText(this.fullName, fullName);
	}

	public void setMeID(String MeID) {
		setText(this.MeID, MeID);
	}

	public void setEmail(String email) {
		setText(this.email, email);
	}

	public void setLineManagerID(String id) {
		setText(this.lineManagerID, id);
	}

	public void setLineManagerEmail(String email) {
		setText(this.lineManagerEmail, email);
	}

	public void setLineManagerName(String name) {
		setText(this.lineManagerName, name);
	}

	public void setRole(String role) {
		setText(this.role, role);
	}

	public void setEmployeeType(String empType) {
		Select titleElementSelect = new Select(this.empType);
		titleElementSelect.selectByValue(empType);
	}

	public void setFillTimeSheetRequired(boolean required) {
		setCheckbox(this.timeSheetRequired, required);

	}

	public void setVendor(String vendor) {
		Select vendorSelect = new Select(this.vendor);
		vendorSelect.selectByValue(vendor);
	}

}
