package mebank.pageobjects.admin;

import mebank.dataobjects.Task;
import mebank.pageobjects.PageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TaskUpdatePage extends PageObject {

	@FindBy(xpath = "//td[contains(text(), 'Task Code')]/following-sibling::td")	
	private WebElement taskCode;

	@FindBy(id = "TaskName")
	private WebElement taskName;

	@FindBy(id = "Description")
	private WebElement description;

	@FindBy(xpath = ".//button[contains(text(), 'Cancel')]")
	private WebElement btnCancel;

	@FindBy(xpath = ".//button[contains(text(), 'Save')]")
	private WebElement btnSave;

	@FindBy(xpath = ".//button[contains(text(), 'Back')]")
	private WebElement btnBack;

	private final WebDriver driver;
	

	@Override
	protected void load() {
		System.out.println("start" + this.getClass().getName() + "load()");		
	}

	@Override
	protected void isLoaded() throws Error {		
		isAvailable(driver, this.getBy("taskCode"));		
	}

	
	public void submit() {
		save();
		// this.submitAndWait(btnSave, driver);
	}

	public TaskUpdatePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	public void setAndSubmit(Task task) {
		this.set(task);
		this.submit();
	}

	public void set(Task task) {
		//this.setTaskCode(task.getTaskCode());// in update mode cannot update
		this.setTaskName(task.getTaskName());
		this.setDescription(task.getDescription());
	}
	
	
	public Task getTask(Task task) {		
		System.out.println("project update page get project");
		task.setTaskCode(getTaskCode().getText());
		task.setDescription(getDescription().getText());
		task.setTaskName(getTaskName().getText());		
		System.out.println(task.toString());
		return task;
	}

	public void save() {
		this.btnSave.click();
	}

	public WebElement getTaskCode() {
		return this.taskCode;
	}

	public WebElement getTaskName() {
		return this.taskName;
	}

	public WebElement getDescription() {
		return this.description;
	}
	
	
	public void setTaskCode(String taskCode) {
		setText(this.taskCode, taskCode);
	}

	public void setTaskName(String taskName) {
		setText(this.taskName, taskName);
	}

	public void setDescription(String description) {
		setText(this.description, description);
	}

	public TaskListPage goBackToTaskListPage() {
		waitAndGetElement(this.getBy("btnBack"), driver).click();
		switchBackToTaskListPage();
		return new TaskListPage(driver);
	}

	
	private void switchBackToTaskListPage() {
		driver.switchTo().defaultContent(); 
	}
	
	public TaskListPage cancel() {
		waitAndGetElement(this.getBy("btnCancel"), driver).click();		
		switchBackToTaskListPage();
		return new TaskListPage(driver);
	}

}
