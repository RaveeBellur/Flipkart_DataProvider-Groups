package mebank.pageobjects.admin;

import java.util.List;
import mebank.dataobjects.TimeSheet;
import mebank.pageobjects.PageObject;
import mebank.pageobjects.TabsTable;
import mebank.resources.Iframes;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MarkToBePaidPage extends PageObject {

	@FindBy(id = "button1")
	private WebElement btnSubmit;

	private final WebDriver driver;

	public MarkToBePaidPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@Override
	protected void load() {
		System.out.println("start" + this.getClass().getName() + "load()");
	}

	@Override
	protected void isLoaded() throws Error {
		System.out.println(this.getClass().toString() + " isLoaded()");

		TabsTable t = (TabsTable) new TabsTable(driver).get();
		t.clickMarkToBePaidTab();

		String frameName = Iframes.MARK_TO_BE_PAID_FRAME_NAME.getFrameName();
		boolean frameLoaded = isAvailable(driver,
				By.xpath("//iframe[@id='" + frameName + "']"));

		if (frameLoaded) {
			waitForFrameAndSwitchToIt(driver, frameName);
			isAvailable(driver, this.getBy("btnSubmit"));
		}
	}

	// TODO how to which days.. you'd need to look up off ts object and all ts
	// rows which days were on it
	// might have multiple rows
	public void markToBePaidPartial(TimeSheet ts) {
		;
	}

	public void submit() {
		btnSubmit.click();
	}

	// TODO create private function to return lsit of all ts on page so remove
	// duplicated lines of code
	public boolean isTimeSheetInListOfMarkToBePaid(TimeSheet ts) {
		sleep(3000);// TODO see if can remove these somehow
		boolean timeSheetFound = false;

		List<WebElement> tsSearchTableRows = driver.findElements(By
				.xpath("//table[@id='bodyTbl_right']/tbody/tr"));
		// start at 1 because 0 is header
		for (int i_RowNum = 1; i_RowNum < tsSearchTableRows.size(); i_RowNum++) {
			List<WebElement> tsSearchTableCol = tsSearchTableRows.get(i_RowNum)
					.findElements(By.xpath("td"));
			if (tsSearchTableCol.size() > 1) {
				// hard coded index to avoid searching all columns. [1] -
				// Employee Name [2] - TS End date
				if (tsSearchTableCol.get(1).getText()
						.equals(ts.getEmployeeName())
						&& tsSearchTableCol.get(2).getText()
								.equals(ts.getWeekEnding())) {
					timeSheetFound = true;
				}
			}
		}
		return timeSheetFound;
	}

	public void markToBePaidInFull(TimeSheet ts) {
		List<WebElement> tsSearchTableRows = driver.findElements(By
				.xpath("//table[@id='bodyTbl_right']/tbody/tr"));
		// start at 1 because 0 is header
		for (int i_RowNum = 1; i_RowNum < tsSearchTableRows.size(); i_RowNum++) {
			List<WebElement> tsSearchTableCol = tsSearchTableRows.get(i_RowNum)
					.findElements(By.xpath("td"));
			if (tsSearchTableCol.size() > 1) {
				// hard coded index to avoid searching all columns. [1] -
				// Employee Name [2] - TS End date
				if (tsSearchTableCol.get(1).getText()
						.equals(ts.getEmployeeName())
						&& tsSearchTableCol.get(2).getText()
								.equals(ts.getWeekEnding())) {
					tsSearchTableCol.get(4).click(); // [4] - Unpaid Hours tick
														// box - total hours.
														// pay in full.
				}
			}
		}
	}

	public void submitAllTimeSheetsToBePaid() {
		boolean tableUnpaidHours = (isAvailable(driver,
				By.xpath("//table[@id='bodyTbl_right']/tbody/tr")));
		if (tableUnpaidHours) {
			List<WebElement> rowCollection = driver.findElements(By
					.xpath("//table[@id='bodyTbl_right']/tbody/tr"));
			if (rowCollection.size() > 1) { // skip the first two rows for
											// headers
				for (int i = 1; i < rowCollection.size(); i++) {
					rowCollection.get(i).findElement(By.xpath("td[5]")).click();
				}
				btnSubmit.click();
			} else
				System.out.println("No items to be marked for payment");
		}
	}

}