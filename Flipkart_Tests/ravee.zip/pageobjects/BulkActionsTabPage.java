package mebank.pageobjects;

import mebank.dataobjects.Employee;
import mebank.resources.Iframes;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class BulkActionsTabPage extends PageObject {

	// TODO implement

	@FindBy(id = "sub")
	private WebElement sub;
	
	@FindBy(xpath = "//select[@id='objOperatorSelect1']")
	private WebElement transferWorkFromSelect;
	
	

	private final WebDriver driver;

	// @Test(dataProvider = "login")
	public BulkActionsTabPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@Override
	protected void load() {
		System.out.println(this.getClass().toString() + " load()");

	}

	@Override
	protected void isLoaded() throws Error {		
		System.out.println(this.getClass().toString() + " isLoaded()");		
		
		TabsTable t = (TabsTable) new TabsTable(driver).get();
		t.clickbulkActionsTab();
		
		String frameName = Iframes.BULK_ACTIONS_FRAME_NAME.getFrameName();
		boolean FrameLoaded = isAvailable(driver, By.xpath("//iframe[@id='"+frameName+"']"));
		// TODO a better check page is loaded other than the frame
		if(FrameLoaded) {
			waitForFrameAndSwitchToIt(driver, frameName);										
			isAvailable(driver, getBy("transferWorkFromSelect"));
		}	
	}

	public void submit() {
		sub.click();
	}
	
	public void selectTransferFrom(Employee e) {
		System.out.println("select transfer from " + e.getFullName());
		Select transferWorkFromSelect = new Select(this.transferWorkFromSelect);
		transferWorkFromSelect.selectByValue(e.getMeID());// note the select displays names but the values are meid
		// selecting the name from the list opens new tab so handle the transfer in the steps file 						
	}

}
