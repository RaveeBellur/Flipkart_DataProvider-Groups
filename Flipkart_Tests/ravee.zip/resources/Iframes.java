package mebank.resources;
 	
public enum Iframes {
	
	//TODO. cannot rely on the frame name + number to be consistent because tabs can be opened in different
	// orders ( e.g. bulk actions is 6 work item is only 7 if you don't trigger action to open other tab )
	
	//TODO would need  afunction to iterate over all frames. find the frame that matches the title and then
	// extract frame name
	
	
	
	CREATE_TIMESHEET_TAB_WEEKENDING_DATE_SELECTOR_FRAME_NAME("PWGadget0Ifr"),
	PROJECT_MAINTENANCE_TAB_FRAME_NAME("PWGadget0Ifr"),
	SEARCH_TAB_FRAME_NAME("PWGadget1Ifr"),
	REPORTS_TAB_FRAME_NAME("PWGadget2Ifr"),
	PENDING_SUBMISSION_TAB_FRAME_NAME("PWGadget3Ifr"),	
	SELECT_INTERNAL_APPROVE_TAB_FRAME_NAME("PWGadget1Ifr"), // used to be 0 now 1 as now create tab also for internal
	SELECT_EXTERNAL_APPROVE_TAB_FRAME_NAME("PWGadget1Ifr"),
	CREATED_BUT_NOT_SUBMITTED_TAB_FRAME_NAME("PWGadget3Ifr"),	
	FILL_TIMESHEET_ROWS_TAB_FRAME_NAME("PWGadget1Ifr"),	
	FILL_TIMESHEET_CONFIRMATION_TAB_FRAME_NAME("PWGadget1Ifr"),
	MARK_TO_BE_PAID_FRAME_NAME("PWGadget5Ifr"),
	BULK_ACTIONS_FRAME_NAME("PWGadget6Ifr"),
	TRANSFER_WORK_ITEM_FRAME_NAME("PWGadget7Ifr"),
	
	ADMIN_CREATE_TIMESHEET_TAB_WEEKENDING_DATE_SELECTOR_FRAME_NAME("PWGadget6Ifr"),
	ADMIN_FILL_TIMESHEET_ROWS_TAB_FRAME_NAME("PWGadget6Ifr"),
	ADMIN_FILL_TIMESHEET_CONFIRMATION_TAB_FRAME_NAME("PWGadget6Ifr");
	//ADMIN_CREATE_TIMESHEET_TAB_WEEKENDING_DATE_SELECTOR_FRAME_NAME("PWGadget5Ifr"),
	//ADMIN_FILL_TIMESHEET_ROWS_TAB_FRAME_NAME("PWGadget5Ifr"),
	//ADMIN_FILL_TIMESHEET_CONFIRMATION_TAB_FRAME_NAME("PWGadget5Ifr");
	
	
	private final String frameName;
	
 	
	private Iframes (String frameName) {
		this.frameName =  frameName;
	}

	public String getFrameName() {
		return frameName;
	}
	
	public static Iframes fromPropertyName(String x) throws Exception {
		for (Iframes currentType : Iframes.values()) {
	      if (x.equals(currentType.getFrameName())) {
	        return currentType;
	      }
	    }
	    throw new Exception("Unmatched Type: " + x);
	  }
	
}

		
		
	

	
	

