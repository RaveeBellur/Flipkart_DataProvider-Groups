package mebank.resources;

import org.junit.rules.TestWatcher;
import org.junit.runner.Description;

public class ScreenShotRule extends TestWatcher
{	
	private BaseTestJUnitVersion testcase;
	private boolean testPassed;
		
	public ScreenShotRule(BaseTestJUnitVersion baseTestJUnitVersion) 
	{
		System.out.println("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF");
		this.testcase =  baseTestJUnitVersion;        
	}
	
	@Override
    protected void succeeded(Description d) 
	{         
		System.out.println("screenshot rule test passed");
		testPassed = true;
    }
	
	
	@Override
    protected void failed(Throwable e, Description description) 
    {		
		System.out.println("screenshot rule test failed");
		testcase.takeScreenShot();
		testPassed = false;
    }
	
	@Override
    protected void finished(Description description)
	{        				                       
        
		// if closeBrowser is not set then don't close the window
		if (testPassed)
		{
		//	testcase.logout();
		//	testcase.closeWindow();
		}					
    }		
}
