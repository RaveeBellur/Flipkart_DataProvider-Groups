package mebank.resources;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;





public class BaseTestJUnitVersion
{
	
	//@Rule
	//public TestName testName = new TestName();
	public String testName = "testname";
	
	//@Rule
    //public ScreenShotRule screenShotRule = new ScreenShotRule(this); 
	
	
	public WebDriver driver;
    public InternetExplorerDriverService service;
    public String pegaFraMeID = "PWGadget2Ifr";
    
    
   
    
        
    
    public void setUp()
    {
    	System.out.println("is this being called");    	
    	InitialiseDriver();
    	if(driver != null)
			System.out.println("FFFFFFFFFFFFFFFFF driver is not null");
    	
    }
    
    //N.B note BeforeTest vs AfterMethod
    // 
    // OR PLAN B don't use testNG
    //@After
    public void tearDown()
    {    	    	    	
        if(TestConfig.flagSet("closeBrowserAfterTest")) {
        	this.driver.quit();
        	this.driver.close();
        }
    }
    
    
   
    
    
    public void InitialiseDriver()
    {    	    	    
    	if (TestConfig.getProperty("browser").contains("ie")) {            
    		Utilities.taskkillInternetExplorer();
    		    		
    		File file;            
            if(System.getProperty("sun.arch.data.model").equals("32"))    
                file = new File("lib/IEDriverServer32/IEDriverServer.exe");                
            else
                file = new File("lib/IEDriverServer.exe");                    
            
            DesiredCapabilities capability = DesiredCapabilities.internetExplorer();
                                                                   
            System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
            System.out.println("file absolute path (the path shows if 32 or 64 bit IEDriverServer) "+file.getAbsolutePath());
            System.out.println(System.getProperty("webdriver.ie.driver"));
                                                                     
            // see http://selenium.googlecode.com/git/docs/api/java/org/openqa/selenium/remote/CapabilityType.html
            //capability.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
            capability.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);            
            capability.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);                                              
            capability.setCapability(InternetExplorerDriver.ENABLE_ELEMENT_CACHE_CLEANUP, true);
            capability.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, TestConfig.getProperty("pegaURL"));
            //capability.setCapability(InternetExplorerDriver.FORCE_CREATE_PROCESS, false);                        
            this.driver = new InternetExplorerDriver(capability);              
        }
    	else {
    		 this.driver = new FirefoxDriver();             
    	}  
    	driver.manage().window().maximize();                
        System.out.println("is the browser session id null" + ((RemoteWebDriver) driver).getSessionId().toString());
        //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //driver.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
    }
    
    public void takeScreenShot() {		
		if (TestConfig.flagSet("screenshots")) {
			File file = ((org.openqa.selenium.TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {
				java.util.Date date= new java.util.Date();
				String timestamp = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss").format(date.getTime());					
				timestamp = timestamp.replace(":", "_");
									
				String fileName = StringUtils.join(
							new String[] {
									Utilities.screenshotDirectory(),
									timestamp + "_" 
											//+ TODO insert user type
											+   "_"
											+ getClass().getSimpleName() + "_"
											+ testName + ".png" }, File.separator);
				
				FileUtils.copyFile(file, new File(fileName));					
			}
			catch (IOException exception) {
				exception.printStackTrace();
			}								
		}    		
	}	
}

