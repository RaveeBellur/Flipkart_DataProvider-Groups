package mebank.resources;

import java.util.HashMap;

import mebank.dataobjects.Employee;

public class User {

	public static class LoggedInUser {
		private Employee loggedInUser;

		public Employee getLoggedInUser() {
			return loggedInUser;
		}

		public void setLoggedInUser(Employee loggedInUser) {
			this.loggedInUser = loggedInUser;
		}

		private static LoggedInUser instance = new LoggedInUser();

		private LoggedInUser() {
		}

		public static LoggedInUser getInstance() {
			return instance;
		}
	}

	private static HashMap<String, Employee> users = new HashMap<String, Employee>();

	public static Employee CONTRACTOR1 = initUser("contractor1");
	public static Employee CONTRACTOR2 = initUser("contractor2");
	public static Employee CONTRACTOR3 = initUser("contractor3");
	public static Employee APPROVER1 = initUser("approver1");
	public static Employee APPROVER2 = initUser("approver2");
	public static Employee ADMINISTRATOR = initUser("administrator");

	/*
	 * private static int CONTRACTOR1_INDEX = 0; private static int
	 * CONTRACTOR2_INDEX = 1; private static int APPROVER1_INDEX = 2; private
	 * static int APPROVER2_INDEX = 3; private static int ADMINISTRATOR_INDEX =
	 * 4;
	 */

	private static Employee initUser(String propertyRef) {
		Employee employee = new Employee();
		employee.setUserType(TestConfig.getProperty(propertyRef
				+ "EmployeeType"));
		// employee.setEmpType(TestConfig.getProperty(propertyRef +
		// "EmployeeType"));
		employee.setMeID(TestConfig.getProperty(propertyRef + "MeID"));
		employee.setPassword(TestConfig.getProperty(propertyRef + "Password"));
		employee.setFirstName(TestConfig.getProperty(propertyRef + "FirstName"));
		employee.setLastName(TestConfig.getProperty(propertyRef + "LastName"));
		employee.setFullName(TestConfig.getProperty(propertyRef + "FirstName")
				+ " " + TestConfig.getProperty(propertyRef + "LastName"));
		employee.setEmail(TestConfig.getProperty(propertyRef + "Email"));
		employee.setManagesProject(TestConfig.getProperty(propertyRef
				+ "ManagesProject"));
		users.put(propertyRef, employee);
		return employee;
	}

	public static Employee getUser(String userType) {
		Employee user = null;
		user = users.get(userType);

		// TODO put some diagnostic output so from console no confusion as to
		// who logs in
		return user;
	}

}
