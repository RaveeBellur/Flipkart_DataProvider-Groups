package mebank.resources;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public final class TestConfig {
	private static final String OVERRIDES_PROPERTY = "test.config.override";
	private static final String USER_PROPERTY = "runAs.user";
	private static final String JENKINSBUILDNAME_PROPERTY = "jenkins.build.name";
	private static final String JENKINS_SET_BROWSER = "jenkins.set.browser";

	private static Properties properties = new Properties();

	static {
		try {
			System.out.println("WITH OUR WITHOUR JUNIT AS WRAPPER"
					+ System.getProperty("user.dir"));

			System.out.println("TestConfig loads properties");
			System.out.println(System.getProperty("user.dir"));
			// properties.load(new FileInputStream("default.properties"));
			properties.load(new FileInputStream(System.getProperty("user.dir")
					+ "\\default.properties"));

			// if test.config.override= is specified as JVM arg override
			// properties set by default.properties
			Properties systemProperties = System.getProperties();
			String overrideFileName = (String) systemProperties
					.get(OVERRIDES_PROPERTY);

			if (systemProperties.containsKey(OVERRIDES_PROPERTY)) {
				properties.load(new FileInputStream(System
						.getProperty("user.dir") + "\\" + overrideFileName));
			}
		} catch (FileNotFoundException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public static boolean hasOverrides() {
		return properties == null;
	}

	public static String getProperty(String key) {
		return properties.getProperty(key);
	}

	public static void setProperty(String key, String value) {
		properties.setProperty(key, value);
	}

	public static boolean flagSet(String key) {
		System.out.println(properties.get(key));
		return properties.get(key).equals("true");
	}

	public static boolean isIE() {
		// return properties.getProperty("browser").startsWith("*ie");
		System.out.println("is it IE?");
		return getBrowser().startsWith("*ie");
	}

	public static boolean isFirefox() {
		return getBrowser().contains("firefox");
		// return properties.getProperty("browser").equals("*firefox");
	}

	public static String getJenkinsBuildName() {
		String jenkinsBuildName = "this must be set in jenkins build parameter";
		System.out.println("check java args has jenkins build name been set");
		if (System.getProperties().containsKey(JENKINSBUILDNAME_PROPERTY)) {
			System.out.println("jenkins build name has been set");
			jenkinsBuildName = System.getProperties().getProperty(
					JENKINSBUILDNAME_PROPERTY);
		}
		return jenkinsBuildName;

	}

	public static String getBrowser() {
		String browser = "browser to be set";
		System.out.println("getBrowser() check java args has browser been set");
		System.out.println("browser ["
				+ System.getProperties().getProperty("browser") + "]");
		System.out
				.println("jenskins set browser ["
						+ System.getProperties().getProperty(
								JENKINS_SET_BROWSER) + "]");
		// check for java cmd line arg browser override otherwise use the
		// browser set in properties file
		// N.B check system properties for jenkins set browser as this is NOT
		// loaded through properties set in TestConfig
		boolean wasBrowserSetInJenkins = false;

		if (System.getProperties().containsKey(JENKINS_SET_BROWSER)) {
			// NOTE. JENKINS_SET_BROWSER - see build.xml junit task this POS is
			// set ( even if to default ) of value="${jenkins.set.browser}"
			// so let us check it is set to something other than this
			if (!System.getProperties().getProperty(JENKINS_SET_BROWSER)
					.equals("${jenkins.set.browser}"))
				wasBrowserSetInJenkins = true;
		}

		if (wasBrowserSetInJenkins) {
			browser = System.getProperties().getProperty(JENKINS_SET_BROWSER);
		} else // (TestConfig.properties.containsKey("browser"))
		{
			browser = TestConfig.getProperty("browser");
		}
		System.out.println("browser [" + browser + "]");
		return browser;
	}

}
