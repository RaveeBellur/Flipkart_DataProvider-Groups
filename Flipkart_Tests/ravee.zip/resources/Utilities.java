package mebank.resources;

import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Random;
import java.util.Set;

import mebank.pageobjects.PageObject;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.Scenario;

public class Utilities {
	// is there a way to test what browser is being used?
	// extend for other browsers
	public static String randomIdentifier() {
		final String lexicon = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
		final java.util.Random rand = new java.util.Random();
		// consider using a Map<String,Boolean> to say whether the identifier is
		// being used or not
		final Set<String> identifiers = new HashSet<String>();

		StringBuilder builder = new StringBuilder();
		while (builder.toString().length() == 0) {
			int length = rand.nextInt(5) + 5;
			for (int i = 0; i < length; i++)
				builder.append(lexicon.charAt(rand.nextInt(lexicon.length())));
			if (identifiers.contains(builder.toString()))
				builder = new StringBuilder();
		}
		return builder.toString();
	}

	public static void execDosCommand(String cmd) {
		try {
			Process p = Runtime.getRuntime().exec(cmd);
			p.waitFor();
			System.out.println("exec cmd " + cmd);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static String randomMeID() {
		int max = 999999; // e.g. me714053
		Random rand = new Random();
		int min = 0;
		int randomNum = rand.nextInt(max - min + 1) + min;
		return "me" + Integer.toString(randomNum);
	}

	public static String resource(String filename) {
		return StringUtils.join(new String[] { System.getProperty("user.dir"),
				"src", "test", "resources", filename }, File.separator);
	}

	public static String resources(String filename) {
		return StringUtils.join(new String[] { System.getProperty("user.dir"),
				"resources", filename }, File.separator);
	}

	public static String screenshotDirectory() {
		String dir = StringUtils.join(
				new String[] { System.getProperty("user.dir"), "screenshots" },
				File.separator);

		File dirFile = new File(dir);

		if (!new File(dir).exists()) {
			dirFile.mkdir();
		}
		return dir;
	}

	public static String getSelectedOption(WebDriver driver, Select webElement) {
		return webElement.getFirstSelectedOption().getText();
	}

	public static void setClipboard(String text) {
		StringSelection ss = new StringSelection(text);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
	}

	public static String removeLastChar(String text) {
		return text.substring(0, text.length() - 1);
	}

	public static void taskkillInternetExplorer() {
		Utilities.execDosCommand("cmd /c taskkill /f /im iexplore.exe");
		Utilities.execDosCommand("cmd /c taskkill /f /im mshta.exe");
		Utilities.execDosCommand("cmd /c taskkill /f /im IEDriverServer.exe");
	}

	public static void takeScreenShot(WebDriver driver, Scenario scenario) {
		if (TestConfig.flagSet("screenshots")) {
			File file = ((org.openqa.selenium.TakesScreenshot) driver)
					.getScreenshotAs(OutputType.FILE);
			try {
				java.util.Date date = new java.util.Date();
				String timestamp = new SimpleDateFormat(
						"EEE, dd MMM yyyy HH:mm:ss").format(date.getTime());
				timestamp = timestamp.replace(":", "_");

				String fileName = StringUtils.join(
						new String[] { Utilities.screenshotDirectory(),
								timestamp + "_"
								// + TODO insert user type
										+ "_" + scenario.getName() + ".png" },
						File.separator);

				FileUtils.copyFile(file, new File(fileName));
			} catch (IOException exception) {
				exception.printStackTrace();
			}
		}
	}

	public static String getDate(String timeSheetWeek) {
		System.out.println("timeSheetWeek [" + timeSheetWeek + "]");

		Calendar cal = Calendar.getInstance();
		// SimpleDateFormat df = new SimpleDateFormat(" dd/MM/yyyy");

		// use this when value is in format 20140921
		// SimpleDateFormat df = new SimpleDateFormat("YYYYMMdd");

		// check production env if value is in this format
		SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
		timeSheetWeek = timeSheetWeek.replace(" ", "");
		LinkedHashMap<String, String> weekEndMap = new LinkedHashMap<String, String>();

		while (cal.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
			cal.add(Calendar.DAY_OF_WEEK, 1);
		}

		int weekCount = -9; // start from -9 to +3 for past 9 weeks sunday and
							// future 3 weeks sunday
		for (int i = 0; i < 13; i++) {
			// add the weekcount to 
			cal.add(Calendar.DAY_OF_WEEK_IN_MONTH, weekCount); // add the
																// weekcount to
																// get the
																// required
																// sunday
			if (weekCount < 0) {
				weekEndMap.put("currentweek-" + Math.abs(weekCount),
						df.format(cal.getTime()).trim());
				cal.add(Calendar.DAY_OF_WEEK_IN_MONTH, Math.abs(weekCount)); // revert
																				// the
																				// days
																				// added
																				// to
																				// return
																				// to
																				// today
			} else if (weekCount == 0) {
				weekEndMap.put("currentweek", df.format(cal.getTime()).trim());
			} else if (weekCount > 0) {
				weekEndMap.put("currentweek-" + weekCount,
						df.format(cal.getTime()).trim());
				cal.add(Calendar.DAY_OF_WEEK_IN_MONTH, (-weekCount));
			}

			weekCount++;
		}
		// System.out.println(weekEndMap);
		System.out.println(" weekEndMap.get(timeSheetWeek) ["
				+ weekEndMap.get(timeSheetWeek) + "]");
		System.out.println("weekEndMap.get(timeSheetWeek);"
				+ weekEndMap.get(timeSheetWeek));
		return weekEndMap.get(timeSheetWeek);
	}

	public static void listFrames(WebDriver driver) {
		List<WebElement> body = driver.findElements(By.xpath("//BODY"));
		System.out.println("number of body" + body.size());
		for (WebElement e : body) {
			System.out.println("tag" + e.getTagName());
			System.out.println("body id" + e.getAttribute("id"));
		}
		List<WebElement> iframes = driver.findElements(By.xpath("//iframe"));
		System.out.println("number of iframe" + iframes.size());
		for (WebElement e : iframes) {
			System.out.println("itag" + e.getTagName());
			System.out.println("iframe id" + e.getAttribute("id"));
		}
		List<WebElement> frames = driver.findElements(By.xpath("iframe"));
		System.out.println("number of frame" + frames.size());
		for (WebElement e : frames) {
			System.out.println("tag" + e.getTagName());
			System.out.println("frame id" + e.getAttribute("id"));
		}
		List<WebElement> inputs = driver.findElements(By.xpath("//input"));
		System.out.println("number of inputs" + inputs.size());
		for (WebElement e : inputs) {
			System.out.println("inputs id" + e.getAttribute("id"));
		}
		List<WebElement> buttons = driver.findElements(By.xpath("//button"));
		System.out.println("number of buttons" + buttons.size());
		for (WebElement e : buttons) {
			System.out.println("buttons" + e.getAttribute("id"));
		}
		PageObject.listAllElementsOnPage(driver);
	}

}
