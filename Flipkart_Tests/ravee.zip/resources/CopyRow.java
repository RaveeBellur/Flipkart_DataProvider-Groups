package mebank.resources;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.util.CellRangeAddress;

public class CopyRow {

	// N.B code is from http://stackoverflow.com/questions/14516932/insert-a-row-in-excel-using-java-apache-poi
	
	public static HSSFSheet copyRow(HSSFWorkbook srcWorkbook,
			HSSFSheet srcWorksheet, HSSFSheet dstWorkSheet, int sourceRowNum,
			int destinationRowNum) {
		// Get the source / new row
		HSSFRow newRow = dstWorkSheet.getRow(destinationRowNum);
		HSSFRow sourceRow = srcWorksheet.getRow(sourceRowNum);

		// If the row exist in destination, push down all rows by 1 else create
		// a new row
		if (newRow != null) {
			dstWorkSheet.shiftRows(destinationRowNum,
					dstWorkSheet.getLastRowNum(), 1);
		} else {
			newRow = dstWorkSheet.createRow(destinationRowNum);
		}

		// Loop through source columns to add to new row
		for (int i = 0; i < sourceRow.getLastCellNum(); i++) {
			// Grab a copy of the old/new cell
			HSSFCell oldCell = sourceRow.getCell(i);
			HSSFCell newCell = newRow.createCell(i);

			// If the old cell is null jump to next cell
			if (oldCell == null) {
				newCell = null;
				continue;
			}

			// Copy style from old cell and apply to new cell
			// HSSFCellStyle newCellStyle = srcWorkbook.createCellStyle();
			// newCellStyle.cloneStyleFrom(oldCell.getCellStyle());
			// newCell.setCellStyle(newCellStyle);

			// If there is a cell comment, copy
			if (oldCell.getCellComment() != null) {
				newCell.setCellComment(oldCell.getCellComment());
			}

			// If there is a cell hyperlink, copy
			if (oldCell.getHyperlink() != null) {
				newCell.setHyperlink(oldCell.getHyperlink());
			}

			// Set the cell data type
			newCell.setCellType(oldCell.getCellType());

			// Set the cell data value
			switch (oldCell.getCellType()) {
			case Cell.CELL_TYPE_BLANK:
				newCell.setCellValue(oldCell.getStringCellValue());
				break;
			case Cell.CELL_TYPE_BOOLEAN:
				newCell.setCellValue(oldCell.getBooleanCellValue());
				break;
			case Cell.CELL_TYPE_ERROR:
				newCell.setCellErrorValue(oldCell.getErrorCellValue());
				break;
			case Cell.CELL_TYPE_FORMULA:
				newCell.setCellFormula(oldCell.getCellFormula());
				break;
			case Cell.CELL_TYPE_NUMERIC:
				newCell.setCellValue(oldCell.getNumericCellValue());
				break;
			case Cell.CELL_TYPE_STRING:
				newCell.setCellValue(oldCell.getRichStringCellValue());
				break;			
			}
		}

		// If there are are any merged regions in the source row, copy to new
		// row
		for (int i = 0; i < srcWorksheet.getNumMergedRegions(); i++) {
			CellRangeAddress cellRangeAddress = srcWorksheet.getMergedRegion(i);
			if (cellRangeAddress.getFirstRow() == sourceRow.getRowNum()) {
				CellRangeAddress newCellRangeAddress = new CellRangeAddress(
						newRow.getRowNum(),
						(newRow.getRowNum() + (cellRangeAddress.getLastRow() - cellRangeAddress
								.getFirstRow())), cellRangeAddress
								.getFirstColumn(), cellRangeAddress
								.getLastColumn());
				srcWorksheet.addMergedRegion(newCellRangeAddress);
			}
		}
		return dstWorkSheet;
	}
}
