package mebank.resources;

import java.io.File;
import java.util.HashMap;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

/**
 * Created with IntelliJ IDEA.
 * User: me713561
 * Date: 6/11/13
 * Time: 6:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class GetExcelTableArray {

    public static Object[][] getTableArray(String xlFilePath, String sheetName, String tableName){
        Object[][] objArray = null;
        HashMap<String, String> map;
        
        //TestDataProvider testDataProvider;

        try{
            Workbook workbook = Workbook.getWorkbook(new File(xlFilePath));
            Sheet sheet = workbook.getSheet(sheetName);
            int startRow,startCol, endRow, endCol,ci,cj;

            Cell tableStart=sheet.findCell(tableName);
            startRow=tableStart.getRow();
            startCol=tableStart.getColumn();
            
            Cell tableEnd= sheet.findCell(tableName, startCol+1,startRow+1, 100, 64000,  false);

            endRow=tableEnd.getRow();
            endCol=tableEnd.getColumn();
             	System.out.println("startRow="+startRow+", endRow="+endRow+", " +  "startCol="+startCol+", endCol="+endCol);
            objArray = new Object[endRow-startRow-1][1];
            ci=0;
            

            for (int i=startRow+1;i<endRow;i++,ci++){
                cj=0;
                map = new HashMap<String, String>();
                for (int j=startCol+1;j<endCol;j++,cj++){
                    map.put(sheet.getCell(j, startRow).getContents(), sheet.getCell(j, i).getContents());
                    System.out.println(sheet.getCell(j, startRow).getContents() +  sheet.getCell(j, i).getContents());
                }
                //testDataProvider = new TestDataProvider();
                //testDataProvider.set(map);
                //objArray[ci][0] = testDataProvider;
            }
        } catch (Exception e)    {
	        System.out.println("error in getTableArray()");
	    }
//        return(tabArray);
        return(objArray);
    }

    public static void main(String[] args) {
    	System.out.println("Start");
        
    	//Object[][] test = getTableArray(TestDataProvider.DEFAULT_SPREADSHEET, "sheet", "test1");
    	getTableArray("C:/1Ravee/WorkSpace/TimeSheetApp/resources/timesheet.xls", "default" ,"default");
    	
        System.out.println("End");
//        for(int i = 0; i < test.length; i++) {
//        	TestDataProvider data = (TestDataProvider) test[i][0];
//        }
//        System.out.println((DataProvider) )
        
        
    }


}
