package mebank.resources;

public enum Tabs {
	CREATE_TIMESHEET("create timesheet", "Create Timesheet"), 
	FOR_APPROVAL("for approval", "Items To Be Approved"), 
	DATA_MAINTENANCE("data maintenance", "Data Maintenance"), 
	SEARCH("search", "Search Timesheet"), 
	REPORTS("reports", "Reports"), 
	PENDING_SUBMISSION("pending submission", "Created But Not Submitted Timesheets"),
	MARK_TO_BE_PAID("mark to be paid", "Approve Payments For Submitted Timesheet");

	private final String tabText; // tabName
	private final String tabToolTip;
	

	private Tabs(String tabText, String tabToolTip) {
		this.tabText = tabText;
		this.tabToolTip = tabToolTip;
	}

	public String getTabText() {
		return tabText;
	}
	
	public String getTabToolTip() {
		return tabToolTip;
	}

	public static Tabs fromPropertyName(String x) throws Exception {
		for (Tabs currentType : Tabs.values()) {
			if (x.equals(currentType.getTabText())) {
				return currentType;
			}
		}
		throw new Exception("Unmatched Type: " + x);
	}

}
