package mebank.dataobjects;

import java.util.ArrayList;
import java.util.List;

public class TimeSheet {

	private String goal;
	private String deadline;
	private String status;
	private String weekEnding;

	private String employeeName;
	private String employeeMeID; // e.g if admin creates t/s on behalf of the employee
	
	private String caseID = "blankCaseID"; // need code on getter so that if it is null return empty string
	
	private String unpaidHours;
	private String paidHours;
	 
	// this should maintain an array of timesheet row objects

	private List<TimeSheetRow> timeSheetRows = new ArrayList<TimeSheetRow>();

	public void set(String goal, String deadline, String status,
			String weekEnding) {
		this.setGoal(goal);
		this.setDeadline(deadline);
		this.setStatus(status);
		this.setWeekEnding(weekEnding);
	}

	public String getGoal() {
		return goal;
	}

	public void setGoal(String goal) {
		this.goal = goal;
	}

	public String getDeadline() {
		return deadline;
	}

	public void setDeadline(String deadline) {
		this.deadline = deadline;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getWeekEnding() {
		return weekEnding;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public void setWeekEnding(String weekEnding) {
		//TODO put in some check that this returns weekending string in yyyymmdd format
		this.weekEnding = weekEnding;
	}

	public String getCaseID() {
		return caseID;
	}

	public void setCaseID(String caseID) {
		this.caseID = caseID;
	}
	
	public void addTimeSheetRow(TimeSheetRow timeSheetRow) {
		timeSheetRows.add(timeSheetRow);
	}

	public List<TimeSheetRow> getTimeSheetRows() {
		return this.timeSheetRows;
	}

	public TimeSheetRow getTimeSheetRow(int rowIndex) {
		return timeSheetRows.get(rowIndex);
	}

	public TimeSheetRow setTimeSheetRow(int rowIndex) {
		return timeSheetRows.get(rowIndex);
	}

	public int projectCount() {
		return timeSheetRows.size();
	}
	
	public String getUnpaidHours() {
		return unpaidHours;
	}

	public void setUnpaidHours(String unpaidHours) {
		this.unpaidHours = unpaidHours;
	}

	public String getPaidHours() {
		return paidHours;
	}

	public void setPaidHours(String paidHours) {
		this.paidHours = paidHours;
	}
	
	public String getEmployeeMeID() {
		return employeeMeID;
	}

	public void setEmployeeMeID(String employeeMeID) {
		this.employeeMeID = employeeMeID;
	}

}
