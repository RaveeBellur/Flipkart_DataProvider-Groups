package mebank.dataobjects;

import java.lang.reflect.Field;
import java.util.Arrays;

// TODO consider creating a user class and then subclass it for specific types 
public class Employee {
	private String firstName;
	private String lastName;
	private String fullName;
	private String MeID;
	private String email;
	private String role;
	private String empType = PERMANENT; // default
	private String vendor;
	private String rate;
	private String lineManagerID;
	private String lineManagerName;
	private String lineManagerEmail;
	private Boolean fillTimesheet = false;
	private String password;
	private String managesProject;
	private String userType; // not to be confused with empType.

	public static final String PERMANENT = "Permanent";
	public static final String MAXIMUM_TERM = "Maximum Term";
	public static final String CASUAL = "Casual";
	public static final String CONTRACTOR = "Contractor";

	public static final String USER_TYPE_CONTRACTOR = "CONTRACTOR";
	public static final String USER_TYPE_ADMINISTRATOR = "ADMINISTRATOR";
	public static final String USER_TYPE_INTERNAL_PROJECT_MANAGER = "INTERNAL_PROJECT_MANAGER";
	public static final String USER_TYPE_EXTERNAL_PROJECT_MANAGER = "EXTERNAL_PROJECT_MANAGER";

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getEmpType() {
		return empType;
	}

	public Employee setEmpType(String empType) {
		// TODO replace this with a switch
		// TODO split out empType and UserRole and use role to login.
		if (empType.trim().toLowerCase().contains("permanent"))
			this.empType = Employee.PERMANENT;
		else if (empType.trim().toLowerCase().contains("contractor"))
			this.empType = Employee.CONTRACTOR;
		else if (empType.trim().toLowerCase().contains("maximum term"))
			this.empType = Employee.MAXIMUM_TERM;
		return this;
	}

	public String getVendor() {
		return vendor;
	}

	public Employee setVendor(String agency) {
		this.vendor = agency;
		return this;
	}

	public String getRate() {
		return rate;
	}

	public Employee setRate(String rate) {
		this.rate = rate;
		return this;
	}

	public String getLineManagerMeID() {
		return lineManagerID;
	}

	public Employee setLineManagerID(String lineManagerID) {
		this.lineManagerID = lineManagerID;
		return this;
	}

	public String getLineManagerEmail() {
		// TODO return empty string if null
		return lineManagerEmail;
	}

	public Employee setLineManagerEmail(String lineManagerEmail) {
		this.lineManagerEmail = lineManagerEmail;
		return this;
	}
	
	public String getLineManagerName() {
		return lineManagerName;
	}

	public void setLineManagerName(String lineManagerName) {
		this.lineManagerName = lineManagerName;
	}

	public Boolean getFillTimesheet() {
		return fillTimesheet;
	}

	public Employee setFillTimesheet(Boolean fillTimesheet) {
		this.fillTimesheet = fillTimesheet;
		return this;
	}

	public String getEmail() {
		return email;
	}

	public Employee setEmail(String email) {
		this.email = email;
		return this;
	}

	public String getMeID() {
		return MeID;
	}

	public Employee setMeID(String MeID) {
		this.MeID = MeID;
		return this;
	}

	public String getRole() {
		return role;
	}

	public Employee setRole(String role) {
		this.role = role;
		return this;
	}

	public String getLastName() {
		return lastName;
	}

	public Employee setLastName(String lastName) {
		this.lastName = lastName;
		return this;
	}

	public String getFirstName() {
		return firstName;
	}

	public Employee setFirstName(String firstName) {
		this.firstName = firstName;
		return this;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getManagesProject() {
		return managesProject;
	}

	public void setManagesProject(String managesProject) {
		this.managesProject = managesProject;
	}
	
	@Override
	public String toString() {

		for (Field field : this.getClass().getDeclaredFields()) {
			try {
				System.out.println(field.getName() + " - [" + field.get(this)
						+ "]");
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return "";
	}

	@Override
	public boolean equals(Object other)	{
		boolean equals = true;
				
		Field[] thisFields = this.getClass().getDeclaredFields();
		Field[] otherFields = other.getClass().getDeclaredFields();
		
		
		for(int i = 0; i < thisFields.length; i++) {
			Field f1 = thisFields[i];
			Field f2 = thisFields[i];	
			try {
				System.out.println(f1.get(this));
				System.out.println(f2.get(other));				
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}						
		}
		equals = Arrays.equals(thisFields, otherFields);		
		return equals;
	}

}
