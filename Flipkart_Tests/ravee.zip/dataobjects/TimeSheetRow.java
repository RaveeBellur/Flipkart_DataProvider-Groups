package mebank.dataobjects;

import java.lang.reflect.Field;

public class TimeSheetRow {

	private String projectName;
	private String projectTask;
	private String mon;
	private String tue;
	private String wed;
	private String thu;
	private String fri;
	private String sat;
	private String sun;
	
	private String submitterComments;
	private String approverComments;
	 

	public String getProjectName() {
		return projectName;
	}

	public TimeSheetRow setProjectName(String projectName) {
		this.projectName = projectName;
		return this;
	}

	public String getProjectTask() {
		return projectTask;
	}

	public TimeSheetRow setProjectTask(String projectTask) {
		this.projectTask = projectTask;
		return this;
	}

	public String getMonday() {
		if(mon == null || mon.length() == 0)
			return "0.0";
		else
			return mon;			
	}

	public TimeSheetRow setMonday(String monday) {
		this.mon = monday;
		return this;
	}

	public String getTuesday() {
		if(tue == null || tue.length() == 0)
			return "0.0";
		else
			return tue;		
	}

	public TimeSheetRow setTuesday(String tuesday) {
		this.tue = tuesday;
		return this;
	}

	public String getWednesday() {
		if(wed == null || wed.length() == 0)
			return "0.0";
		else
			return wed;				
	}

	public TimeSheetRow setWednesday(String wednesday) {
		this.wed = wednesday;
		return this;
	}

	public String getThursday() {
		if(thu == null || thu.length() == 0)
			return "0.0";
		else
			return thu;				
	}

	public TimeSheetRow setThursday(String thursday) {
		this.thu = thursday;
		return this;
	}

	public String getFriday() {
		if(fri == null || fri.length() == 0)
			return "0.0";
		else
			return fri;			
	}

	public TimeSheetRow setFriday(String friday) {
		this.fri = friday;
		return this;
	}

	public String getSaturday() {
		if(sat == null || sat.length() == 0)
			return "0.0";
		else
			return sat;			
	}

	public TimeSheetRow setSaturday(String saturday) {
		this.sat = saturday;
		return this;
	}

	public String getSunday() {
		if(sun == null || sun.length() == 0)
			return "0.0";
		else
			return sun;		
	}

	public TimeSheetRow setSunday(String sunday) {
		this.sun = sunday;
		return this;
	}

	
	public String getSubmitterComments() {
		if(submitterComments == null)
			return "";
		else
			return submitterComments;
	}

	public TimeSheetRow setSubmitterComments(String comments) {
		this.submitterComments = comments;
		return this;
	}

	
	public String getApproverComments() {
		if(approverComments == null)
			return "";
		else
			return approverComments;		
	}

	
	public TimeSheetRow setApproverComments(String comments) {
		this.approverComments = comments;
		return this;
	}
	
		
	@Override
	public String toString() {

		for (Field field : this.getClass().getDeclaredFields()) {
			try {
				System.out.println(field.getName() + " - [" + field.get(this)
						+ "]");
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return "";
	}

}
