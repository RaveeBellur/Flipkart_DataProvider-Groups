package mebank.dataobjects;

import java.lang.reflect.Field;
import java.util.Arrays;

public class Project {
	private String projectCode;
	private String projectName;
	private String costCenter;
	private String capitalised = "Capex"; // default
	private String phase;
	private String programme;

	private String projectManagerID;
	private String projectManagerName;
	private String projectManagerEmail;
	private String projectStatus = "Open"; // default

	public String getProjectCode() {
		return projectCode;
	}

	public Project setProjectCode(String projectCode) {
		this.projectCode = projectCode;
		return this;
	}

	public String getProjectName() {
		return projectName;
	}

	public Project setProjectName(String projectName) {
		this.projectName = projectName;
		return this;
	}

	public String getCostCenter() {
		return costCenter;
	}

	public Project setCostCenter(String costCenter) {
		this.costCenter = costCenter;
		return this;
	}

	public String getCapitalised() {
		return capitalised;
	}

	public Project setCapitalised(String cap) {
		this.capitalised = cap;
		return this;
	}

	public String getPhase() {
		return phase;
	}

	public Project setPhase(String phase) {
		this.phase = phase;
		return this;
	}

	public String getProgramme() {
		return programme;
	}

	public Project setProgramme(String programme) {
		this.programme = programme;
		return this;
	}

	public String getProjectManagerName() {
		return projectManagerName;
	}

	public Project setProjectManagerName(String projectManager) {
		this.projectManagerName = projectManager;
		return this;
	}

	public String getProjectManagerEmail() {
		return projectManagerEmail;
	}

	public Project setProjectManagerEmail(String projectManagerEmail) {
		this.projectManagerEmail = projectManagerEmail;
		return this;
	}

	public String getProjectStatus() {
		return projectStatus;
	}

	public Project setProjectStatus(String projectStatus) {
		this.projectStatus = projectStatus;
		return this;
	}

	public String getProjectManagerID() {
		return projectManagerID;
	}

	public void setProjectManagerMeID(String projectManagerID) {
		this.projectManagerID = projectManagerID;
	}

	//TODO do we also need to override hashcode
	
	@Override
	public String toString() {

		for (Field field : this.getClass().getDeclaredFields()) {
			try {
				System.out.println(field.getName() + " - [" + field.get(this)
						+ "]");
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return "";
	}

	@Override
	public boolean equals(Object other)	{
		boolean equals = true;
				
		Field[] thisFields = this.getClass().getDeclaredFields();
		Field[] otherFields = other.getClass().getDeclaredFields();
		
		
		for(int i = 0; i < thisFields.length; i++) {
			Field f1 = thisFields[i];
			Field f2 = thisFields[i];	
			try {
				System.out.println(f1.get(this));
				System.out.println(f2.get(other));				
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}						
		}
		equals = Arrays.equals(thisFields, otherFields);		
		return equals;
	}
}
