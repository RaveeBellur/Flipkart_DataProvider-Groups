package mebank.dataobjects;

import java.lang.reflect.Field;
import java.util.Arrays;

public class Task {
	private String taskCode;
	private String taskName;
	private String description;
	public String getTaskCode() {
		return taskCode;
	}
	public void setTaskCode(String taskCode) {
		this.taskCode = taskCode;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	@Override
	public String toString() {

		for (Field field : this.getClass().getDeclaredFields()) {
			try {
				System.out.println(field.getName() + " - [" + field.get(this)
						+ "]");
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return "";
	}
	
	@Override
	public boolean equals(Object other)	{
		boolean equals = true;
				
		Field[] thisFields = this.getClass().getDeclaredFields();
		Field[] otherFields = other.getClass().getDeclaredFields();
		
		
		for(int i = 0; i < thisFields.length; i++) {
			Field f1 = thisFields[i];
			Field f2 = thisFields[i];	
			try {
				System.out.println(f1.get(this));
				System.out.println(f2.get(other));				
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}						
		}
		equals = Arrays.equals(thisFields, otherFields);		
		return equals;
	}
	
}
